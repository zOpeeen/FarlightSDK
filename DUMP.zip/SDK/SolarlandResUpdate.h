/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package SolarlandResUpdate.

/// Class /Script/SolarlandResUpdate.DownloadFileTask
/// Size: 0x00A0 (0x000028 - 0x0000C8)
class UDownloadFileTask : public UObject
{ 
public:
	FMulticastInlineDelegate                           OnDownloadComplete;                                         // 0x0028   (0x0010)  
	FMulticastInlineDelegate                           OnDownloadProgress;                                         // 0x0038   (0x0010)  
	FMulticastInlineDelegate                           OnDownloadFailed;                                           // 0x0048   (0x0010)  
	unsigned char                                      UnknownData00_6[0x70];                                      // 0x0058   (0x0070)  MISSED


	/// Functions
	// Function /Script/SolarlandResUpdate.DownloadFileTask.StartDownload
	void StartDownload();                                                                                                    // [0x2a56440] Final|Native|Public|BlueprintCallable 
	// Function /Script/SolarlandResUpdate.DownloadFileTask.SetSaveToFile
	void SetSaveToFile(bool InSet);                                                                                          // [0x2a563b0] Final|Native|Public|BlueprintCallable 
	// Function /Script/SolarlandResUpdate.DownloadFileTask.SetForceRedownload
	void SetForceRedownload(bool inForceRedownload);                                                                         // [0x2a56320] Final|Native|Public|BlueprintCallable 
	// Function /Script/SolarlandResUpdate.DownloadFileTask.GetUrl
	FString GetUrl();                                                                                                        // [0x2a562a0] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/SolarlandResUpdate.DownloadFileTask.CreateNoFile
	UDownloadFileTask* CreateNoFile(FString URL, bool bByChunk);                                                             // [0x2a561c0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/SolarlandResUpdate.DownloadFileTask.Create
	UDownloadFileTask* Create(FString URL, FString FileDirectory, FString Filename, bool bByChunk, bool bForceWrite);        // [0x2a55ff0] Final|Native|Static|Public|BlueprintCallable 
};

/// Class /Script/SolarlandResUpdate.SolarlandResUpdater
/// Size: 0x00B8 (0x000028 - 0x0000E0)
class USolarlandResUpdater : public UObject
{ 
public:
	unsigned char                                      UnknownData00_2[0x8];                                       // 0x0028   (0x0008)  MISSED
	FDelegateProperty                                  OnPatchPrompt;                                              // 0x0030   (0x0010)  
	FDelegateProperty                                  OnPatchComplete;                                            // 0x0040   (0x0010)  
	FDelegateProperty                                  OnPatchFailed;                                              // 0x0050   (0x0010)  
	FDelegateProperty                                  OnCDNDownloadFailed;                                        // 0x0060   (0x0010)  
	FDelegateProperty                                  OnPatchProgress;                                            // 0x0070   (0x0010)  
	FDelegateProperty                                  OnServerClose;                                              // 0x0080   (0x0010)  
	FDelegateProperty                                  OnBackdoorComplete;                                         // 0x0090   (0x0010)  
	FDelegateProperty                                  OnBackdoorFaild;                                            // 0x00A0   (0x0010)  
	FDelegateProperty                                  OnBackdoorProgress;                                         // 0x00B0   (0x0010)  
	FDelegateProperty                                  OnAnnouncementGet;                                          // 0x00C0   (0x0010)  
	FDelegateProperty                                  OnAnnouncementGetFail;                                      // 0x00D0   (0x0010)  
};

/// Enum /Script/SolarlandResUpdate.EDownloadTaskError
/// Size: 0x11
enum EDownloadTaskError : uint8_t
{
	EDownloadTaskError__ConnectFailed                                                = 0,
	EDownloadTaskError__RequestHeadFailed                                            = 1,
	EDownloadTaskError__CreateFileFailed                                             = 2,
	EDownloadTaskError__DownloadFailed                                               = 3,
	EDownloadTaskError__WriteFailed                                                  = 4,
	EDownloadTaskError__DeleteOldFailed                                              = 5,
	EDownloadTaskError__MoveFailed                                                   = 6,
	EDownloadTaskError__CreateDownloadTaskFail                                       = 7,
	EDownloadTaskError__GetPlatformFileFail                                          = 8,
	EDownloadTaskError__GetWrongJsonFormat                                           = 9,
	EDownloadTaskError__EDownloadTaskError_MAX                                       = 10
};

/// Enum /Script/SolarlandResUpdate.ELoginAnnouncement
/// Size: 0x04
enum ELoginAnnouncement : uint8_t
{
	ELoginAnnouncement__ServerCloseAnnounce                                          = 0,
	ELoginAnnouncement__UpdateAnnounce                                               = 1,
	ELoginAnnouncement__Unknown                                                      = 2,
	ELoginAnnouncement__ELoginAnnouncement_MAX                                       = 3
};

