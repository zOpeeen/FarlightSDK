/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package UdiniIntermediateModule.

/// Class /Script/UdiniIntermediateModule.UdiniIntermediateModuleBPLibrary
/// Size: 0x0000 (0x000028 - 0x000028)
class UUdiniIntermediateModuleBPLibrary : public UBlueprintFunctionLibrary
{ 
public:
};

