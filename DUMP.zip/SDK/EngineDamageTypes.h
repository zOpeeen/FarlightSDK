/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package EngineDamageTypes.

/// Class /Engine/EngineDamageTypes/DmgTypeBP_Environmental.DmgTypeBP_Environmental_C
/// Size: 0x0000 (0x000040 - 0x000040)
class UDmgTypeBP_Environmental_C : public UDamageType
{ 
public:
};

