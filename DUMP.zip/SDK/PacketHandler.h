/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package PacketHandler.

/// Class /Script/PacketHandler.HandlerComponentFactory
/// Size: 0x0000 (0x000028 - 0x000028)
class UHandlerComponentFactory : public UObject
{ 
public:
};

/// Class /Script/PacketHandler.PacketHandlerProfileConfig
/// Size: 0x0010 (0x000028 - 0x000038)
class UPacketHandlerProfileConfig : public UObject
{ 
public:
	TArray<FString>                                    Components;                                                 // 0x0028   (0x0010)  
};

