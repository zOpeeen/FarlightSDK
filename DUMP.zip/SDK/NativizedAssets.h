/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package NativizedAssets.

/// Class /Script/NativizedAssets.__Delegates__ABP_Penguin_C__pf944487101
/// Size: 0x0000 (0x000028 - 0x000028)
class U__Delegates__ABP_Penguin_C__pf944487101 : public UObject
{ 
public:
};

