/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package SoundFields.

/// Class /Script/SoundFields.AmbisonicsEncodingSettings
/// Size: 0x0008 (0x000028 - 0x000030)
class UAmbisonicsEncodingSettings : public USoundfieldEncodingSettingsBase
{ 
public:
	int32_t                                            AmbisonicsOrder;                                            // 0x0028   (0x0004)  
	unsigned char                                      UnknownData00_6[0x4];                                       // 0x002C   (0x0004)  MISSED
};

