/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package CommonUI.

/// Class /Script/CommonUI.AnalogSlider
/// Size: 0x0020 (0x000760 - 0x000780)
class UAnalogSlider : public USlider
{ 
public:
	FMulticastInlineDelegate                           OnAnalogCapture;                                            // 0x0760   (0x0010)  
	unsigned char                                      UnknownData00_6[0x10];                                      // 0x0770   (0x0010)  MISSED
};

/// Class /Script/CommonUI.CommonActionHandlerInterface
/// Size: 0x0000 (0x000028 - 0x000028)
class UCommonActionHandlerInterface : public UInterface
{ 
public:
};

/// Class /Script/CommonUI.CommonActionWidget
/// Size: 0x0338 (0x000138 - 0x000470)
class UCommonActionWidget : public UWidget
{ 
public:
	FMulticastInlineDelegate                           OnInputMethodChanged;                                       // 0x0138   (0x0010)  
	unsigned char                                      UnknownData00_5[0x8];                                       // 0x0148   (0x0008)  MISSED
	FSlateBrush                                        ProgressMaterialBrush;                                      // 0x0150   (0x00E0)  
	FName                                              ProgressMaterialParam;                                      // 0x0230   (0x0008)  
	unsigned char                                      UnknownData01_5[0x8];                                       // 0x0238   (0x0008)  MISSED
	FSlateBrush                                        IconRimBrush;                                               // 0x0240   (0x00E0)  
	TArray<FDataTableRowHandle>                        InputActions;                                               // 0x0320   (0x0010)  
	unsigned char                                      UnknownData02_5[0x8];                                       // 0x0330   (0x0008)  MISSED
	UMaterialInstanceDynamic*                          ProgressDynamicMaterial;                                    // 0x0338   (0x0008)  
	unsigned char                                      UnknownData03_6[0x130];                                     // 0x0340   (0x0130)  MISSED


	/// Functions
	// Function /Script/CommonUI.CommonActionWidget.SetInputActions
	void SetInputActions(TArray<FDataTableRowHandle> NewInputActions);                                                       // [0xbe0050] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonActionWidget.SetInputAction
	void SetInputAction(FDataTableRowHandle InputActionRow);                                                                 // [0xbdfea0] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonActionWidget.SetIconRimBrush
	void SetIconRimBrush(FSlateBrush InIconRimBrush);                                                                        // [0xbdfdf0] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonActionWidget.OnInputMethodChanged__DelegateSignature
	void OnInputMethodChanged__DelegateSignature(bool bUsingGamepad);                                                        // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/CommonUI.CommonActionWidget.IsHeldAction
	bool IsHeldAction();                                                                                                     // [0xbdf970] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonActionWidget.GetIcon
	FSlateBrush GetIcon();                                                                                                   // [0xbdf130] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonActionWidget.GetDisplayText
	FText GetDisplayText();                                                                                                  // [0xbdf090] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
};

/// Class /Script/CommonUI.CommonUserWidget
/// Size: 0x0028 (0x000260 - 0x000288)
class UCommonUserWidget : public UUserWidget
{ 
public:
	bool                                               bConsumePointerInput;                                       // 0x0260   (0x0001)  
	unsigned char                                      UnknownData00_6[0x27];                                      // 0x0261   (0x0027)  MISSED


	/// Functions
	// Function /Script/CommonUI.CommonUserWidget.SetConsumePointerInput
	void SetConsumePointerInput(bool bInConsumePointerInput);                                                                // [0xbeac30] Final|Native|Public|BlueprintCallable 
};

/// Class /Script/CommonUI.CommonActivatableWidget
/// Size: 0x0098 (0x000288 - 0x000320)
class UCommonActivatableWidget : public UCommonUserWidget
{ 
public:
	bool                                               bAutoActivate;                                              // 0x0288   (0x0001)  
	bool                                               bIsBackHandler;                                             // 0x0289   (0x0001)  
	bool                                               bSupportsActivationFocus;                                   // 0x028A   (0x0001)  
	bool                                               bIsModal;                                                   // 0x028B   (0x0001)  
	bool                                               bAutoRestoreFocus;                                          // 0x028C   (0x0001)  
	bool                                               bSetVisibilityOnActivated;                                  // 0x028D   (0x0001)  
	ESlateVisibility                                   ActivatedVisibility;                                        // 0x028E   (0x0001)  
	bool                                               bSetVisibilityOnDeactivated;                                // 0x028F   (0x0001)  
	ESlateVisibility                                   DeactivatedVisibility;                                      // 0x0290   (0x0001)  
	unsigned char                                      UnknownData00_5[0x7];                                       // 0x0291   (0x0007)  MISSED
	FMulticastInlineDelegate                           BP_OnWidgetActivated;                                       // 0x0298   (0x0010)  
	FMulticastInlineDelegate                           BP_OnWidgetDeactivated;                                     // 0x02A8   (0x0010)  
	bool                                               bIsActive;                                                  // 0x02B8   (0x0001)  
	unsigned char                                      UnknownData01_6[0x67];                                      // 0x02B9   (0x0067)  MISSED


	/// Functions
	// Function /Script/CommonUI.CommonActivatableWidget.IsActivated
	bool IsActivated();                                                                                                      // [0xbdf950] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonActivatableWidget.DeactivateWidget
	void DeactivateWidget();                                                                                                 // [0xbdeaf0] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonActivatableWidget.BP_OnHandleBackAction
	bool BP_OnHandleBackAction();                                                                                            // [0x2d64c70] Event|Protected|BlueprintEvent 
	// Function /Script/CommonUI.CommonActivatableWidget.BP_OnDeactivated
	void BP_OnDeactivated();                                                                                                 // [0x2d64c70] Event|Protected|BlueprintEvent 
	// Function /Script/CommonUI.CommonActivatableWidget.BP_OnActivated
	void BP_OnActivated();                                                                                                   // [0x2d64c70] Event|Protected|BlueprintEvent 
	// Function /Script/CommonUI.CommonActivatableWidget.BP_GetDesiredFocusTarget
	UWidget* BP_GetDesiredFocusTarget();                                                                                     // [0x2d64c70] Event|Protected|BlueprintEvent|Const 
	// Function /Script/CommonUI.CommonActivatableWidget.ActivateWidget
	void ActivateWidget();                                                                                                   // [0xbde9f0] Final|Native|Public|BlueprintCallable 
};

/// Class /Script/CommonUI.CommonActivatableWidgetContainerBase
/// Size: 0x0100 (0x000138 - 0x000238)
class UCommonActivatableWidgetContainerBase : public UWidget
{ 
public:
	ECommonSwitcherTransition                          TransitionType;                                             // 0x0138   (0x0001)  
	ETransitionCurve                                   TransitionCurveType;                                        // 0x0139   (0x0001)  
	unsigned char                                      UnknownData00_5[0x2];                                       // 0x013A   (0x0002)  MISSED
	float                                              TransitionDuration;                                         // 0x013C   (0x0004)  
	TArray<UCommonActivatableWidget*>                  WidgetList;                                                 // 0x0140   (0x0010)  
	UCommonActivatableWidget*                          DisplayedWidget;                                            // 0x0150   (0x0008)  
	FUserWidgetPool                                    GeneratedWidgetsPool;                                       // 0x0158   (0x0080)  
	unsigned char                                      UnknownData01_6[0x60];                                      // 0x01D8   (0x0060)  MISSED


	/// Functions
	// Function /Script/CommonUI.CommonActivatableWidgetContainerBase.RemoveWidget
	void RemoveWidget(UCommonActivatableWidget* WidgetToRemove);                                                             // [0xbdfb30] Final|Native|Private|BlueprintCallable 
	// Function /Script/CommonUI.CommonActivatableWidgetContainerBase.GetActiveWidget
	UCommonActivatableWidget* GetActiveWidget();                                                                             // [0xbdebe0] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonActivatableWidgetContainerBase.ClearWidgets
	void ClearWidgets();                                                                                                     // [0xbdead0] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonActivatableWidgetContainerBase.BP_AddWidget
	UCommonActivatableWidget* BP_AddWidget(UClass* ActivatableWidgetClass);                                                  // [0xbdea10] Final|Native|Private|BlueprintCallable 
};

/// Class /Script/CommonUI.CommonActivatableWidgetStack
/// Size: 0x0010 (0x000238 - 0x000248)
class UCommonActivatableWidgetStack : public UCommonActivatableWidgetContainerBase
{ 
public:
	UClass*                                            RootContentWidgetClass;                                     // 0x0238   (0x0008)  
	UCommonActivatableWidget*                          RootContentWidget;                                          // 0x0240   (0x0008)  
};

/// Class /Script/CommonUI.CommonActivatableWidgetQueue
/// Size: 0x0000 (0x000238 - 0x000238)
class UCommonActivatableWidgetQueue : public UCommonActivatableWidgetContainerBase
{ 
public:
};

/// Class /Script/CommonUI.CommonAnimatedSwitcher
/// Size: 0x0058 (0x000168 - 0x0001C0)
class UCommonAnimatedSwitcher : public UWidgetSwitcher
{ 
public:
	unsigned char                                      UnknownData00_2[0x18];                                      // 0x0168   (0x0018)  MISSED
	ECommonSwitcherTransition                          TransitionType;                                             // 0x0180   (0x0001)  
	ETransitionCurve                                   TransitionCurveType;                                        // 0x0181   (0x0001)  
	unsigned char                                      UnknownData01_5[0x2];                                       // 0x0182   (0x0002)  MISSED
	float                                              TransitionDuration;                                         // 0x0184   (0x0004)  
	unsigned char                                      UnknownData02_6[0x38];                                      // 0x0188   (0x0038)  MISSED


	/// Functions
	// Function /Script/CommonUI.CommonAnimatedSwitcher.SetDisableTransitionAnimation
	void SetDisableTransitionAnimation(bool bDisableAnimation);                                                              // [0xbdfc40] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonAnimatedSwitcher.HasWidgets
	bool HasWidgets();                                                                                                       // [0xbdf920] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonAnimatedSwitcher.ActivatePreviousWidget
	void ActivatePreviousWidget(bool bCanWrap);                                                                              // [0xbde960] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonAnimatedSwitcher.ActivateNextWidget
	void ActivateNextWidget(bool bCanWrap);                                                                                  // [0xbde8d0] Final|Native|Public|BlueprintCallable 
};

/// Class /Script/CommonUI.CommonActivatableWidgetSwitcher
/// Size: 0x0000 (0x0001C0 - 0x0001C0)
class UCommonActivatableWidgetSwitcher : public UCommonAnimatedSwitcher
{ 
public:
};

/// Class /Script/CommonUI.CommonBorderStyle
/// Size: 0x00E8 (0x000028 - 0x000110)
class UCommonBorderStyle : public UObject
{ 
public:
	unsigned char                                      UnknownData00_2[0x8];                                       // 0x0028   (0x0008)  MISSED
	FSlateBrush                                        Background;                                                 // 0x0030   (0x00E0)  


	/// Functions
	// Function /Script/CommonUI.CommonBorderStyle.GetBackgroundBrush
	void GetBackgroundBrush(FSlateBrush& Brush);                                                                             // [0xbdec10] Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const 
};

/// Class /Script/CommonUI.CommonBorder
/// Size: 0x0020 (0x000300 - 0x000320)
class UCommonBorder : public UBorder
{ 
public:
	UClass*                                            Style;                                                      // 0x0300   (0x0008)  
	bool                                               bReducePaddingBySafezone;                                   // 0x0308   (0x0001)  
	unsigned char                                      UnknownData00_5[0x3];                                       // 0x0309   (0x0003)  MISSED
	FMargin                                            MinimumPadding;                                             // 0x030C   (0x0010)  
	unsigned char                                      UnknownData01_6[0x4];                                       // 0x031C   (0x0004)  MISSED


	/// Functions
	// Function /Script/CommonUI.CommonBorder.SetStyle
	void SetStyle(UClass* InStyle);                                                                                          // [0xbe0910] Final|Native|Public|BlueprintCallable 
};

/// Class /Script/CommonUI.CommonBoundActionBar
/// Size: 0x0010 (0x0001F8 - 0x000208)
class UCommonBoundActionBar : public UDynamicEntryBoxBase
{ 
public:
	UClass*                                            ActionButtonClass;                                          // 0x01F8   (0x0008)  
	bool                                               bDisplayOwningPlayerActionsOnly;                            // 0x0200   (0x0001)  
	unsigned char                                      UnknownData00_6[0x7];                                       // 0x0201   (0x0007)  MISSED


	/// Functions
	// Function /Script/CommonUI.CommonBoundActionBar.SetDisplayOwningPlayerActionsOnly
	void SetDisplayOwningPlayerActionsOnly(bool bShouldOnlyDisplayOwningPlayerActions);                                      // [0xbdfcd0] Final|Native|Public|BlueprintCallable 
};

/// Class /Script/CommonUI.CommonButtonBase
/// Size: 0x0D58 (0x000288 - 0x000FE0)
class UCommonButtonBase : public UCommonUserWidget
{ 
public:
	int32_t                                            MinWidth;                                                   // 0x0288   (0x0004)  
	int32_t                                            MinHeight;                                                  // 0x028C   (0x0004)  
	UClass*                                            Style;                                                      // 0x0290   (0x0008)  
	bool                                               bHideInputAction;                                           // 0x0298   (0x0001)  
	unsigned char                                      UnknownData00_5[0x7];                                       // 0x0299   (0x0007)  MISSED
	FSlateSound                                        PressedSlateSoundOverride;                                  // 0x02A0   (0x0018)  
	FSlateSound                                        HoveredSlateSoundOverride;                                  // 0x02B8   (0x0018)  
	bool                                               bApplyAlphaOnDisable;                                       // 0x02D0:0 (0x0001)  
	bool                                               bSelectable;                                                // 0x02D0:1 (0x0001)  
	bool                                               bShouldSelectUponReceivingFocus;                            // 0x02D0:2 (0x0001)  
	bool                                               bInteractableWhenSelected;                                  // 0x02D0:3 (0x0001)  
	bool                                               bToggleable;                                                // 0x02D0:4 (0x0001)  
	bool                                               bDisplayInputActionWhenNotInteractable;                     // 0x02D0:5 (0x0001)  
	bool                                               bHideInputActionWithKeyboard;                               // 0x02D0:6 (0x0001)  
	bool                                               bShouldUseFallbackDefaultInputAction;                       // 0x02D0:7 (0x0001)  
	unsigned char                                      UnknownData01_4[0x1];                                       // 0x02D1   (0x0001)  MISSED
	TEnumAsByte<EButtonClickMethod>                    ClickMethod;                                                // 0x02D2   (0x0001)  
	TEnumAsByte<EButtonTouchMethod>                    TouchMethod;                                                // 0x02D3   (0x0001)  
	TEnumAsByte<EButtonPressMethod>                    PressMethod;                                                // 0x02D4   (0x0001)  
	unsigned char                                      UnknownData02_5[0x3];                                       // 0x02D5   (0x0003)  MISSED
	int32_t                                            InputPriority;                                              // 0x02D8   (0x0004)  
	unsigned char                                      UnknownData03_5[0x4];                                       // 0x02DC   (0x0004)  MISSED
	FDataTableRowHandle                                TriggeringInputAction;                                      // 0x02E0   (0x0010)  
	unsigned char                                      UnknownData04_5[0x10];                                      // 0x02F0   (0x0010)  MISSED
	FMulticastInlineDelegate                           OnSelectedChangedBase;                                      // 0x0300   (0x0010)  
	FMulticastInlineDelegate                           OnButtonBaseClicked;                                        // 0x0310   (0x0010)  
	FMulticastInlineDelegate                           OnButtonBaseDoubleClicked;                                  // 0x0320   (0x0010)  
	FMulticastInlineDelegate                           OnButtonBaseHovered;                                        // 0x0330   (0x0010)  
	FMulticastInlineDelegate                           OnButtonBaseUnhovered;                                      // 0x0340   (0x0010)  
	unsigned char                                      UnknownData05_5[0x4];                                       // 0x0350   (0x0004)  MISSED
	bool                                               bIsPersistentBinding;                                       // 0x0354   (0x0001)  
	ECommonInputMode                                   InputModeOverride;                                          // 0x0355   (0x0001)  
	unsigned char                                      UnknownData06_5[0x32];                                      // 0x0356   (0x0032)  MISSED
	UMaterialInstanceDynamic*                          SingleMaterialStyleMID;                                     // 0x0388   (0x0008)  
	FButtonStyle                                       NormalStyle;                                                // 0x0390   (0x03E0)  
	FButtonStyle                                       SelectedStyle;                                              // 0x0770   (0x03E0)  
	FButtonStyle                                       DisabledStyle;                                              // 0x0B50   (0x03E0)  
	bool                                               bStopDoubleClickPropagation;                                // 0x0F30:0 (0x0001)  
	unsigned char                                      UnknownData07_4[0x9F];                                      // 0x0F31   (0x009F)  MISSED
	UCommonActionWidget*                               InputActionWidget;                                          // 0x0FD0   (0x0008)  
	unsigned char                                      UnknownData08_6[0x8];                                       // 0x0FD8   (0x0008)  MISSED


	/// Functions
	// Function /Script/CommonUI.CommonButtonBase.StopDoubleClickPropagation
	void StopDoubleClickPropagation();                                                                                       // [0xbe0bf0] Final|Native|Protected|BlueprintCallable 
	// Function /Script/CommonUI.CommonButtonBase.SetTriggeringInputAction
	void SetTriggeringInputAction(FDataTableRowHandle& InputActionRow);                                                      // [0xbe0b50] Final|Native|Public|HasOutParms|BlueprintCallable 
	// Function /Script/CommonUI.CommonButtonBase.SetTriggeredInputAction
	void SetTriggeredInputAction(FDataTableRowHandle& InputActionRow);                                                       // [0xbe0ab0] Final|Native|Public|HasOutParms|BlueprintCallable 
	// Function /Script/CommonUI.CommonButtonBase.SetTouchMethod
	void SetTouchMethod(TEnumAsByte<EButtonTouchMethod> InTouchMethod);                                                      // [0xbe0a30] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonButtonBase.SetStyle
	void SetStyle(UClass* InStyle);                                                                                          // [0xbe09a0] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonButtonBase.SetShouldUseFallbackDefaultInputAction
	void SetShouldUseFallbackDefaultInputAction(bool bInShouldUseFallbackDefaultInputAction);                                // [0xbe0880] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonButtonBase.SetShouldSelectUponReceivingFocus
	void SetShouldSelectUponReceivingFocus(bool bInShouldSelectUponReceivingFocus);                                          // [0xbe07f0] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonButtonBase.SetSelectedInternal
	void SetSelectedInternal(bool bInSelected, bool bAllowSound, bool bBroadCast);                                           // [0xbe06c0] Final|Native|Protected|BlueprintCallable 
	// Function /Script/CommonUI.CommonButtonBase.SetPressMethod
	void SetPressMethod(TEnumAsByte<EButtonPressMethod> InPressMethod);                                                      // [0xbe05b0] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonButtonBase.SetPressedSoundOverride
	void SetPressedSoundOverride(USoundBase* Sound);                                                                         // [0xbe0630] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonButtonBase.SetMinDimensions
	void SetMinDimensions(int32_t InMinWidth, int32_t InMinHeight);                                                          // [0xbe04e0] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonButtonBase.SetIsToggleable
	void SetIsToggleable(bool bInIsToggleable);                                                                              // [0xbe0450] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonButtonBase.SetIsSelected
	void SetIsSelected(bool InSelected, bool bGiveClickFeedback);                                                            // [0xbe0380] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonButtonBase.SetIsSelectable
	void SetIsSelectable(bool bInIsSelectable);                                                                              // [0xbe02f0] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonButtonBase.SetIsInteractionEnabled
	void SetIsInteractionEnabled(bool bInIsInteractionEnabled);                                                              // [0xbe0260] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonButtonBase.SetIsInteractableWhenSelected
	void SetIsInteractableWhenSelected(bool bInInteractableWhenSelected);                                                    // [0xbe01d0] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonButtonBase.SetIsFocusable
	void SetIsFocusable(bool bInIsFocusable);                                                                                // [0xbe0140] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonButtonBase.SetInputActionProgressMaterial
	void SetInputActionProgressMaterial(FSlateBrush& InProgressMaterialBrush, FName& InProgressMaterialParam);               // [0xbdff40] Final|Native|Public|HasOutParms|BlueprintCallable 
	// Function /Script/CommonUI.CommonButtonBase.SetHoveredSoundOverride
	void SetHoveredSoundOverride(USoundBase* Sound);                                                                         // [0xbdfd60] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonButtonBase.SetClickMethod
	void SetClickMethod(TEnumAsByte<EButtonClickMethod> InClickMethod);                                                      // [0xbdfbc0] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonButtonBase.OnTriggeredInputActionChanged
	void OnTriggeredInputActionChanged(FDataTableRowHandle& NewTriggeredAction);                                             // [0x2d64c70] Event|Protected|HasOutParms|BlueprintEvent 
	// Function /Script/CommonUI.CommonButtonBase.OnInputMethodChanged
	void OnInputMethodChanged(ECommonInputType CurrentInputType);                                                            // [0xbdfab0] Native|Protected     
	// Function /Script/CommonUI.CommonButtonBase.OnCurrentTextStyleChanged
	void OnCurrentTextStyleChanged();                                                                                        // [0x2d64c70] Event|Protected|BlueprintEvent 
	// Function /Script/CommonUI.CommonButtonBase.OnActionProgress
	void OnActionProgress(float HeldPercent);                                                                                // [0x2d64c70] Event|Protected|BlueprintEvent 
	// Function /Script/CommonUI.CommonButtonBase.OnActionComplete
	void OnActionComplete();                                                                                                 // [0x2d64c70] Event|Protected|BlueprintEvent 
	// Function /Script/CommonUI.CommonButtonBase.NativeOnActionProgress
	void NativeOnActionProgress(float HeldPercent);                                                                          // [0xbdfa20] Native|Protected     
	// Function /Script/CommonUI.CommonButtonBase.NativeOnActionComplete
	void NativeOnActionComplete();                                                                                           // [0xbdfa00] Native|Protected     
	// Function /Script/CommonUI.CommonButtonBase.IsPressed
	bool IsPressed();                                                                                                        // [0xbdf9d0] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonBase.IsInteractionEnabled
	bool IsInteractionEnabled();                                                                                             // [0xbdf9a0] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonBase.HandleTriggeringActionCommited
	void HandleTriggeringActionCommited(bool& bPassThrough);                                                                 // [0xbdf880] Native|Protected|HasOutParms 
	// Function /Script/CommonUI.CommonButtonBase.HandleFocusReceived
	void HandleFocusReceived();                                                                                              // [0xbdf860] Native|Protected     
	// Function /Script/CommonUI.CommonButtonBase.HandleButtonReleased
	void HandleButtonReleased();                                                                                             // [0xbdf840] Final|Native|Protected 
	// Function /Script/CommonUI.CommonButtonBase.HandleButtonPressed
	void HandleButtonPressed();                                                                                              // [0xbdf820] Final|Native|Protected 
	// Function /Script/CommonUI.CommonButtonBase.HandleButtonClicked
	void HandleButtonClicked();                                                                                              // [0xbdf800] Final|Native|Protected 
	// Function /Script/CommonUI.CommonButtonBase.GetStyle
	UCommonButtonStyle* GetStyle();                                                                                          // [0xbdf7d0] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonBase.GetSingleMaterialStyleMID
	UMaterialInstanceDynamic* GetSingleMaterialStyleMID();                                                                   // [0xbdf7a0] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonBase.GetShouldSelectUponReceivingFocus
	bool GetShouldSelectUponReceivingFocus();                                                                                // [0xbdf770] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonBase.GetSelected
	bool GetSelected();                                                                                                      // [0xbdf4d0] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonBase.GetIsFocusable
	bool GetIsFocusable();                                                                                                   // [0xbdf230] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonBase.GetInputAction
	bool GetInputAction(FDataTableRowHandle& InputActionRow);                                                                // [0xbdf180] Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonBase.GetCurrentTextStyleClass
	UClass* GetCurrentTextStyleClass();                                                                                      // [0xbdeed0] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonBase.GetCurrentTextStyle
	UCommonTextStyle* GetCurrentTextStyle();                                                                                 // [0xbdeea0] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonBase.GetCurrentCustomPadding
	void GetCurrentCustomPadding(FMargin& OutCustomPadding);                                                                 // [0xbdee00] Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonBase.GetCurrentButtonPadding
	void GetCurrentButtonPadding(FMargin& OutButtonPadding);                                                                 // [0xbded60] Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonBase.DisableButtonWithReason
	void DisableButtonWithReason(FText& DisabledReason);                                                                     // [0xbdeb10] Final|Native|Public|HasOutParms|BlueprintCallable 
	// Function /Script/CommonUI.CommonButtonBase.ClearSelection
	void ClearSelection();                                                                                                   // [0xbdeab0] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonButtonBase.BP_OnUnhovered
	void BP_OnUnhovered();                                                                                                   // [0x2d64c70] Event|Protected|BlueprintEvent 
	// Function /Script/CommonUI.CommonButtonBase.BP_OnSelected
	void BP_OnSelected();                                                                                                    // [0x2d64c70] Event|Protected|BlueprintEvent 
	// Function /Script/CommonUI.CommonButtonBase.BP_OnHovered
	void BP_OnHovered();                                                                                                     // [0x2d64c70] Event|Protected|BlueprintEvent 
	// Function /Script/CommonUI.CommonButtonBase.BP_OnEnabled
	void BP_OnEnabled();                                                                                                     // [0x2d64c70] Event|Protected|BlueprintEvent 
	// Function /Script/CommonUI.CommonButtonBase.BP_OnDoubleClicked
	void BP_OnDoubleClicked();                                                                                               // [0x2d64c70] Event|Protected|BlueprintEvent 
	// Function /Script/CommonUI.CommonButtonBase.BP_OnDisabled
	void BP_OnDisabled();                                                                                                    // [0x2d64c70] Event|Protected|BlueprintEvent 
	// Function /Script/CommonUI.CommonButtonBase.BP_OnDeselected
	void BP_OnDeselected();                                                                                                  // [0x2d64c70] Event|Protected|BlueprintEvent 
	// Function /Script/CommonUI.CommonButtonBase.BP_OnClicked
	void BP_OnClicked();                                                                                                     // [0x2d64c70] Event|Protected|BlueprintEvent 
};

/// Class /Script/CommonUI.CommonBoundActionButton
/// Size: 0x0010 (0x000FE0 - 0x000FF0)
class UCommonBoundActionButton : public UCommonButtonBase
{ 
public:
	UCommonTextBlock*                                  Text_ActionName;                                            // 0x0FD8   (0x0008)  
	unsigned char                                      UnknownData00_6[0x10];                                      // 0x0FE0   (0x0010)  MISSED


	/// Functions
	// Function /Script/CommonUI.CommonBoundActionButton.OnUpdateInputAction
	void OnUpdateInputAction();                                                                                              // [0x2d64c70] Event|Protected|BlueprintEvent 
};

/// Class /Script/CommonUI.CommonButtonStyle
/// Size: 0x0808 (0x000028 - 0x000830)
class UCommonButtonStyle : public UObject
{ 
public:
	bool                                               bSingleMaterial;                                            // 0x0028   (0x0001)  
	unsigned char                                      UnknownData00_5[0x7];                                       // 0x0029   (0x0007)  MISSED
	FSlateBrush                                        SingleMaterialBrush;                                        // 0x0030   (0x00E0)  
	FSlateBrush                                        NormalBase;                                                 // 0x0110   (0x00E0)  
	FSlateBrush                                        NormalHovered;                                              // 0x01F0   (0x00E0)  
	FSlateBrush                                        NormalPressed;                                              // 0x02D0   (0x00E0)  
	FSlateBrush                                        SelectedBase;                                               // 0x03B0   (0x00E0)  
	FSlateBrush                                        SelectedHovered;                                            // 0x0490   (0x00E0)  
	FSlateBrush                                        SelectedPressed;                                            // 0x0570   (0x00E0)  
	FSlateBrush                                        Disabled;                                                   // 0x0650   (0x00E0)  
	FMargin                                            ButtonPadding;                                              // 0x0730   (0x0010)  
	FMargin                                            CustomPadding;                                              // 0x0740   (0x0010)  
	int32_t                                            MinWidth;                                                   // 0x0750   (0x0004)  
	int32_t                                            MinHeight;                                                  // 0x0754   (0x0004)  
	UClass*                                            NormalTextStyle;                                            // 0x0758   (0x0008)  
	UClass*                                            NormalHoveredTextStyle;                                     // 0x0760   (0x0008)  
	UClass*                                            SelectedTextStyle;                                          // 0x0768   (0x0008)  
	UClass*                                            SelectedHoveredTextStyle;                                   // 0x0770   (0x0008)  
	UClass*                                            DisabledTextStyle;                                          // 0x0778   (0x0008)  
	FSlateSound                                        PressedSlateSound;                                          // 0x0780   (0x0018)  
	FCommonButtonStyleOptionalSlateSound               SelectedPressedSlateSound;                                  // 0x0798   (0x0020)  
	FCommonButtonStyleOptionalSlateSound               DisabledPressedSlateSound;                                  // 0x07B8   (0x0020)  
	FSlateSound                                        HoveredSlateSound;                                          // 0x07D8   (0x0018)  
	FCommonButtonStyleOptionalSlateSound               SelectedHoveredSlateSound;                                  // 0x07F0   (0x0020)  
	FCommonButtonStyleOptionalSlateSound               DisabledHoveredSlateSound;                                  // 0x0810   (0x0020)  


	/// Functions
	// Function /Script/CommonUI.CommonButtonStyle.GetSelectedTextStyle
	UCommonTextStyle* GetSelectedTextStyle();                                                                                // [0xbdf740] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonStyle.GetSelectedPressedBrush
	void GetSelectedPressedBrush(FSlateBrush& Brush);                                                                        // [0xbdf690] Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonStyle.GetSelectedHoveredTextStyle
	UCommonTextStyle* GetSelectedHoveredTextStyle();                                                                         // [0xbdf660] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonStyle.GetSelectedHoveredBrush
	void GetSelectedHoveredBrush(FSlateBrush& Brush);                                                                        // [0xbdf5b0] Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonStyle.GetSelectedBaseBrush
	void GetSelectedBaseBrush(FSlateBrush& Brush);                                                                           // [0xbdf500] Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonStyle.GetNormalTextStyle
	UCommonTextStyle* GetNormalTextStyle();                                                                                  // [0xbdf4a0] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonStyle.GetNormalPressedBrush
	void GetNormalPressedBrush(FSlateBrush& Brush);                                                                          // [0xbdf3f0] Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonStyle.GetNormalHoveredTextStyle
	UCommonTextStyle* GetNormalHoveredTextStyle();                                                                           // [0xbdf3c0] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonStyle.GetNormalHoveredBrush
	void GetNormalHoveredBrush(FSlateBrush& Brush);                                                                          // [0xbdf310] Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonStyle.GetNormalBaseBrush
	void GetNormalBaseBrush(FSlateBrush& Brush);                                                                             // [0xbdf260] Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonStyle.GetMaterialBrush
	void GetMaterialBrush(FSlateBrush& Brush);                                                                               // [0xbdec10] Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonStyle.GetDisabledTextStyle
	UCommonTextStyle* GetDisabledTextStyle();                                                                                // [0xbdf060] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonStyle.GetDisabledBrush
	void GetDisabledBrush(FSlateBrush& Brush);                                                                               // [0xbdefb0] Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonStyle.GetCustomPadding
	void GetCustomPadding(FMargin& OutCustomPadding);                                                                        // [0xbdef10] Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonStyle.GetButtonPadding
	void GetButtonPadding(FMargin& OutButtonPadding);                                                                        // [0xbdecc0] Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const 
};

/// Class /Script/CommonUI.CommonButtonInternalBase
/// Size: 0x0060 (0x0005D0 - 0x000630)
class UCommonButtonInternalBase : public UButton
{ 
public:
	unsigned char                                      UnknownData00_2[0x8];                                       // 0x05D0   (0x0008)  MISSED
	FMulticastInlineDelegate                           OnDoubleClicked;                                            // 0x05D8   (0x0010)  
	unsigned char                                      UnknownData01_5[0x10];                                      // 0x05E8   (0x0010)  MISSED
	int32_t                                            MinWidth;                                                   // 0x05F8   (0x0004)  
	int32_t                                            MinHeight;                                                  // 0x05FC   (0x0004)  
	bool                                               bButtonEnabled;                                             // 0x0600   (0x0001)  
	bool                                               bInteractionEnabled;                                        // 0x0601   (0x0001)  
	unsigned char                                      UnknownData02_6[0x2E];                                      // 0x0602   (0x002E)  MISSED
};

/// Class /Script/CommonUI.CommonWidgetGroupBase
/// Size: 0x0000 (0x000028 - 0x000028)
class UCommonWidgetGroupBase : public UObject
{ 
public:
};

/// Class /Script/CommonUI.CommonButtonGroupBase
/// Size: 0x00E8 (0x000028 - 0x000110)
class UCommonButtonGroupBase : public UCommonWidgetGroupBase
{ 
public:
	FMulticastInlineDelegate                           OnSelectedButtonBaseChanged;                                // 0x0028   (0x0010)  
	unsigned char                                      UnknownData00_5[0x18];                                      // 0x0038   (0x0018)  MISSED
	FMulticastInlineDelegate                           OnHoveredButtonBaseChanged;                                 // 0x0050   (0x0010)  
	unsigned char                                      UnknownData01_5[0x18];                                      // 0x0060   (0x0018)  MISSED
	FMulticastInlineDelegate                           OnButtonBaseClicked;                                        // 0x0078   (0x0010)  
	unsigned char                                      UnknownData02_5[0x18];                                      // 0x0088   (0x0018)  MISSED
	FMulticastInlineDelegate                           OnButtonBaseDoubleClicked;                                  // 0x00A0   (0x0010)  
	unsigned char                                      UnknownData03_5[0x18];                                      // 0x00B0   (0x0018)  MISSED
	FMulticastInlineDelegate                           OnSelectionCleared;                                         // 0x00C8   (0x0010)  
	unsigned char                                      UnknownData04_5[0x18];                                      // 0x00D8   (0x0018)  MISSED
	bool                                               bSelectionRequired;                                         // 0x00F0   (0x0001)  
	unsigned char                                      UnknownData05_6[0x1F];                                      // 0x00F1   (0x001F)  MISSED


	/// Functions
	// Function /Script/CommonUI.CommonButtonGroupBase.SetSelectionRequired
	void SetSelectionRequired(bool bRequireSelection);                                                                       // [0xbe5f10] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonButtonGroupBase.SelectPreviousButton
	void SelectPreviousButton(bool bAllowWrap);                                                                              // [0xbe51a0] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonButtonGroupBase.SelectNextButton
	void SelectNextButton(bool bAllowWrap);                                                                                  // [0xbe5110] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonButtonGroupBase.SelectButtonAtIndex
	void SelectButtonAtIndex(int32_t ButtonIndex);                                                                           // [0xbe5080] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonButtonGroupBase.OnSelectionStateChangedBase
	void OnSelectionStateChangedBase(UCommonButtonBase* BaseButton, bool bIsSelected);                                       // [0xbe4c70] Native|Protected     
	// Function /Script/CommonUI.CommonButtonGroupBase.OnHandleButtonBaseDoubleClicked
	void OnHandleButtonBaseDoubleClicked(UCommonButtonBase* BaseButton);                                                     // [0xbe4bc0] Native|Protected     
	// Function /Script/CommonUI.CommonButtonGroupBase.OnHandleButtonBaseClicked
	void OnHandleButtonBaseClicked(UCommonButtonBase* BaseButton);                                                           // [0xbe4b30] Native|Protected     
	// Function /Script/CommonUI.CommonButtonGroupBase.OnButtonBaseUnhovered
	void OnButtonBaseUnhovered(UCommonButtonBase* BaseButton);                                                               // [0xbe4aa0] Native|Protected     
	// Function /Script/CommonUI.CommonButtonGroupBase.OnButtonBaseHovered
	void OnButtonBaseHovered(UCommonButtonBase* BaseButton);                                                                 // [0xbe4a10] Native|Protected     
	// Function /Script/CommonUI.CommonButtonGroupBase.HasAnyButtons
	bool HasAnyButtons();                                                                                                    // [0xbe47a0] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonGroupBase.GetSelectedButtonIndex
	int32_t GetSelectedButtonIndex();                                                                                        // [0xbe4150] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonGroupBase.GetSelectedButtonBase
	UCommonButtonBase* GetSelectedButtonBase();                                                                              // [0xbe4120] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonGroupBase.GetHoveredButtonIndex
	int32_t GetHoveredButtonIndex();                                                                                         // [0xbe40c0] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonGroupBase.GetButtonCount
	int32_t GetButtonCount();                                                                                                // [0xbe4030] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonGroupBase.GetButtonBaseAtIndex
	UCommonButtonBase* GetButtonBaseAtIndex(int32_t Index);                                                                  // [0xbe3f90] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonGroupBase.FindButtonIndex
	int32_t FindButtonIndex(UCommonButtonBase* ButtonToFind);                                                                // [0xbe3ed0] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonButtonGroupBase.DeselectAll
	void DeselectAll();                                                                                                      // [0xbe3da0] Final|Native|Public|BlueprintCallable 
};

/// Class /Script/CommonUI.CommonCustomNavigation
/// Size: 0x0010 (0x000300 - 0x000310)
class UCommonCustomNavigation : public UBorder
{ 
public:
	FDelegateProperty                                  OnNavigationEvent;                                          // 0x0300   (0x0010)  
};

/// Class /Script/CommonUI.CommonTextBlock
/// Size: 0x0030 (0x000420 - 0x000450)
class UCommonTextBlock : public UTextBlock
{ 
public:
	UClass*                                            Style;                                                      // 0x0420   (0x0008)  
	UClass*                                            ScrollStyle;                                                // 0x0428   (0x0008)  
	bool                                               bDisplayAllCaps;                                            // 0x0430   (0x0001)  
	bool                                               bAutoCollapseWithEmptyText;                                 // 0x0431   (0x0001)  
	unsigned char                                      UnknownData00_5[0x2];                                       // 0x0432   (0x0002)  MISSED
	float                                              MobileFontSizeMultiplier;                                   // 0x0434   (0x0004)  
	unsigned char                                      UnknownData01_6[0x18];                                      // 0x0438   (0x0018)  MISSED


	/// Functions
	// Function /Script/CommonUI.CommonTextBlock.SetWrapTextWidth
	void SetWrapTextWidth(int32_t InWrapTextAt);                                                                             // [0xbeae70] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonTextBlock.SetTextCase
	void SetTextCase(bool bUseAllCaps);                                                                                      // [0xbeade0] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonTextBlock.SetStyle
	void SetStyle(UClass* InStyle);                                                                                          // [0xbead50] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonTextBlock.ResetScrollState
	void ResetScrollState();                                                                                                 // [0xbea9d0] Final|Native|Public|BlueprintCallable 
};

/// Class /Script/CommonUI.CommonDateTimeTextBlock
/// Size: 0x0040 (0x000450 - 0x000490)
class UCommonDateTimeTextBlock : public UCommonTextBlock
{ 
public:
	unsigned char                                      UnknownData00_1[0x40];                                      // 0x0450   (0x0040)  MISSED
};

/// Class /Script/CommonUI.CommonGameViewportClient
/// Size: 0x0040 (0x000330 - 0x000370)
class UCommonGameViewportClient : public UGameViewportClient
{ 
public:
	unsigned char                                      UnknownData00_1[0x40];                                      // 0x0330   (0x0040)  MISSED
};

/// Class /Script/CommonUI.CommonHierarchicalScrollBox
/// Size: 0x0000 (0x000D40 - 0x000D40)
class UCommonHierarchicalScrollBox : public UScrollBox
{ 
public:
};

/// Class /Script/CommonUI.CommonLazyImage
/// Size: 0x0120 (0x0002A0 - 0x0003C0)
class UCommonLazyImage : public UImage
{ 
public:
	FSlateBrush                                        LoadingBackgroundBrush;                                     // 0x02A0   (0x00E0)  
	FName                                              MaterialTextureParamName;                                   // 0x0380   (0x0008)  
	FMulticastInlineDelegate                           BP_OnLoadingStateChanged;                                   // 0x0388   (0x0010)  
	unsigned char                                      UnknownData00_6[0x28];                                      // 0x0398   (0x0028)  MISSED


	/// Functions
	// Function /Script/CommonUI.CommonLazyImage.SetMaterialTextureParamName
	void SetMaterialTextureParamName(FName TextureParamName);                                                                // [0xbe5ce0] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonLazyImage.SetBrushFromLazyTexture
	void SetBrushFromLazyTexture(TWeakObjectPtr<UTexture2D*>& LazyTexture, bool bMatchSize);                                 // [0xbe54d0] Final|Native|Public|HasOutParms|BlueprintCallable 
	// Function /Script/CommonUI.CommonLazyImage.SetBrushFromLazyMaterial
	void SetBrushFromLazyMaterial(TWeakObjectPtr<UMaterialInterface*>& LazyMaterial);                                        // [0xbe5410] Final|Native|Public|HasOutParms|BlueprintCallable 
	// Function /Script/CommonUI.CommonLazyImage.SetBrushFromLazyDisplayAsset
	void SetBrushFromLazyDisplayAsset(TWeakObjectPtr<UObject*>& LazyObject, bool bMatchTextureSize);                         // [0xbe5300] Final|Native|Public|HasOutParms|BlueprintCallable 
	// Function /Script/CommonUI.CommonLazyImage.IsLoading
	bool IsLoading();                                                                                                        // [0xbe4960] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
};

/// Class /Script/CommonUI.CommonLazyWidget
/// Size: 0x0168 (0x000138 - 0x0002A0)
class UCommonLazyWidget : public UWidget
{ 
public:
	unsigned char                                      UnknownData00_2[0x8];                                       // 0x0138   (0x0008)  MISSED
	FSlateBrush                                        LoadingBackgroundBrush;                                     // 0x0140   (0x00E0)  
	UUserWidget*                                       Content;                                                    // 0x0220   (0x0008)  
	unsigned char                                      UnknownData01_5[0x28];                                      // 0x0228   (0x0028)  MISSED
	FMulticastInlineDelegate                           BP_OnLoadingStateChanged;                                   // 0x0250   (0x0010)  
	unsigned char                                      UnknownData02_6[0x40];                                      // 0x0260   (0x0040)  MISSED


	/// Functions
	// Function /Script/CommonUI.CommonLazyWidget.SetLazyContent
	void SetLazyContent(TWeakObjectPtr<UClass*> SoftWidget);                                                                 // [0xbe59e0] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonLazyWidget.IsLoading
	bool IsLoading();                                                                                                        // [0xbe4990] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonLazyWidget.GetContent
	UUserWidget* GetContent();                                                                                               // [0xbe4060] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
};

/// Class /Script/CommonUI.CommonListView
/// Size: 0x0000 (0x000BF0 - 0x000BF0)
class UCommonListView : public UListView
{ 
public:
};

/// Class /Script/CommonUI.LoadGuardSlot
/// Size: 0x0028 (0x000038 - 0x000060)
class ULoadGuardSlot : public UPanelSlot
{ 
public:
	FMargin                                            Padding;                                                    // 0x0038   (0x0010)  
	TEnumAsByte<EHorizontalAlignment>                  HorizontalAlignment;                                        // 0x0048   (0x0001)  
	TEnumAsByte<EVerticalAlignment>                    VerticalAlignment;                                          // 0x0049   (0x0001)  
	unsigned char                                      UnknownData00_6[0x16];                                      // 0x004A   (0x0016)  MISSED


	/// Functions
	// Function /Script/CommonUI.LoadGuardSlot.SetVerticalAlignment
	void SetVerticalAlignment(TEnumAsByte<EVerticalAlignment> InVerticalAlignment);                                          // [0xbe6290] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.LoadGuardSlot.SetPadding
	void SetPadding(FMargin InPadding);                                                                                      // [0xbe5df0] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.LoadGuardSlot.SetHorizontalAlignment
	void SetHorizontalAlignment(TEnumAsByte<EHorizontalAlignment> InHorizontalAlignment);                                    // [0xbe58d0] Final|Native|Public|BlueprintCallable 
};

/// Class /Script/CommonUI.CommonLoadGuard
/// Size: 0x0170 (0x000150 - 0x0002C0)
class UCommonLoadGuard : public UContentWidget
{ 
public:
	FSlateBrush                                        LoadingBackgroundBrush;                                     // 0x0150   (0x00E0)  
	TEnumAsByte<EHorizontalAlignment>                  ThrobberAlignment;                                          // 0x0230   (0x0001)  
	unsigned char                                      UnknownData00_5[0x3];                                       // 0x0231   (0x0003)  MISSED
	FMargin                                            ThrobberPadding;                                            // 0x0234   (0x0010)  
	unsigned char                                      UnknownData01_5[0x4];                                       // 0x0244   (0x0004)  MISSED
	FText                                              LoadingText;                                                // 0x0248   (0x0018)  
	UClass*                                            TextStyle;                                                  // 0x0260   (0x0008)  
	FMulticastInlineDelegate                           BP_OnLoadingStateChanged;                                   // 0x0268   (0x0010)  
	FSoftObjectPath                                    SpinnerMaterialPath;                                        // 0x0278   (0x0018)  
	unsigned char                                      UnknownData02_6[0x30];                                      // 0x0290   (0x0030)  MISSED


	/// Functions
	// Function /Script/CommonUI.CommonLoadGuard.SetLoadingText
	void SetLoadingText(FText& InLoadingText);                                                                               // [0xbe5c10] Final|Native|Public|HasOutParms|BlueprintCallable 
	// Function /Script/CommonUI.CommonLoadGuard.SetIsLoading
	void SetIsLoading(bool bInIsLoading);                                                                                    // [0xbe5950] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonLoadGuard.OnAssetLoaded__DelegateSignature
	void OnAssetLoaded__DelegateSignature(UObject* Object);                                                                  // [0x2d64c70] Public|Delegate      
	// Function /Script/CommonUI.CommonLoadGuard.IsLoading
	bool IsLoading();                                                                                                        // [0xbe49c0] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonLoadGuard.BP_GuardAndLoadAsset
	void BP_GuardAndLoadAsset(TWeakObjectPtr<UObject*>& InLazyAsset, FDelegateProperty& OnAssetLoaded);                      // [0xbe3c70] Final|Native|Private|HasOutParms|BlueprintCallable 
};

/// Class /Script/CommonUI.CommonNumericTextBlock
/// Size: 0x00A0 (0x000450 - 0x0004F0)
class UCommonNumericTextBlock : public UCommonTextBlock
{ 
public:
	FMulticastInlineDelegate                           OnInterpolationStartedEvent;                                // 0x0448   (0x0010)  
	FMulticastInlineDelegate                           OnInterpolationUpdatedEvent;                                // 0x0458   (0x0010)  
	FMulticastInlineDelegate                           OnOutroEvent;                                               // 0x0468   (0x0010)  
	FMulticastInlineDelegate                           OnInterpolationEndedEvent;                                  // 0x0478   (0x0010)  
	float                                              CurrentNumericValue;                                        // 0x0488   (0x0004)  
	ECommonNumericType                                 NumericType;                                                // 0x048C   (0x0001)  
	unsigned char                                      UnknownData00_5[0x3];                                       // 0x048D   (0x0003)  MISSED
	FCommonNumberFormattingOptions                     FormattingSpecification;                                    // 0x0490   (0x0014)  
	float                                              EaseOutInterpolationExponent;                               // 0x04A4   (0x0004)  
	float                                              InterpolationUpdateInterval;                                // 0x04A8   (0x0004)  
	float                                              PostInterpolationShrinkDuration;                            // 0x04AC   (0x0004)  
	bool                                               PerformSizeInterpolation;                                   // 0x04B0   (0x0001)  
	bool                                               IsPercentage;                                               // 0x04B1   (0x0001)  
	unsigned char                                      UnknownData01_6[0x3E];                                      // 0x04B2   (0x003E)  MISSED


	/// Functions
	// Function /Script/CommonUI.CommonNumericTextBlock.SetNumericType
	void SetNumericType(ECommonNumericType InNumericType);                                                                   // [0xbe5d70] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonNumericTextBlock.SetCurrentValue
	void SetCurrentValue(float NewValue);                                                                                    // [0xbe56c0] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonNumericTextBlock.OnOutro__DelegateSignature
	void OnOutro__DelegateSignature(UCommonNumericTextBlock* NumericTextBlock);                                              // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/CommonUI.CommonNumericTextBlock.OnInterpolationUpdated__DelegateSignature
	void OnInterpolationUpdated__DelegateSignature(UCommonNumericTextBlock* NumericTextBlock, float LastValue, float NewValue); // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/CommonUI.CommonNumericTextBlock.OnInterpolationStarted__DelegateSignature
	void OnInterpolationStarted__DelegateSignature(UCommonNumericTextBlock* NumericTextBlock);                               // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/CommonUI.CommonNumericTextBlock.OnInterpolationEnded__DelegateSignature
	void OnInterpolationEnded__DelegateSignature(UCommonNumericTextBlock* NumericTextBlock, bool HadCompleted);              // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/CommonUI.CommonNumericTextBlock.IsInterpolatingNumericValue
	bool IsInterpolatingNumericValue();                                                                                      // [0xbe4930] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonNumericTextBlock.InterpolateToValue
	void InterpolateToValue(float TargetValue, float MaximumInterpolationDuration, float MinimumChangeRate, float OutroOffset); // [0xbe47d0] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonNumericTextBlock.GetTargetValue
	float GetTargetValue();                                                                                                  // [0xbe43e0] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
};

/// Class /Script/CommonUI.CommonPoolableWidgetInterface
/// Size: 0x0000 (0x000028 - 0x000028)
class UCommonPoolableWidgetInterface : public UInterface
{ 
public:
};

/// Class /Script/CommonUI.CommonRichTextBlock
/// Size: 0x0040 (0x000AA0 - 0x000AE0)
class UCommonRichTextBlock : public URichTextBlock
{ 
public:
	ERichTextInlineIconDisplayMode                     InlineIconDisplayMode;                                      // 0x0AA0   (0x0001)  
	bool                                               bTintInlineIcon;                                            // 0x0AA1   (0x0001)  
	unsigned char                                      UnknownData00_5[0x6];                                       // 0x0AA2   (0x0006)  MISSED
	UClass*                                            DefaultTextStyleOverrideClass;                              // 0x0AA8   (0x0008)  
	float                                              MobileTextBlockScale;                                       // 0x0AB0   (0x0004)  
	unsigned char                                      UnknownData01_5[0x4];                                       // 0x0AB4   (0x0004)  MISSED
	UClass*                                            ScrollStyle;                                                // 0x0AB8   (0x0008)  
	bool                                               bDisplayAllCaps;                                            // 0x0AC0   (0x0001)  
	unsigned char                                      UnknownData02_6[0x1F];                                      // 0x0AC1   (0x001F)  MISSED
};

/// Class /Script/CommonUI.CommonRotator
/// Size: 0x0050 (0x000FE0 - 0x001030)
class UCommonRotator : public UCommonButtonBase
{ 
public:
	unsigned char                                      UnknownData00_2[0x8];                                       // 0x0FE0   (0x0008)  MISSED
	FMulticastInlineDelegate                           OnRotated;                                                  // 0x0FE8   (0x0010)  
	unsigned char                                      UnknownData01_5[0x18];                                      // 0x0FF8   (0x0018)  MISSED
	UCommonTextBlock*                                  MyText;                                                     // 0x1010   (0x0008)  
	unsigned char                                      UnknownData02_6[0x18];                                      // 0x1018   (0x0018)  MISSED


	/// Functions
	// Function /Script/CommonUI.CommonRotator.ShiftTextRight
	void ShiftTextRight();                                                                                                   // [0xbe6330] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonRotator.ShiftTextLeft
	void ShiftTextLeft();                                                                                                    // [0xbe6310] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonRotator.SetSelectedItem
	void SetSelectedItem(int32_t InValue);                                                                                   // [0xbe5e80] Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonRotator.PopulateTextLabels
	void PopulateTextLabels(TArray<FText> Labels);                                                                           // [0xbe4d40] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonRotator.GetSelectedText
	FText GetSelectedText();                                                                                                 // [0xbe41e0] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonRotator.GetSelectedIndex
	int32_t GetSelectedIndex();                                                                                              // [0xbe4180] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonRotator.BP_OnOptionsPopulated
	void BP_OnOptionsPopulated(int32_t count);                                                                               // [0x2d64c70] Event|Protected|BlueprintEvent 
	// Function /Script/CommonUI.CommonRotator.BP_OnOptionSelected
	void BP_OnOptionSelected(int32_t Index);                                                                                 // [0x2d64c70] Event|Protected|BlueprintEvent 
};

/// Class /Script/CommonUI.CommonTabListWidgetBase
/// Size: 0x00D0 (0x000288 - 0x000358)
class UCommonTabListWidgetBase : public UCommonUserWidget
{ 
public:
	FMulticastInlineDelegate                           OnTabSelected;                                              // 0x0288   (0x0010)  
	FMulticastInlineDelegate                           OnTabButtonCreation;                                        // 0x0298   (0x0010)  
	FMulticastInlineDelegate                           OnTabButtonRemoval;                                         // 0x02A8   (0x0010)  
	FDataTableRowHandle                                NextTabInputActionData;                                     // 0x02B8   (0x0010)  
	FDataTableRowHandle                                PreviousTabInputActionData;                                 // 0x02C8   (0x0010)  
	bool                                               bAutoListenForInput;                                        // 0x02D8   (0x0001)  
	unsigned char                                      UnknownData00_5[0x3];                                       // 0x02D9   (0x0003)  MISSED
	TWeakObjectPtr<UCommonAnimatedSwitcher*>           LinkedSwitcher;                                             // 0x02DC   (0x0008)  
	unsigned char                                      UnknownData01_5[0x4];                                       // 0x02E4   (0x0004)  MISSED
	UCommonButtonGroupBase*                            TabButtonGroup;                                             // 0x02E8   (0x0008)  
	unsigned char                                      UnknownData02_5[0x8];                                       // 0x02F0   (0x0008)  MISSED
	TMap<FName, FCommonRegisteredTabInfo>              RegisteredTabsByID;                                         // 0x02F8   (0x0050)  
	unsigned char                                      UnknownData03_6[0x10];                                      // 0x0348   (0x0010)  MISSED


	/// Functions
	// Function /Script/CommonUI.CommonTabListWidgetBase.SetTabVisibility
	void SetTabVisibility(FName TabNameID, ESlateVisibility NewVisibility);                                                  // [0xbe6140] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonTabListWidgetBase.SetTabInteractionEnabled
	void SetTabInteractionEnabled(FName TabNameID, bool bEnable);                                                            // [0xbe6070] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonTabListWidgetBase.SetTabEnabled
	void SetTabEnabled(FName TabNameID, bool bEnable);                                                                       // [0xbe5fa0] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonTabListWidgetBase.SetListeningForInput
	void SetListeningForInput(bool bShouldListen);                                                                           // [0xbe5b80] Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonTabListWidgetBase.SetLinkedSwitcher
	void SetLinkedSwitcher(UCommonAnimatedSwitcher* CommonSwitcher);                                                         // [0xbe5af0] Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonTabListWidgetBase.SelectTabByID
	bool SelectTabByID(FName TabNameID, bool bSuppressClickFeedback);                                                        // [0xbe5230] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonTabListWidgetBase.RemoveTab
	bool RemoveTab(FName TabNameID);                                                                                         // [0xbe4fe0] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonTabListWidgetBase.RemoveAllTabs
	void RemoveAllTabs();                                                                                                    // [0xbe4fc0] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonTabListWidgetBase.RegisterTab
	bool RegisterTab(FName TabNameID, UClass* ButtonWidgetType, UWidget* ContentWidget);                                     // [0xbe4eb0] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonTabListWidgetBase.OnTabSelected__DelegateSignature
	void OnTabSelected__DelegateSignature(FName TabId);                                                                      // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/CommonUI.CommonTabListWidgetBase.OnTabButtonRemoval__DelegateSignature
	void OnTabButtonRemoval__DelegateSignature(FName TabId, UCommonButtonBase* TabButton);                                   // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/CommonUI.CommonTabListWidgetBase.OnTabButtonCreation__DelegateSignature
	void OnTabButtonCreation__DelegateSignature(FName TabId, UCommonButtonBase* TabButton);                                  // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/CommonUI.CommonTabListWidgetBase.HandleTabRemoval
	void HandleTabRemoval(FName TabNameID, UCommonButtonBase* TabButton);                                                    // [0xbe46d0] Native|Event|Protected|BlueprintEvent 
	// Function /Script/CommonUI.CommonTabListWidgetBase.HandleTabCreation
	void HandleTabCreation(FName TabNameID, UCommonButtonBase* TabButton);                                                   // [0xbe4600] Native|Event|Protected|BlueprintEvent 
	// Function /Script/CommonUI.CommonTabListWidgetBase.HandleTabButtonSelected
	void HandleTabButtonSelected(UCommonButtonBase* SelectedTabButton, int32_t ButtonIndex);                                 // [0xbe4530] Final|Native|Protected 
	// Function /Script/CommonUI.CommonTabListWidgetBase.HandlePreviousTabInputAction
	void HandlePreviousTabInputAction(bool& bPassThrough);                                                                   // [0xbe44a0] Final|Native|Protected|HasOutParms 
	// Function /Script/CommonUI.CommonTabListWidgetBase.HandlePreLinkedSwitcherChanged_BP
	void HandlePreLinkedSwitcherChanged_BP();                                                                                // [0x2d64c70] Event|Protected|BlueprintEvent 
	// Function /Script/CommonUI.CommonTabListWidgetBase.HandlePostLinkedSwitcherChanged_BP
	void HandlePostLinkedSwitcherChanged_BP();                                                                               // [0x2d64c70] Event|Protected|BlueprintEvent 
	// Function /Script/CommonUI.CommonTabListWidgetBase.HandleNextTabInputAction
	void HandleNextTabInputAction(bool& bPassThrough);                                                                       // [0xbe4410] Final|Native|Protected|HasOutParms 
	// Function /Script/CommonUI.CommonTabListWidgetBase.GetTabIdAtIndex
	FName GetTabIdAtIndex(int32_t Index);                                                                                    // [0xbe4350] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonTabListWidgetBase.GetTabCount
	int32_t GetTabCount();                                                                                                   // [0xbe4320] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonTabListWidgetBase.GetTabButtonBaseByID
	UCommonButtonBase* GetTabButtonBaseByID(FName TabNameID);                                                                // [0xbe4280] Final|Native|Protected|BlueprintCallable 
	// Function /Script/CommonUI.CommonTabListWidgetBase.GetSelectedTabId
	FName GetSelectedTabId();                                                                                                // [0xbe41a0] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonTabListWidgetBase.GetLinkedSwitcher
	UCommonAnimatedSwitcher* GetLinkedSwitcher();                                                                            // [0xbe40f0] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonTabListWidgetBase.GetActiveTab
	FName GetActiveTab();                                                                                                    // [0xbe3f70] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonTabListWidgetBase.DisableTabWithReason
	void DisableTabWithReason(FName TabNameID, FText& reason);                                                               // [0xbe3dc0] Final|Native|Public|HasOutParms|BlueprintCallable 
};

/// Class /Script/CommonUI.CommonTextStyle
/// Size: 0x0198 (0x000028 - 0x0001C0)
class UCommonTextStyle : public UObject
{ 
public:
	FSlateFontInfo                                     Font;                                                       // 0x0028   (0x0060)  
	FLinearColor                                       Color;                                                      // 0x0088   (0x0010)  
	bool                                               bUsesDropShadow;                                            // 0x0098   (0x0001)  
	unsigned char                                      UnknownData00_5[0x3];                                       // 0x0099   (0x0003)  MISSED
	FVector2D                                          ShadowOffset;                                               // 0x009C   (0x0008)  
	FLinearColor                                       ShadowColor;                                                // 0x00A4   (0x0010)  
	FMargin                                            Margin;                                                     // 0x00B4   (0x0010)  
	unsigned char                                      UnknownData01_5[0xC];                                       // 0x00C4   (0x000C)  MISSED
	FSlateBrush                                        StrikeBrush;                                                // 0x00D0   (0x00E0)  
	float                                              LineHeightPercentage;                                       // 0x01B0   (0x0004)  
	unsigned char                                      UnknownData02_6[0xC];                                       // 0x01B4   (0x000C)  MISSED


	/// Functions
	// Function /Script/CommonUI.CommonTextStyle.GetStrikeBrush
	void GetStrikeBrush(FSlateBrush& OutStrikeBrush);                                                                        // [0xbea560] Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonTextStyle.GetShadowOffset
	void GetShadowOffset(FVector2D& OutShadowOffset);                                                                        // [0xbea4d0] Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonTextStyle.GetShadowColor
	void GetShadowColor(FLinearColor& OutColor);                                                                             // [0xbea440] Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonTextStyle.GetMargin
	void GetMargin(FMargin& OutMargin);                                                                                      // [0xbea310] Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonTextStyle.GetLineHeightPercentage
	float GetLineHeightPercentage();                                                                                         // [0xbea2e0] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonTextStyle.GetFont
	void GetFont(FSlateFontInfo& OutFont);                                                                                   // [0xbea090] Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonTextStyle.GetColor
	void GetColor(FLinearColor& OutColor);                                                                                   // [0xbea000] Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const 
};

/// Class /Script/CommonUI.CommonTextScrollStyle
/// Size: 0x0018 (0x000028 - 0x000040)
class UCommonTextScrollStyle : public UObject
{ 
public:
	float                                              Speed;                                                      // 0x0028   (0x0004)  
	float                                              StartDelay;                                                 // 0x002C   (0x0004)  
	float                                              EndDelay;                                                   // 0x0030   (0x0004)  
	float                                              FadeInDelay;                                                // 0x0034   (0x0004)  
	float                                              FadeOutDelay;                                               // 0x0038   (0x0004)  
	unsigned char                                      UnknownData00_6[0x4];                                       // 0x003C   (0x0004)  MISSED
};

/// Class /Script/CommonUI.CommonTileView
/// Size: 0x0000 (0x000C10 - 0x000C10)
class UCommonTileView : public UTileView
{ 
public:
};

/// Class /Script/CommonUI.CommonTreeView
/// Size: 0x0000 (0x000C50 - 0x000C50)
class UCommonTreeView : public UTreeView
{ 
public:
};

/// Class /Script/CommonUI.CommonUIActionRouterBase
/// Size: 0x00D0 (0x000030 - 0x000100)
class UCommonUIActionRouterBase : public ULocalPlayerSubsystem
{ 
public:
	unsigned char                                      UnknownData00_1[0xD0];                                      // 0x0030   (0x00D0)  MISSED
};

/// Class /Script/CommonUI.CommonUIEditorSettings
/// Size: 0x0080 (0x000028 - 0x0000A8)
class UCommonUIEditorSettings : public UObject
{ 
public:
	TWeakObjectPtr<UClass*>                            TemplateTextStyle;                                          // 0x0028   (0x0028)  
	TWeakObjectPtr<UClass*>                            TemplateButtonStyle;                                        // 0x0050   (0x0028)  
	TWeakObjectPtr<UClass*>                            TemplateBorderStyle;                                        // 0x0078   (0x0028)  
	unsigned char                                      UnknownData00_6[0x8];                                       // 0x00A0   (0x0008)  MISSED
};

/// Class /Script/CommonUI.CommonUIInputSettings
/// Size: 0x0050 (0x000028 - 0x000078)
class UCommonUIInputSettings : public UObject
{ 
public:
	bool                                               bLinkCursorToGamepadFocus;                                  // 0x0028   (0x0001)  
	unsigned char                                      UnknownData00_5[0x3];                                       // 0x0029   (0x0003)  MISSED
	int32_t                                            UIActionProcessingPriority;                                 // 0x002C   (0x0004)  
	TArray<FUIInputAction>                             InputActions;                                               // 0x0030   (0x0010)  
	TArray<FUIInputAction>                             ActionOverrides;                                            // 0x0040   (0x0010)  
	FCommonAnalogCursorSettings                        AnalogCursorSettings;                                       // 0x0050   (0x0028)  
};

/// Class /Script/CommonUI.CommonUILibrary
/// Size: 0x0000 (0x000028 - 0x000028)
class UCommonUILibrary : public UBlueprintFunctionLibrary
{ 
public:
};

/// Class /Script/CommonUI.CommonUIRichTextData
/// Size: 0x0008 (0x000028 - 0x000030)
class UCommonUIRichTextData : public UObject
{ 
public:
	UDataTable*                                        InlineIconSet;                                              // 0x0028   (0x0008)  
};

/// Class /Script/CommonUI.CommonUISettings
/// Size: 0x0188 (0x000028 - 0x0001B0)
class UCommonUISettings : public UObject
{ 
public:
	bool                                               bAutoLoadData;                                              // 0x0028   (0x0001)  
	unsigned char                                      UnknownData00_5[0x7];                                       // 0x0029   (0x0007)  MISSED
	TWeakObjectPtr<UObject*>                           DefaultImageResourceObject;                                 // 0x0030   (0x0028)  
	TWeakObjectPtr<UMaterialInterface*>                DefaultThrobberMaterial;                                    // 0x0058   (0x0028)  
	TWeakObjectPtr<UClass*>                            DefaultRichTextDataClass;                                   // 0x0080   (0x0028)  
	unsigned char                                      UnknownData01_5[0x8];                                       // 0x00A8   (0x0008)  MISSED
	UObject*                                           DefaultImageResourceObjectInstance;                         // 0x00B0   (0x0008)  
	UMaterialInterface*                                DefaultThrobberMaterialInstance;                            // 0x00B8   (0x0008)  
	FSlateBrush                                        DefaultThrobberBrush;                                       // 0x00C0   (0x00E0)  
	UCommonUIRichTextData*                             RichTextDataInstance;                                       // 0x01A0   (0x0008)  
	unsigned char                                      UnknownData02_6[0x8];                                       // 0x01A8   (0x0008)  MISSED
};

/// Class /Script/CommonUI.CommonUISubsystemBase
/// Size: 0x0010 (0x000030 - 0x000040)
class UCommonUISubsystemBase : public UGameInstanceSubsystem
{ 
public:
	unsigned char                                      UnknownData00_1[0x10];                                      // 0x0030   (0x0010)  MISSED
};

/// Class /Script/CommonUI.CommonVideoPlayer
/// Size: 0x0168 (0x000138 - 0x0002A0)
class UCommonVideoPlayer : public UWidget
{ 
public:
	UMediaSource*                                      Video;                                                      // 0x0138   (0x0008)  
	UMediaPlayer*                                      MediaPlayer;                                                // 0x0140   (0x0008)  
	UMediaTexture*                                     MediaTexture;                                               // 0x0148   (0x0008)  
	UMaterial*                                         VideoMaterial;                                              // 0x0150   (0x0008)  
	UMediaSoundComponent*                              SoundComponent;                                             // 0x0158   (0x0008)  
	FSlateBrush                                        VideoBrush;                                                 // 0x0160   (0x00E0)  
	unsigned char                                      UnknownData00_6[0x60];                                      // 0x0240   (0x0060)  MISSED
};

/// Class /Script/CommonUI.CommonVisibilitySwitcher
/// Size: 0x0028 (0x000160 - 0x000188)
class UCommonVisibilitySwitcher : public UOverlay
{ 
public:
	ESlateVisibility                                   ShownVisibility;                                            // 0x0160   (0x0001)  
	unsigned char                                      UnknownData00_5[0x3];                                       // 0x0161   (0x0003)  MISSED
	int32_t                                            ActiveWidgetIndex;                                          // 0x0164   (0x0004)  
	bool                                               bAutoActivateSlot;                                          // 0x0168   (0x0001)  
	bool                                               bActivateFirstSlotOnAdding;                                 // 0x0169   (0x0001)  
	unsigned char                                      UnknownData01_6[0x1E];                                      // 0x016A   (0x001E)  MISSED


	/// Functions
	// Function /Script/CommonUI.CommonVisibilitySwitcher.SetActiveWidgetIndex
	void SetActiveWidgetIndex(int32_t Index);                                                                                // [0xbeab10] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonVisibilitySwitcher.SetActiveWidget
	void SetActiveWidget(UWidget* Widget);                                                                                   // [0xbea9f0] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonVisibilitySwitcher.IncrementActiveWidgetIndex
	void IncrementActiveWidgetIndex(bool bAllowWrapping);                                                                    // [0xbea850] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonVisibilitySwitcher.GetActiveWidgetIndex
	int32_t GetActiveWidgetIndex();                                                                                          // [0xbe9fb0] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonVisibilitySwitcher.GetActiveWidget
	UWidget* GetActiveWidget();                                                                                              // [0xbe9f80] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonVisibilitySwitcher.DecrementActiveWidgetIndex
	void DecrementActiveWidgetIndex(bool bAllowWrapping);                                                                    // [0xbe9e00] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonVisibilitySwitcher.DeactivateVisibleSlot
	void DeactivateVisibleSlot();                                                                                            // [0xbe9de0] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonVisibilitySwitcher.ActivateVisibleSlot
	void ActivateVisibleSlot();                                                                                              // [0xbe9cb0] Final|Native|Public|BlueprintCallable 
};

/// Class /Script/CommonUI.CommonVisibilitySwitcherSlot
/// Size: 0x0010 (0x000058 - 0x000068)
class UCommonVisibilitySwitcherSlot : public UOverlaySlot
{ 
public:
	unsigned char                                      UnknownData00_1[0x10];                                      // 0x0058   (0x0010)  MISSED
};

/// Class /Script/CommonUI.CommonVisibilityWidgetBase
/// Size: 0x0060 (0x000320 - 0x000380)
class UCommonVisibilityWidgetBase : public UCommonBorder
{ 
public:
	TMap<FName, bool>                                  VisibilityControls;                                         // 0x0320   (0x0050)  
	bool                                               bShowForGamepad;                                            // 0x0370   (0x0001)  
	bool                                               bShowForMouseAndKeyboard;                                   // 0x0371   (0x0001)  
	bool                                               bShowForTouch;                                              // 0x0372   (0x0001)  
	ESlateVisibility                                   VisibleType;                                                // 0x0373   (0x0001)  
	ESlateVisibility                                   HiddenType;                                                 // 0x0374   (0x0001)  
	unsigned char                                      UnknownData00_6[0xB];                                       // 0x0375   (0x000B)  MISSED


	/// Functions
	// Function /Script/CommonUI.CommonVisibilityWidgetBase.GetRegisteredPlatforms
	TArray<FName> GetRegisteredPlatforms();                                                                                  // [0xbea3b0] Final|Native|Static|Protected 
};

/// Class /Script/CommonUI.CommonVisualAttachment
/// Size: 0x0018 (0x000188 - 0x0001A0)
class UCommonVisualAttachment : public USizeBox
{ 
public:
	FVector2D                                          ContentAnchor;                                              // 0x0188   (0x0008)  
	unsigned char                                      UnknownData00_6[0x10];                                      // 0x0190   (0x0010)  MISSED
};

/// Class /Script/CommonUI.CommonWidgetCarousel
/// Size: 0x0040 (0x000150 - 0x000190)
class UCommonWidgetCarousel : public UPanelWidget
{ 
public:
	int32_t                                            ActiveWidgetIndex;                                          // 0x0150   (0x0004)  
	unsigned char                                      UnknownData00_5[0x4];                                       // 0x0154   (0x0004)  MISSED
	FMulticastInlineDelegate                           OnCurrentPageIndexChanged;                                  // 0x0158   (0x0010)  
	unsigned char                                      UnknownData01_6[0x28];                                      // 0x0168   (0x0028)  MISSED


	/// Functions
	// Function /Script/CommonUI.CommonWidgetCarousel.SetActiveWidgetIndex
	void SetActiveWidgetIndex(int32_t Index);                                                                                // [0xbeaba0] Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonWidgetCarousel.SetActiveWidget
	void SetActiveWidget(UWidget* Widget);                                                                                   // [0xbeaa80] Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonWidgetCarousel.PreviousPage
	void PreviousPage();                                                                                                     // [0xbea900] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonWidgetCarousel.NextPage
	void NextPage();                                                                                                         // [0xbea8e0] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonWidgetCarousel.GetWidgetAtIndex
	UWidget* GetWidgetAtIndex(int32_t Index);                                                                                // [0xbea610] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonWidgetCarousel.GetActiveWidgetIndex
	int32_t GetActiveWidgetIndex();                                                                                          // [0xbe9fd0] Final|Native|Public|BlueprintCallable|BlueprintPure|Const 
	// Function /Script/CommonUI.CommonWidgetCarousel.EndAutoScrolling
	void EndAutoScrolling();                                                                                                 // [0xbe9e90] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonWidgetCarousel.BeginAutoScrolling
	void BeginAutoScrolling(float ScrollInterval);                                                                           // [0xbe9d60] Final|Native|Public|BlueprintCallable 
};

/// Class /Script/CommonUI.CommonWidgetCarouselNavBar
/// Size: 0x0048 (0x000138 - 0x000180)
class UCommonWidgetCarouselNavBar : public UWidget
{ 
public:
	UClass*                                            ButtonWidgetType;                                           // 0x0138   (0x0008)  
	FMargin                                            ButtonPadding;                                              // 0x0140   (0x0010)  
	unsigned char                                      UnknownData00_5[0x10];                                      // 0x0150   (0x0010)  MISSED
	UCommonWidgetCarousel*                             LinkedCarousel;                                             // 0x0160   (0x0008)  
	UCommonButtonGroupBase*                            ButtonGroup;                                                // 0x0168   (0x0008)  
	TArray<UCommonButtonBase*>                         Buttons;                                                    // 0x0170   (0x0010)  


	/// Functions
	// Function /Script/CommonUI.CommonWidgetCarouselNavBar.SetLinkedCarousel
	void SetLinkedCarousel(UCommonWidgetCarousel* CommonCarousel);                                                           // [0xbeacc0] Final|Native|Public|BlueprintCallable 
	// Function /Script/CommonUI.CommonWidgetCarouselNavBar.HandlePageChanged
	void HandlePageChanged(UCommonWidgetCarousel* CommonCarousel, int32_t PageIndex);                                        // [0xbea780] Final|Native|Protected 
	// Function /Script/CommonUI.CommonWidgetCarouselNavBar.HandleButtonClicked
	void HandleButtonClicked(UCommonButtonBase* AssociatedButton, int32_t ButtonIndex);                                      // [0xbea6b0] Final|Native|Protected 
};

/// Struct /Script/CommonUI.CommonNumberFormattingOptions
/// Size: 0x0014 (0x000000 - 0x000014)
struct FCommonNumberFormattingOptions
{ 
	TEnumAsByte<ERoundingMode>                         RoundingMode;                                               // 0x0000   (0x0001)  
	bool                                               UseGrouping;                                                // 0x0001   (0x0001)  
	unsigned char                                      UnknownData00_5[0x2];                                       // 0x0002   (0x0002)  MISSED
	int32_t                                            MinimumIntegralDigits;                                      // 0x0004   (0x0004)  
	int32_t                                            MaximumIntegralDigits;                                      // 0x0008   (0x0004)  
	int32_t                                            MinimumFractionalDigits;                                    // 0x000C   (0x0004)  
	int32_t                                            MaximumFractionalDigits;                                    // 0x0010   (0x0004)  
};

/// Struct /Script/CommonUI.CommonRegisteredTabInfo
/// Size: 0x0018 (0x000000 - 0x000018)
struct FCommonRegisteredTabInfo
{ 
	int32_t                                            TabIndex;                                                   // 0x0000   (0x0004)  
	unsigned char                                      UnknownData00_5[0x4];                                       // 0x0004   (0x0004)  MISSED
	UCommonButtonBase*                                 TabButton;                                                  // 0x0008   (0x0008)  
	UWidget*                                           ContentInstance;                                            // 0x0010   (0x0008)  
};

/// Struct /Script/CommonUI.CommonInputActionHandlerData
/// Size: 0x0020 (0x000000 - 0x000020)
struct FCommonInputActionHandlerData
{ 
	FDataTableRowHandle                                InputActionRow;                                             // 0x0000   (0x0010)  
	EInputActionState                                  State;                                                      // 0x0010   (0x0001)  
	unsigned char                                      UnknownData00_6[0xF];                                       // 0x0011   (0x000F)  MISSED
};

/// Struct /Script/CommonUI.CommonButtonStyleOptionalSlateSound
/// Size: 0x0020 (0x000000 - 0x000020)
struct FCommonButtonStyleOptionalSlateSound
{ 
	bool                                               bHasSound;                                                  // 0x0000   (0x0001)  
	unsigned char                                      UnknownData00_5[0x7];                                       // 0x0001   (0x0007)  MISSED
	FSlateSound                                        Sound;                                                      // 0x0008   (0x0018)  
};

/// Struct /Script/CommonUI.CommonAnalogCursorSettings
/// Size: 0x0028 (0x000000 - 0x000028)
struct FCommonAnalogCursorSettings
{ 
	int32_t                                            PreprocessorPriority;                                       // 0x0000   (0x0004)  
	bool                                               bEnableCursorAcceleration;                                  // 0x0004   (0x0001)  
	unsigned char                                      UnknownData00_5[0x3];                                       // 0x0005   (0x0003)  MISSED
	float                                              CursorAcceleration;                                         // 0x0008   (0x0004)  
	float                                              CursorMaxSpeed;                                             // 0x000C   (0x0004)  
	float                                              CursorDeadZone;                                             // 0x0010   (0x0004)  
	float                                              CursorRadius;                                               // 0x0014   (0x0004)  
	float                                              HoverSlowdownFactor;                                        // 0x0018   (0x0004)  
	float                                              ScrollDeadZone;                                             // 0x001C   (0x0004)  
	float                                              ScrollUpdatePeriod;                                         // 0x0020   (0x0004)  
	float                                              ScrollMultiplier;                                           // 0x0024   (0x0004)  
};

/// Struct /Script/CommonUI.UIInputAction
/// Size: 0x0030 (0x000000 - 0x000030)
struct FUIInputAction
{ 
	FUIActionTag                                       ActionTag;                                                  // 0x0000   (0x0008)  
	FText                                              DefaultDisplayName;                                         // 0x0008   (0x0018)  
	TArray<FUIActionKeyMapping>                        KeyMappings;                                                // 0x0020   (0x0010)  
};

/// Struct /Script/CommonUI.UIActionKeyMapping
/// Size: 0x0020 (0x000000 - 0x000020)
struct FUIActionKeyMapping
{ 
	FKey                                               Key;                                                        // 0x0000   (0x0018)  
	float                                              HoldTime;                                                   // 0x0018   (0x0004)  
	unsigned char                                      UnknownData00_6[0x4];                                       // 0x001C   (0x0004)  MISSED
};

/// Struct /Script/CommonUI.UITag
/// Size: 0x0000 (0x000008 - 0x000008)
struct FUITag : FGameplayTag
{ 
};

/// Struct /Script/CommonUI.UIActionTag
/// Size: 0x0000 (0x000008 - 0x000008)
struct FUIActionTag : FUITag
{ 
};

/// Struct /Script/CommonUI.RichTextIconData
/// Size: 0x0048 (0x000008 - 0x000050)
struct FRichTextIconData : FTableRowBase
{ 
	FText                                              DisplayName;                                                // 0x0008   (0x0018)  
	TWeakObjectPtr<UObject*>                           ResourceObject;                                             // 0x0020   (0x0028)  
	FVector2D                                          ImageSize;                                                  // 0x0048   (0x0008)  
};

/// Struct /Script/CommonUI.CommonInputActionDataBase
/// Size: 0x0388 (0x000008 - 0x000390)
struct FCommonInputActionDataBase : FTableRowBase
{ 
	FText                                              DisplayName;                                                // 0x0008   (0x0018)  
	FText                                              HoldDisplayName;                                            // 0x0020   (0x0018)  
	unsigned char                                      UnknownData00_5[0x8];                                       // 0x0038   (0x0008)  MISSED
	FCommonInputTypeInfo                               KeyboardInputTypeInfo;                                      // 0x0040   (0x0100)  
	FCommonInputTypeInfo                               DefaultGamepadInputTypeInfo;                                // 0x0140   (0x0100)  
	TMap<FName, FCommonInputTypeInfo>                  GamepadInputOverrides;                                      // 0x0240   (0x0050)  
	FCommonInputTypeInfo                               TouchInputTypeInfo;                                         // 0x0290   (0x0100)  
};

/// Struct /Script/CommonUI.CommonInputTypeInfo
/// Size: 0x0100 (0x000000 - 0x000100)
struct FCommonInputTypeInfo
{ 
	FKey                                               Key;                                                        // 0x0000   (0x0018)  
	EInputActionState                                  OverrrideState;                                             // 0x0018   (0x0001)  
	bool                                               bActionRequiresHold;                                        // 0x0019   (0x0001)  
	unsigned char                                      UnknownData00_5[0x2];                                       // 0x001A   (0x0002)  MISSED
	float                                              HoldTime;                                                   // 0x001C   (0x0004)  
	FSlateBrush                                        OverrideBrush;                                              // 0x0020   (0x00E0)  
};

/// Enum /Script/CommonUI.ECommonNumericType
/// Size: 0x05
enum ECommonNumericType : uint8_t
{
	ECommonNumericType__Number                                                       = 0,
	ECommonNumericType__Percentage                                                   = 1,
	ECommonNumericType__Seconds                                                      = 2,
	ECommonNumericType__Distance                                                     = 3,
	ECommonNumericType__ECommonNumericType_MAX                                       = 4
};

/// Enum /Script/CommonUI.ECommonInputMode
/// Size: 0x04
enum ECommonInputMode : uint8_t
{
	ECommonInputMode__Menu                                                           = 0,
	ECommonInputMode__Game                                                           = 1,
	ECommonInputMode__All                                                            = 2,
	ECommonInputMode__MAX                                                            = 3
};

/// Enum /Script/CommonUI.ERichTextInlineIconDisplayMode
/// Size: 0x04
enum ERichTextInlineIconDisplayMode : uint8_t
{
	ERichTextInlineIconDisplayMode__IconOnly                                         = 0,
	ERichTextInlineIconDisplayMode__TextOnly                                         = 1,
	ERichTextInlineIconDisplayMode__IconAndText                                      = 2,
	ERichTextInlineIconDisplayMode__MAX                                              = 3
};

/// Enum /Script/CommonUI.EInputActionState
/// Size: 0x05
enum EInputActionState : uint8_t
{
	EInputActionState__Enabled                                                       = 0,
	EInputActionState__Disabled                                                      = 1,
	EInputActionState__Hidden                                                        = 2,
	EInputActionState__HiddenAndDisabled                                             = 3,
	EInputActionState__EInputActionState_MAX                                         = 4
};

/// Enum /Script/CommonUI.ETransitionCurve
/// Size: 0x08
enum ETransitionCurve : uint8_t
{
	ETransitionCurve__Linear                                                         = 0,
	ETransitionCurve__QuadIn                                                         = 1,
	ETransitionCurve__QuadOut                                                        = 2,
	ETransitionCurve__QuadInOut                                                      = 3,
	ETransitionCurve__CubicIn                                                        = 4,
	ETransitionCurve__CubicOut                                                       = 5,
	ETransitionCurve__CubicInOut                                                     = 6,
	ETransitionCurve__ETransitionCurve_MAX                                           = 7
};

/// Enum /Script/CommonUI.ECommonSwitcherTransition
/// Size: 0x05
enum ECommonSwitcherTransition : uint8_t
{
	ECommonSwitcherTransition__FadeOnly                                              = 0,
	ECommonSwitcherTransition__Horizontal                                            = 1,
	ECommonSwitcherTransition__Vertical                                              = 2,
	ECommonSwitcherTransition__Zoom                                                  = 3,
	ECommonSwitcherTransition__ECommonSwitcherTransition_MAX                         = 4
};

