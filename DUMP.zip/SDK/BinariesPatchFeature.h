/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package BinariesPatchFeature.

/// Enum /Script/BinariesPatchFeature.EBinariesPatchFeature
/// Size: 0x03
enum EBinariesPatchFeature : uint8_t
{
	EBinariesPatchFeature__None                                                      = 0,
	EBinariesPatchFeature__Count                                                     = 1,
	EBinariesPatchFeature__EBinariesPatchFeature_MAX                                 = 2
};

