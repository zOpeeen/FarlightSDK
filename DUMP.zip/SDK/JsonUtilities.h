/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package JsonUtilities.

/// Class /Script/JsonUtilities.JsonUtilitiesDummyObject
/// Size: 0x0000 (0x000028 - 0x000028)
class UJsonUtilitiesDummyObject : public UObject
{ 
public:
};

/// Struct /Script/JsonUtilities.JsonObjectWrapper
/// Size: 0x0020 (0x000000 - 0x000020)
struct FJsonObjectWrapper
{ 
	FString                                            JsonString;                                                 // 0x0000   (0x0010)  
	unsigned char                                      UnknownData00_6[0x10];                                      // 0x0010   (0x0010)  MISSED
};

