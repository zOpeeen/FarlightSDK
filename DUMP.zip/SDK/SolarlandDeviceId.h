/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package SolarlandDeviceId.

/// Class /Script/SolarlandDeviceId.SolarlandDeviceInfoSettings
/// Size: 0x0010 (0x000038 - 0x000048)
class USolarlandDeviceInfoSettings : public UDeveloperSettings
{ 
public:
	FString                                            UserName;                                                   // 0x0038   (0x0010)  


	/// Functions
	// Function /Script/SolarlandDeviceId.SolarlandDeviceInfoSettings.GetInstance
	USolarlandDeviceInfoSettings* GetInstance();                                                                             // [0x2a54180] Final|Native|Static|Public|BlueprintCallable 
};

/// Struct /Script/SolarlandDeviceId.DummyObject
/// Size: 0x0001 (0x000000 - 0x000001)
struct FDummyObject
{ 
	unsigned char                                      UnknownData00_1[0x1];                                       // 0x0000   (0x0001)  MISSED
};

