/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package 08_Vehicles.

/// Class /Game/08_Vehicles/Abilities/WeaponAbility/GE_VehicleWeaponFire.GE_VehicleWeaponFire_C
/// Size: 0x0000 (0x000848 - 0x000848)
class UGE_VehicleWeaponFire_C : public UGameplayEffect
{ 
public:
};

/// Class /Game/08_Vehicles/Abilities/WeaponAbility/GA_VehicleWeaponFire.GA_VehicleWeaponFire_C
/// Size: 0x0000 (0x000508 - 0x000508)
class UGA_VehicleWeaponFire_C : public USolarVehicleGA_WeaponFire
{ 
public:
};

