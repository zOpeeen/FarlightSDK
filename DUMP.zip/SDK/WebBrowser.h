/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package WebBrowser.

/// Struct /Script/WebBrowser.WebJSCallbackBase
/// Size: 0x0020 (0x000000 - 0x000020)
struct FWebJSCallbackBase
{ 
	unsigned char                                      UnknownData00_1[0x20];                                      // 0x0000   (0x0020)  MISSED
};

/// Struct /Script/WebBrowser.WebJSResponse
/// Size: 0x0000 (0x000020 - 0x000020)
struct FWebJSResponse : FWebJSCallbackBase
{ 
};

/// Struct /Script/WebBrowser.WebJSFunction
/// Size: 0x0000 (0x000020 - 0x000020)
struct FWebJSFunction : FWebJSCallbackBase
{ 
};

