/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package SolarUtils.

/// Struct /Script/SolarUtils.SolarAggregationTickFunction
/// Size: 0x0008 (0x000028 - 0x000030)
struct FSolarAggregationTickFunction : FTickFunction
{ 
	unsigned char                                      UnknownData00_1[0x8];                                       // 0x0028   (0x0008)  MISSED
};

