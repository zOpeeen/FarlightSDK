/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package SignificanceManager.

/// Class /Script/SignificanceManager.SignificanceManager
/// Size: 0x0110 (0x000028 - 0x000138)
class USignificanceManager : public UObject
{ 
public:
	unsigned char                                      UnknownData00_2[0xF8];                                      // 0x0028   (0x00F8)  MISSED
	FSoftClassPath                                     SignificanceManagerClassName;                               // 0x0120   (0x0018)  
};

