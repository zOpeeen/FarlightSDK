/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package LightPropagationVolumeRuntime.

/// Class /Script/LightPropagationVolumeRuntime.LightPropagationVolumeBlendable
/// Size: 0x0050 (0x000028 - 0x000078)
class ULightPropagationVolumeBlendable : public UObject
{ 
public:
	unsigned char                                      UnknownData00_2[0x8];                                       // 0x0028   (0x0008)  MISSED
	FLightPropagationVolumeSettings                    Settings;                                                   // 0x0030   (0x0040)  
	float                                              BlendWeight;                                                // 0x0070   (0x0004)  
	unsigned char                                      UnknownData01_6[0x4];                                       // 0x0074   (0x0004)  MISSED
};

