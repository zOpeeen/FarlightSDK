/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package UObjectPlugin.

/// Class /Script/UObjectPlugin.MyPluginObject
/// Size: 0x0010 (0x000028 - 0x000038)
class UMyPluginObject : public UObject
{ 
public:
	FMyPluginStruct                                    MyStruct;                                                   // 0x0028   (0x0010)  
};

/// Struct /Script/UObjectPlugin.MyPluginStruct
/// Size: 0x0010 (0x000000 - 0x000010)
struct FMyPluginStruct
{ 
	FString                                            TestString;                                                 // 0x0000   (0x0010)  
};

