/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package SlateCore.

/// Class /Script/SlateCore.FontBulkData
/// Size: 0x0048 (0x000028 - 0x000070)
class UFontBulkData : public UObject
{ 
public:
	unsigned char                                      UnknownData00_1[0x48];                                      // 0x0028   (0x0048)  MISSED
};

/// Class /Script/SlateCore.FontFaceInterface
/// Size: 0x0000 (0x000028 - 0x000028)
class UFontFaceInterface : public UInterface
{ 
public:
};

/// Class /Script/SlateCore.FontProviderInterface
/// Size: 0x0000 (0x000028 - 0x000028)
class UFontProviderInterface : public UInterface
{ 
public:
};

/// Class /Script/SlateCore.SlateTypes
/// Size: 0x0000 (0x000028 - 0x000028)
class USlateTypes : public UObject
{ 
public:
};

/// Class /Script/SlateCore.SlateWidgetStyleAsset
/// Size: 0x0008 (0x000028 - 0x000030)
class USlateWidgetStyleAsset : public UObject
{ 
public:
	USlateWidgetStyleContainerBase*                    CustomStyle;                                                // 0x0028   (0x0008)  
};

/// Class /Script/SlateCore.SlateWidgetStyleContainerBase
/// Size: 0x0008 (0x000028 - 0x000030)
class USlateWidgetStyleContainerBase : public UObject
{ 
public:
	unsigned char                                      UnknownData00_1[0x8];                                       // 0x0028   (0x0008)  MISSED
};

/// Class /Script/SlateCore.SlateWidgetStyleContainerInterface
/// Size: 0x0000 (0x000028 - 0x000028)
class USlateWidgetStyleContainerInterface : public UInterface
{ 
public:
};

/// Struct /Script/SlateCore.Geometry
/// Size: 0x0038 (0x000000 - 0x000038)
struct FGeometry
{ 
	unsigned char                                      UnknownData00_1[0x38];                                      // 0x0000   (0x0038)  MISSED
};

/// Struct /Script/SlateCore.SlateBrush
/// Size: 0x00E0 (0x000000 - 0x0000E0)
struct FSlateBrush
{ 
	unsigned char                                      UnknownData00_2[0x10];                                      // 0x0000   (0x0010)  MISSED
	FVector2D                                          ImageSize;                                                  // 0x0010   (0x0008)  
	bool                                               bLockRatio;                                                 // 0x0018   (0x0001)  
	unsigned char                                      UnknownData01_5[0x3];                                       // 0x0019   (0x0003)  MISSED
	FVector2D                                          LockedSize;                                                 // 0x001C   (0x0008)  
	bool                                               bUsePixelMargin;                                            // 0x0024   (0x0001)  
	unsigned char                                      UnknownData02_5[0x3];                                       // 0x0025   (0x0003)  MISSED
	FMargin                                            Margin;                                                     // 0x0028   (0x0010)  
	FSlateColor                                        TintColor;                                                  // 0x0038   (0x0028)  
	FSlateBrushOutlineSettings                         OutlineSettings;                                            // 0x0060   (0x0040)  
	UObject*                                           ResourceObject;                                             // 0x00A0   (0x0008)  
	FName                                              ResourceName;                                               // 0x00A8   (0x0008)  
	FBox2D                                             UVRegion;                                                   // 0x00B0   (0x0014)  
	TEnumAsByte<ESlateBrushDrawType>                   DrawAs;                                                     // 0x00C4   (0x0001)  
	TEnumAsByte<ESlateBrushTileType>                   Tiling;                                                     // 0x00C5   (0x0001)  
	TEnumAsByte<ESlateBrushMirrorType>                 Mirroring;                                                  // 0x00C6   (0x0001)  
	TEnumAsByte<ESlateBrushImageType>                  ImageType;                                                  // 0x00C7   (0x0001)  
	unsigned char                                      UnknownData03_5[0x10];                                      // 0x00C8   (0x0010)  MISSED
	bool                                               bIsDynamicallyLoaded;                                       // 0x00D8:0 (0x0001)  
	bool                                               bHasUObject;                                                // 0x00D8:1 (0x0001)  
	unsigned char                                      UnknownData04_6[0x7];                                       // 0x00D9   (0x0007)  MISSED
};

/// Struct /Script/SlateCore.SlateBrushOutlineSettings
/// Size: 0x0040 (0x000000 - 0x000040)
struct FSlateBrushOutlineSettings
{ 
	FVector4                                           CornerRadii;                                                // 0x0000   (0x0010)  
	FSlateColor                                        Color;                                                      // 0x0010   (0x0028)  
	float                                              Width;                                                      // 0x0038   (0x0004)  
	TEnumAsByte<ESlateBrushRoundingType>               RoundingType;                                               // 0x003C   (0x0001)  
	bool                                               bUseBrushTransparency;                                      // 0x003D   (0x0001)  
	unsigned char                                      UnknownData00_6[0x2];                                       // 0x003E   (0x0002)  MISSED
};

/// Struct /Script/SlateCore.SlateColor
/// Size: 0x0028 (0x000000 - 0x000028)
struct FSlateColor
{ 
	FLinearColor                                       SpecifiedColor;                                             // 0x0000   (0x0010)  
	TEnumAsByte<ESlateColorStylingMode>                ColorUseRule;                                               // 0x0010   (0x0001)  
	unsigned char                                      UnknownData00_6[0x17];                                      // 0x0011   (0x0017)  MISSED
};

/// Struct /Script/SlateCore.Margin
/// Size: 0x0010 (0x000000 - 0x000010)
struct FMargin
{ 
	float                                              Left;                                                       // 0x0000   (0x0004)  
	float                                              Top;                                                        // 0x0004   (0x0004)  
	float                                              Right;                                                      // 0x0008   (0x0004)  
	float                                              Bottom;                                                     // 0x000C   (0x0004)  
};

/// Struct /Script/SlateCore.InputEvent
/// Size: 0x0018 (0x000000 - 0x000018)
struct FInputEvent
{ 
	unsigned char                                      UnknownData00_1[0x18];                                      // 0x0000   (0x0018)  MISSED
};

/// Struct /Script/SlateCore.PointerEvent
/// Size: 0x0058 (0x000018 - 0x000070)
struct FPointerEvent : FInputEvent
{ 
	unsigned char                                      UnknownData00_1[0x58];                                      // 0x0018   (0x0058)  MISSED
};

/// Struct /Script/SlateCore.CharacterEvent
/// Size: 0x0008 (0x000018 - 0x000020)
struct FCharacterEvent : FInputEvent
{ 
	unsigned char                                      UnknownData00_1[0x8];                                       // 0x0018   (0x0008)  MISSED
};

/// Struct /Script/SlateCore.KeyEvent
/// Size: 0x0020 (0x000018 - 0x000038)
struct FKeyEvent : FInputEvent
{ 
	unsigned char                                      UnknownData00_1[0x20];                                      // 0x0018   (0x0020)  MISSED
};

/// Struct /Script/SlateCore.NavigationEvent
/// Size: 0x0008 (0x000018 - 0x000020)
struct FNavigationEvent : FInputEvent
{ 
	unsigned char                                      UnknownData00_1[0x8];                                       // 0x0018   (0x0008)  MISSED
};

/// Struct /Script/SlateCore.AnalogInputEvent
/// Size: 0x0008 (0x000038 - 0x000040)
struct FAnalogInputEvent : FKeyEvent
{ 
	unsigned char                                      UnknownData00_1[0x8];                                       // 0x0038   (0x0008)  MISSED
};

/// Struct /Script/SlateCore.SlateFontInfo
/// Size: 0x0060 (0x000000 - 0x000060)
struct FSlateFontInfo
{ 
	UObject*                                           FontObject;                                                 // 0x0000   (0x0008)  
	UObject*                                           FontMaterial;                                               // 0x0008   (0x0008)  
	FFontOutlineSettings                               OutlineSettings;                                            // 0x0010   (0x0028)  
	unsigned char                                      UnknownData00_5[0x10];                                      // 0x0038   (0x0010)  MISSED
	FName                                              TypefaceFontName;                                           // 0x0048   (0x0008)  
	int32_t                                            Size;                                                       // 0x0050   (0x0004)  
	int32_t                                            LetterSpacing;                                              // 0x0054   (0x0004)  
	unsigned char                                      UnknownData01_6[0x8];                                       // 0x0058   (0x0008)  MISSED
};

/// Struct /Script/SlateCore.FontOutlineSettings
/// Size: 0x0028 (0x000000 - 0x000028)
struct FFontOutlineSettings
{ 
	int32_t                                            OutlineSize;                                                // 0x0000   (0x0004)  
	int32_t                                            OutlineBlur;                                                // 0x0004   (0x0004)  
	bool                                               bSeparateFillAlpha;                                         // 0x0008   (0x0001)  
	bool                                               bApplyOutlineToDropShadows;                                 // 0x0009   (0x0001)  
	unsigned char                                      UnknownData00_5[0x6];                                       // 0x000A   (0x0006)  MISSED
	UObject*                                           OutlineMaterial;                                            // 0x0010   (0x0008)  
	FLinearColor                                       OutlineColor;                                               // 0x0018   (0x0010)  
};

/// Struct /Script/SlateCore.SlateWidgetStyle
/// Size: 0x0008 (0x000000 - 0x000008)
struct FSlateWidgetStyle
{ 
	unsigned char                                      UnknownData00_1[0x8];                                       // 0x0000   (0x0008)  MISSED
};

/// Struct /Script/SlateCore.TableRowStyle
/// Size: 0x0C98 (0x000008 - 0x000CA0)
struct FTableRowStyle : FSlateWidgetStyle
{ 
	unsigned char                                      UnknownData00_2[0x8];                                       // 0x0008   (0x0008)  MISSED
	FSlateBrush                                        SelectorFocusedBrush;                                       // 0x0010   (0x00E0)  
	FSlateBrush                                        ActiveHoveredBrush;                                         // 0x00F0   (0x00E0)  
	FSlateBrush                                        ActiveBrush;                                                // 0x01D0   (0x00E0)  
	FSlateBrush                                        InactiveHoveredBrush;                                       // 0x02B0   (0x00E0)  
	FSlateBrush                                        InactiveBrush;                                              // 0x0390   (0x00E0)  
	FSlateBrush                                        EvenRowBackgroundHoveredBrush;                              // 0x0470   (0x00E0)  
	FSlateBrush                                        EvenRowBackgroundBrush;                                     // 0x0550   (0x00E0)  
	FSlateBrush                                        OddRowBackgroundHoveredBrush;                               // 0x0630   (0x00E0)  
	FSlateBrush                                        OddRowBackgroundBrush;                                      // 0x0710   (0x00E0)  
	FSlateColor                                        TextColor;                                                  // 0x07F0   (0x0028)  
	FSlateColor                                        SelectedTextColor;                                          // 0x0818   (0x0028)  
	FSlateBrush                                        DropIndicator_Above;                                        // 0x0840   (0x00E0)  
	FSlateBrush                                        DropIndicator_Onto;                                         // 0x0920   (0x00E0)  
	FSlateBrush                                        DropIndicator_Below;                                        // 0x0A00   (0x00E0)  
	FSlateBrush                                        ActiveHighlightedBrush;                                     // 0x0AE0   (0x00E0)  
	FSlateBrush                                        InactiveHighlightedBrush;                                   // 0x0BC0   (0x00E0)  
};

/// Struct /Script/SlateCore.ComboBoxStyle
/// Size: 0x0618 (0x000008 - 0x000620)
struct FComboBoxStyle : FSlateWidgetStyle
{ 
	unsigned char                                      UnknownData00_2[0x8];                                       // 0x0008   (0x0008)  MISSED
	FComboButtonStyle                                  ComboButtonStyle;                                           // 0x0010   (0x05E0)  
	FSlateSound                                        PressedSlateSound;                                          // 0x05F0   (0x0018)  
	FSlateSound                                        SelectionChangeSlateSound;                                  // 0x0608   (0x0018)  
};

/// Struct /Script/SlateCore.SlateSound
/// Size: 0x0018 (0x000000 - 0x000018)
struct FSlateSound
{ 
	UObject*                                           ResourceObject;                                             // 0x0000   (0x0008)  
	unsigned char                                      UnknownData00_6[0x10];                                      // 0x0008   (0x0010)  MISSED
};

/// Struct /Script/SlateCore.ComboButtonStyle
/// Size: 0x05D8 (0x000008 - 0x0005E0)
struct FComboButtonStyle : FSlateWidgetStyle
{ 
	unsigned char                                      UnknownData00_2[0x8];                                       // 0x0008   (0x0008)  MISSED
	FButtonStyle                                       ButtonStyle;                                                // 0x0010   (0x03E0)  
	FSlateBrush                                        DownArrowImage;                                             // 0x03F0   (0x00E0)  
	FVector2D                                          ShadowOffset;                                               // 0x04D0   (0x0008)  
	FLinearColor                                       ShadowColorAndOpacity;                                      // 0x04D8   (0x0010)  
	unsigned char                                      UnknownData01_5[0x8];                                       // 0x04E8   (0x0008)  MISSED
	FSlateBrush                                        MenuBorderBrush;                                            // 0x04F0   (0x00E0)  
	FMargin                                            MenuBorderPadding;                                          // 0x05D0   (0x0010)  
};

/// Struct /Script/SlateCore.ButtonStyle
/// Size: 0x03D8 (0x000008 - 0x0003E0)
struct FButtonStyle : FSlateWidgetStyle
{ 
	unsigned char                                      UnknownData00_2[0x8];                                       // 0x0008   (0x0008)  MISSED
	FSlateBrush                                        Normal;                                                     // 0x0010   (0x00E0)  
	FSlateBrush                                        Hovered;                                                    // 0x00F0   (0x00E0)  
	FSlateBrush                                        Pressed;                                                    // 0x01D0   (0x00E0)  
	FSlateBrush                                        Disabled;                                                   // 0x02B0   (0x00E0)  
	FMargin                                            NormalPadding;                                              // 0x0390   (0x0010)  
	FMargin                                            PressedPadding;                                             // 0x03A0   (0x0010)  
	FSlateSound                                        PressedSlateSound;                                          // 0x03B0   (0x0018)  
	FSlateSound                                        HoveredSlateSound;                                          // 0x03C8   (0x0018)  
};

/// Struct /Script/SlateCore.EditableTextStyle
/// Size: 0x0328 (0x000008 - 0x000330)
struct FEditableTextStyle : FSlateWidgetStyle
{ 
	FSlateFontInfo                                     Font;                                                       // 0x0008   (0x0060)  
	FSlateColor                                        ColorAndOpacity;                                            // 0x0068   (0x0028)  
	FSlateBrush                                        BackgroundImageSelected;                                    // 0x0090   (0x00E0)  
	FSlateBrush                                        BackgroundImageComposing;                                   // 0x0170   (0x00E0)  
	FSlateBrush                                        CaretImage;                                                 // 0x0250   (0x00E0)  
};

/// Struct /Script/SlateCore.EditableTextBoxStyle
/// Size: 0x0C88 (0x000008 - 0x000C90)
struct FEditableTextBoxStyle : FSlateWidgetStyle
{ 
	unsigned char                                      UnknownData00_2[0x8];                                       // 0x0008   (0x0008)  MISSED
	FSlateBrush                                        BackgroundImageNormal;                                      // 0x0010   (0x00E0)  
	FSlateBrush                                        BackgroundImageHovered;                                     // 0x00F0   (0x00E0)  
	FSlateBrush                                        BackgroundImageFocused;                                     // 0x01D0   (0x00E0)  
	FSlateBrush                                        BackgroundImageReadOnly;                                    // 0x02B0   (0x00E0)  
	FMargin                                            Padding;                                                    // 0x0390   (0x0010)  
	FSlateFontInfo                                     Font;                                                       // 0x03A0   (0x0060)  
	FSlateColor                                        ForegroundColor;                                            // 0x0400   (0x0028)  
	FSlateColor                                        BackgroundColor;                                            // 0x0428   (0x0028)  
	FSlateColor                                        ReadOnlyForegroundColor;                                    // 0x0450   (0x0028)  
	FMargin                                            HScrollBarPadding;                                          // 0x0478   (0x0010)  
	FMargin                                            VScrollBarPadding;                                          // 0x0488   (0x0010)  
	unsigned char                                      UnknownData01_5[0x8];                                       // 0x0498   (0x0008)  MISSED
	FScrollBarStyle                                    ScrollBarStyle;                                             // 0x04A0   (0x07F0)  
};

/// Struct /Script/SlateCore.ScrollBarStyle
/// Size: 0x07E8 (0x000008 - 0x0007F0)
struct FScrollBarStyle : FSlateWidgetStyle
{ 
	unsigned char                                      UnknownData00_2[0x8];                                       // 0x0008   (0x0008)  MISSED
	FSlateBrush                                        HorizontalBackgroundImage;                                  // 0x0010   (0x00E0)  
	FSlateBrush                                        VerticalBackgroundImage;                                    // 0x00F0   (0x00E0)  
	FSlateBrush                                        VerticalTopSlotImage;                                       // 0x01D0   (0x00E0)  
	FSlateBrush                                        HorizontalTopSlotImage;                                     // 0x02B0   (0x00E0)  
	FSlateBrush                                        VerticalBottomSlotImage;                                    // 0x0390   (0x00E0)  
	FSlateBrush                                        HorizontalBottomSlotImage;                                  // 0x0470   (0x00E0)  
	FSlateBrush                                        NormalThumbImage;                                           // 0x0550   (0x00E0)  
	FSlateBrush                                        HoveredThumbImage;                                          // 0x0630   (0x00E0)  
	FSlateBrush                                        DraggedThumbImage;                                          // 0x0710   (0x00E0)  
};

/// Struct /Script/SlateCore.TextBlockStyle
/// Size: 0x0458 (0x000008 - 0x000460)
struct FTextBlockStyle : FSlateWidgetStyle
{ 
	FSlateFontInfo                                     Font;                                                       // 0x0008   (0x0060)  
	FSlateColor                                        ColorAndOpacity;                                            // 0x0068   (0x0028)  
	FVector2D                                          ShadowOffset;                                               // 0x0090   (0x0008)  
	FLinearColor                                       ShadowColorAndOpacity;                                      // 0x0098   (0x0010)  
	FSlateColor                                        SelectedBackgroundColor;                                    // 0x00A8   (0x0028)  
	FLinearColor                                       HighlightColor;                                             // 0x00D0   (0x0010)  
	FSlateBrush                                        HighlightShape;                                             // 0x00E0   (0x00E0)  
	FSlateBrush                                        StrikeBrush;                                                // 0x01C0   (0x00E0)  
	FSlateBrush                                        UnderlineBrush;                                             // 0x02A0   (0x00E0)  
	FSlateBrush                                        BackgroundBrush;                                            // 0x0380   (0x00E0)  
};

/// Struct /Script/SlateCore.SpinBoxStyle
/// Size: 0x04A8 (0x000008 - 0x0004B0)
struct FSpinBoxStyle : FSlateWidgetStyle
{ 
	unsigned char                                      UnknownData00_2[0x8];                                       // 0x0008   (0x0008)  MISSED
	FSlateBrush                                        BackgroundBrush;                                            // 0x0010   (0x00E0)  
	FSlateBrush                                        HoveredBackgroundBrush;                                     // 0x00F0   (0x00E0)  
	FSlateBrush                                        ActiveFillBrush;                                            // 0x01D0   (0x00E0)  
	FSlateBrush                                        InactiveFillBrush;                                          // 0x02B0   (0x00E0)  
	FSlateBrush                                        ArrowsImage;                                                // 0x0390   (0x00E0)  
	FSlateColor                                        ForegroundColor;                                            // 0x0470   (0x0028)  
	FMargin                                            TextPadding;                                                // 0x0498   (0x0010)  
	unsigned char                                      UnknownData01_6[0x8];                                       // 0x04A8   (0x0008)  MISSED
};

/// Struct /Script/SlateCore.FocusEvent
/// Size: 0x0008 (0x000000 - 0x000008)
struct FFocusEvent
{ 
	unsigned char                                      UnknownData00_1[0x8];                                       // 0x0000   (0x0008)  MISSED
};

/// Struct /Script/SlateCore.MotionEvent
/// Size: 0x0030 (0x000018 - 0x000048)
struct FMotionEvent : FInputEvent
{ 
	unsigned char                                      UnknownData00_1[0x30];                                      // 0x0018   (0x0030)  MISSED
};

/// Struct /Script/SlateCore.HyperlinkStyle
/// Size: 0x0858 (0x000008 - 0x000860)
struct FHyperlinkStyle : FSlateWidgetStyle
{ 
	unsigned char                                      UnknownData00_2[0x8];                                       // 0x0008   (0x0008)  MISSED
	FButtonStyle                                       UnderlineStyle;                                             // 0x0010   (0x03E0)  
	FTextBlockStyle                                    TextStyle;                                                  // 0x03F0   (0x0460)  
	FMargin                                            Padding;                                                    // 0x0850   (0x0010)  
};

/// Struct /Script/SlateCore.CompositeFont
/// Size: 0x0038 (0x000000 - 0x000038)
struct FCompositeFont
{ 
	FTypeface                                          DefaultTypeface;                                            // 0x0000   (0x0010)  
	FCompositeFallbackFont                             FallbackTypeface;                                           // 0x0010   (0x0018)  
	TArray<FCompositeSubFont>                          SubTypefaces;                                               // 0x0028   (0x0010)  
};

/// Struct /Script/SlateCore.CompositeFallbackFont
/// Size: 0x0018 (0x000000 - 0x000018)
struct FCompositeFallbackFont
{ 
	FTypeface                                          Typeface;                                                   // 0x0000   (0x0010)  
	float                                              ScalingFactor;                                              // 0x0010   (0x0004)  
	unsigned char                                      UnknownData00_6[0x4];                                       // 0x0014   (0x0004)  MISSED
};

/// Struct /Script/SlateCore.Typeface
/// Size: 0x0010 (0x000000 - 0x000010)
struct FTypeface
{ 
	TArray<FTypefaceEntry>                             Fonts;                                                      // 0x0000   (0x0010)  
};

/// Struct /Script/SlateCore.TypefaceEntry
/// Size: 0x0028 (0x000000 - 0x000028)
struct FTypefaceEntry
{ 
	FName                                              Name;                                                       // 0x0000   (0x0008)  
	FFontData                                          Font;                                                       // 0x0008   (0x0020)  
};

/// Struct /Script/SlateCore.FontData
/// Size: 0x0020 (0x000000 - 0x000020)
struct FFontData
{ 
	FString                                            FontFilename;                                               // 0x0000   (0x0010)  
	EFontHinting                                       Hinting;                                                    // 0x0010   (0x0001)  
	EFontLoadingPolicy                                 LoadingPolicy;                                              // 0x0011   (0x0001)  
	unsigned char                                      UnknownData00_5[0x2];                                       // 0x0012   (0x0002)  MISSED
	int32_t                                            SubFaceIndex;                                               // 0x0014   (0x0004)  
	UObject*                                           FontFaceAsset;                                              // 0x0018   (0x0008)  
};

/// Struct /Script/SlateCore.CompositeSubFont
/// Size: 0x0020 (0x000018 - 0x000038)
struct FCompositeSubFont : FCompositeFallbackFont
{ 
	TArray<FInt32Range>                                CharacterRanges;                                            // 0x0018   (0x0010)  
	FString                                            Cultures;                                                   // 0x0028   (0x0010)  
};

/// Struct /Script/SlateCore.CaptureLostEvent
/// Size: 0x0008 (0x000000 - 0x000008)
struct FCaptureLostEvent
{ 
	unsigned char                                      UnknownData00_1[0x8];                                       // 0x0000   (0x0008)  MISSED
};

/// Struct /Script/SlateCore.WindowStyle
/// Size: 0x1A68 (0x000008 - 0x001A70)
struct FWindowStyle : FSlateWidgetStyle
{ 
	unsigned char                                      UnknownData00_2[0x8];                                       // 0x0008   (0x0008)  MISSED
	FButtonStyle                                       MinimizeButtonStyle;                                        // 0x0010   (0x03E0)  
	FButtonStyle                                       MaximizeButtonStyle;                                        // 0x03F0   (0x03E0)  
	FButtonStyle                                       RestoreButtonStyle;                                         // 0x07D0   (0x03E0)  
	FButtonStyle                                       CloseButtonStyle;                                           // 0x0BB0   (0x03E0)  
	FTextBlockStyle                                    TitleTextStyle;                                             // 0x0F90   (0x0460)  
	FSlateBrush                                        ActiveTitleBrush;                                           // 0x13F0   (0x00E0)  
	FSlateBrush                                        InactiveTitleBrush;                                         // 0x14D0   (0x00E0)  
	FSlateBrush                                        FlashTitleBrush;                                            // 0x15B0   (0x00E0)  
	FSlateColor                                        BackgroundColor;                                            // 0x1690   (0x0028)  
	unsigned char                                      UnknownData01_5[0x8];                                       // 0x16B8   (0x0008)  MISSED
	FSlateBrush                                        OutlineBrush;                                               // 0x16C0   (0x00E0)  
	FSlateColor                                        OutlineColor;                                               // 0x17A0   (0x0028)  
	unsigned char                                      UnknownData02_5[0x8];                                       // 0x17C8   (0x0008)  MISSED
	FSlateBrush                                        BorderBrush;                                                // 0x17D0   (0x00E0)  
	FSlateBrush                                        BackgroundBrush;                                            // 0x18B0   (0x00E0)  
	FSlateBrush                                        ChildBackgroundBrush;                                       // 0x1990   (0x00E0)  
};

/// Struct /Script/SlateCore.ScrollBorderStyle
/// Size: 0x01C8 (0x000008 - 0x0001D0)
struct FScrollBorderStyle : FSlateWidgetStyle
{ 
	unsigned char                                      UnknownData00_2[0x8];                                       // 0x0008   (0x0008)  MISSED
	FSlateBrush                                        TopShadowBrush;                                             // 0x0010   (0x00E0)  
	FSlateBrush                                        BottomShadowBrush;                                          // 0x00F0   (0x00E0)  
};

/// Struct /Script/SlateCore.ScrollBoxStyle
/// Size: 0x0388 (0x000008 - 0x000390)
struct FScrollBoxStyle : FSlateWidgetStyle
{ 
	unsigned char                                      UnknownData00_2[0x8];                                       // 0x0008   (0x0008)  MISSED
	FSlateBrush                                        TopShadowBrush;                                             // 0x0010   (0x00E0)  
	FSlateBrush                                        BottomShadowBrush;                                          // 0x00F0   (0x00E0)  
	FSlateBrush                                        LeftShadowBrush;                                            // 0x01D0   (0x00E0)  
	FSlateBrush                                        RightShadowBrush;                                           // 0x02B0   (0x00E0)  
};

/// Struct /Script/SlateCore.DockTabStyle
/// Size: 0x0B28 (0x000008 - 0x000B30)
struct FDockTabStyle : FSlateWidgetStyle
{ 
	unsigned char                                      UnknownData00_2[0x8];                                       // 0x0008   (0x0008)  MISSED
	FButtonStyle                                       CloseButtonStyle;                                           // 0x0010   (0x03E0)  
	FSlateBrush                                        NormalBrush;                                                // 0x03F0   (0x00E0)  
	FSlateBrush                                        ActiveBrush;                                                // 0x04D0   (0x00E0)  
	FSlateBrush                                        ColorOverlayTabBrush;                                       // 0x05B0   (0x00E0)  
	FSlateBrush                                        ColorOverlayIconBrush;                                      // 0x0690   (0x00E0)  
	FSlateBrush                                        ForegroundBrush;                                            // 0x0770   (0x00E0)  
	FSlateBrush                                        HoveredBrush;                                               // 0x0850   (0x00E0)  
	FSlateBrush                                        ContentAreaBrush;                                           // 0x0930   (0x00E0)  
	FSlateBrush                                        TabWellBrush;                                               // 0x0A10   (0x00E0)  
	FMargin                                            TabPadding;                                                 // 0x0AF0   (0x0010)  
	float                                              OverlapWidth;                                               // 0x0B00   (0x0004)  
	unsigned char                                      UnknownData01_5[0x4];                                       // 0x0B04   (0x0004)  MISSED
	FSlateColor                                        FlashColor;                                                 // 0x0B08   (0x0028)  
};

/// Struct /Script/SlateCore.HeaderRowStyle
/// Size: 0x12C8 (0x000008 - 0x0012D0)
struct FHeaderRowStyle : FSlateWidgetStyle
{ 
	unsigned char                                      UnknownData00_2[0x8];                                       // 0x0008   (0x0008)  MISSED
	FTableColumnHeaderStyle                            ColumnStyle;                                                // 0x0010   (0x07F0)  
	FTableColumnHeaderStyle                            LastColumnStyle;                                            // 0x0800   (0x07F0)  
	FSplitterStyle                                     ColumnSplitterStyle;                                        // 0x0FF0   (0x01D0)  
	FSlateBrush                                        BackgroundBrush;                                            // 0x11C0   (0x00E0)  
	FSlateColor                                        ForegroundColor;                                            // 0x12A0   (0x0028)  
	unsigned char                                      UnknownData01_6[0x8];                                       // 0x12C8   (0x0008)  MISSED
};

/// Struct /Script/SlateCore.SplitterStyle
/// Size: 0x01C8 (0x000008 - 0x0001D0)
struct FSplitterStyle : FSlateWidgetStyle
{ 
	unsigned char                                      UnknownData00_2[0x8];                                       // 0x0008   (0x0008)  MISSED
	FSlateBrush                                        HandleNormalBrush;                                          // 0x0010   (0x00E0)  
	FSlateBrush                                        HandleHighlightBrush;                                       // 0x00F0   (0x00E0)  
};

/// Struct /Script/SlateCore.TableColumnHeaderStyle
/// Size: 0x07E8 (0x000008 - 0x0007F0)
struct FTableColumnHeaderStyle : FSlateWidgetStyle
{ 
	unsigned char                                      UnknownData00_2[0x8];                                       // 0x0008   (0x0008)  MISSED
	FSlateBrush                                        SortPrimaryAscendingImage;                                  // 0x0010   (0x00E0)  
	FSlateBrush                                        SortPrimaryDescendingImage;                                 // 0x00F0   (0x00E0)  
	FSlateBrush                                        SortSecondaryAscendingImage;                                // 0x01D0   (0x00E0)  
	FSlateBrush                                        SortSecondaryDescendingImage;                               // 0x02B0   (0x00E0)  
	FSlateBrush                                        NormalBrush;                                                // 0x0390   (0x00E0)  
	FSlateBrush                                        HoveredBrush;                                               // 0x0470   (0x00E0)  
	FSlateBrush                                        MenuDropdownImage;                                          // 0x0550   (0x00E0)  
	FSlateBrush                                        MenuDropdownNormalBorderBrush;                              // 0x0630   (0x00E0)  
	FSlateBrush                                        MenuDropdownHoveredBorderBrush;                             // 0x0710   (0x00E0)  
};

/// Struct /Script/SlateCore.InlineTextImageStyle
/// Size: 0x00F8 (0x000008 - 0x000100)
struct FInlineTextImageStyle : FSlateWidgetStyle
{ 
	unsigned char                                      UnknownData00_2[0x8];                                       // 0x0008   (0x0008)  MISSED
	FSlateBrush                                        Image;                                                      // 0x0010   (0x00E0)  
	int16_t                                            Baseline;                                                   // 0x00F0   (0x0002)  
	unsigned char                                      UnknownData01_6[0xE];                                       // 0x00F2   (0x000E)  MISSED
};

/// Struct /Script/SlateCore.VolumeControlStyle
/// Size: 0x09C8 (0x000008 - 0x0009D0)
struct FVolumeControlStyle : FSlateWidgetStyle
{ 
	unsigned char                                      UnknownData00_2[0x8];                                       // 0x0008   (0x0008)  MISSED
	FSliderStyle                                       SliderStyle;                                                // 0x0010   (0x0560)  
	FSlateBrush                                        HighVolumeImage;                                            // 0x0570   (0x00E0)  
	FSlateBrush                                        MidVolumeImage;                                             // 0x0650   (0x00E0)  
	FSlateBrush                                        LowVolumeImage;                                             // 0x0730   (0x00E0)  
	FSlateBrush                                        NoVolumeImage;                                              // 0x0810   (0x00E0)  
	FSlateBrush                                        MutedImage;                                                 // 0x08F0   (0x00E0)  
};

/// Struct /Script/SlateCore.SliderStyle
/// Size: 0x0558 (0x000008 - 0x000560)
struct FSliderStyle : FSlateWidgetStyle
{ 
	unsigned char                                      UnknownData00_2[0x8];                                       // 0x0008   (0x0008)  MISSED
	FSlateBrush                                        NormalBarImage;                                             // 0x0010   (0x00E0)  
	FSlateBrush                                        HoveredBarImage;                                            // 0x00F0   (0x00E0)  
	FSlateBrush                                        DisabledBarImage;                                           // 0x01D0   (0x00E0)  
	FSlateBrush                                        NormalThumbImage;                                           // 0x02B0   (0x00E0)  
	FSlateBrush                                        HoveredThumbImage;                                          // 0x0390   (0x00E0)  
	FSlateBrush                                        DisabledThumbImage;                                         // 0x0470   (0x00E0)  
	float                                              BarThickness;                                               // 0x0550   (0x0004)  
	unsigned char                                      UnknownData01_6[0xC];                                       // 0x0554   (0x000C)  MISSED
};

/// Struct /Script/SlateCore.SearchBoxStyle
/// Size: 0x1098 (0x000008 - 0x0010A0)
struct FSearchBoxStyle : FSlateWidgetStyle
{ 
	unsigned char                                      UnknownData00_2[0x8];                                       // 0x0008   (0x0008)  MISSED
	FEditableTextBoxStyle                              TextBoxStyle;                                               // 0x0010   (0x0C90)  
	FSlateFontInfo                                     ActiveFontInfo;                                             // 0x0CA0   (0x0060)  
	FSlateBrush                                        UpArrowImage;                                               // 0x0D00   (0x00E0)  
	FSlateBrush                                        DownArrowImage;                                             // 0x0DE0   (0x00E0)  
	FSlateBrush                                        GlassImage;                                                 // 0x0EC0   (0x00E0)  
	FSlateBrush                                        ClearImage;                                                 // 0x0FA0   (0x00E0)  
	FMargin                                            ImagePadding;                                               // 0x1080   (0x0010)  
	bool                                               bLeftAlignButtons;                                          // 0x1090   (0x0001)  
	unsigned char                                      UnknownData01_6[0xF];                                       // 0x1091   (0x000F)  MISSED
};

/// Struct /Script/SlateCore.ExpandableAreaStyle
/// Size: 0x01D8 (0x000008 - 0x0001E0)
struct FExpandableAreaStyle : FSlateWidgetStyle
{ 
	unsigned char                                      UnknownData00_2[0x8];                                       // 0x0008   (0x0008)  MISSED
	FSlateBrush                                        CollapsedImage;                                             // 0x0010   (0x00E0)  
	FSlateBrush                                        ExpandedImage;                                              // 0x00F0   (0x00E0)  
	float                                              RolloutAnimationSeconds;                                    // 0x01D0   (0x0004)  
	unsigned char                                      UnknownData01_6[0xC];                                       // 0x01D4   (0x000C)  MISSED
};

/// Struct /Script/SlateCore.ProgressBarStyle
/// Size: 0x02A8 (0x000008 - 0x0002B0)
struct FProgressBarStyle : FSlateWidgetStyle
{ 
	unsigned char                                      UnknownData00_2[0x8];                                       // 0x0008   (0x0008)  MISSED
	FSlateBrush                                        BackgroundImage;                                            // 0x0010   (0x00E0)  
	FSlateBrush                                        FillImage;                                                  // 0x00F0   (0x00E0)  
	FSlateBrush                                        MarqueeImage;                                               // 0x01D0   (0x00E0)  
};

/// Struct /Script/SlateCore.InlineEditableTextBlockStyle
/// Size: 0x10F8 (0x000008 - 0x001100)
struct FInlineEditableTextBlockStyle : FSlateWidgetStyle
{ 
	unsigned char                                      UnknownData00_2[0x8];                                       // 0x0008   (0x0008)  MISSED
	FEditableTextBoxStyle                              EditableTextBoxStyle;                                       // 0x0010   (0x0C90)  
	FTextBlockStyle                                    TextStyle;                                                  // 0x0CA0   (0x0460)  
};

/// Struct /Script/SlateCore.CheckBoxStyle
/// Size: 0x0898 (0x000008 - 0x0008A0)
struct FCheckBoxStyle : FSlateWidgetStyle
{ 
	TEnumAsByte<ESlateCheckBoxType>                    CheckBoxType;                                               // 0x0008   (0x0001)  
	unsigned char                                      UnknownData00_5[0x7];                                       // 0x0009   (0x0007)  MISSED
	FSlateBrush                                        UncheckedImage;                                             // 0x0010   (0x00E0)  
	FSlateBrush                                        UncheckedHoveredImage;                                      // 0x00F0   (0x00E0)  
	FSlateBrush                                        UncheckedPressedImage;                                      // 0x01D0   (0x00E0)  
	FSlateBrush                                        CheckedImage;                                               // 0x02B0   (0x00E0)  
	FSlateBrush                                        CheckedHoveredImage;                                        // 0x0390   (0x00E0)  
	FSlateBrush                                        CheckedPressedImage;                                        // 0x0470   (0x00E0)  
	FSlateBrush                                        UndeterminedImage;                                          // 0x0550   (0x00E0)  
	FSlateBrush                                        UndeterminedHoveredImage;                                   // 0x0630   (0x00E0)  
	FSlateBrush                                        UndeterminedPressedImage;                                   // 0x0710   (0x00E0)  
	FMargin                                            Padding;                                                    // 0x07F0   (0x0010)  
	FSlateColor                                        ForegroundColor;                                            // 0x0800   (0x0028)  
	FSlateColor                                        BorderBackgroundColor;                                      // 0x0828   (0x0028)  
	FSlateSound                                        CheckedSlateSound;                                          // 0x0850   (0x0018)  
	FSlateSound                                        UncheckedSlateSound;                                        // 0x0868   (0x0018)  
	FSlateSound                                        HoveredSlateSound;                                          // 0x0880   (0x0018)  
	unsigned char                                      UnknownData01_6[0x8];                                       // 0x0898   (0x0008)  MISSED
};

/// Enum /Script/SlateCore.EUINavigation
/// Size: 0x09
enum EUINavigation : uint8_t
{
	EUINavigation__Left                                                              = 0,
	EUINavigation__Right                                                             = 1,
	EUINavigation__Up                                                                = 2,
	EUINavigation__Down                                                              = 3,
	EUINavigation__Next                                                              = 4,
	EUINavigation__Previous                                                          = 5,
	EUINavigation__Num                                                               = 6,
	EUINavigation__Invalid                                                           = 7,
	EUINavigation__EUINavigation_MAX                                                 = 8
};

/// Enum /Script/SlateCore.ECheckBoxState
/// Size: 0x04
enum ECheckBoxState : uint8_t
{
	ECheckBoxState__Unchecked                                                        = 0,
	ECheckBoxState__Checked                                                          = 1,
	ECheckBoxState__Undetermined                                                     = 2,
	ECheckBoxState__ECheckBoxState_MAX                                               = 3
};

/// Enum /Script/SlateCore.EWidgetClipping
/// Size: 0x06
enum EWidgetClipping : uint8_t
{
	EWidgetClipping__Inherit                                                         = 0,
	EWidgetClipping__ClipToBounds                                                    = 1,
	EWidgetClipping__ClipToBoundsWithoutIntersecting                                 = 2,
	EWidgetClipping__ClipToBoundsAlways                                              = 3,
	EWidgetClipping__OnDemand                                                        = 4,
	EWidgetClipping__EWidgetClipping_MAX                                             = 5
};

/// Enum /Script/SlateCore.ESlateBrushImageType
/// Size: 0x05
enum ESlateBrushImageType : uint8_t
{
	ESlateBrushImageType__NoImage                                                    = 0,
	ESlateBrushImageType__FullColor                                                  = 1,
	ESlateBrushImageType__Linear                                                     = 2,
	ESlateBrushImageType__Vector                                                     = 3,
	ESlateBrushImageType__ESlateBrushImageType_MAX                                   = 4
};

/// Enum /Script/SlateCore.ESlateBrushMirrorType
/// Size: 0x05
enum ESlateBrushMirrorType : uint8_t
{
	ESlateBrushMirrorType__NoMirror                                                  = 0,
	ESlateBrushMirrorType__Horizontal                                                = 1,
	ESlateBrushMirrorType__Vertical                                                  = 2,
	ESlateBrushMirrorType__Both                                                      = 3,
	ESlateBrushMirrorType__ESlateBrushMirrorType_MAX                                 = 4
};

/// Enum /Script/SlateCore.ESlateBrushTileType
/// Size: 0x05
enum ESlateBrushTileType : uint8_t
{
	ESlateBrushTileType__NoTile                                                      = 0,
	ESlateBrushTileType__Horizontal                                                  = 1,
	ESlateBrushTileType__Vertical                                                    = 2,
	ESlateBrushTileType__Both                                                        = 3,
	ESlateBrushTileType__ESlateBrushTileType_MAX                                     = 4
};

/// Enum /Script/SlateCore.ESlateBrushDrawType
/// Size: 0x06
enum ESlateBrushDrawType : uint8_t
{
	ESlateBrushDrawType__NoDrawType                                                  = 0,
	ESlateBrushDrawType__Box                                                         = 1,
	ESlateBrushDrawType__Border                                                      = 2,
	ESlateBrushDrawType__Image                                                       = 3,
	ESlateBrushDrawType__RoundedBox                                                  = 4,
	ESlateBrushDrawType__ESlateBrushDrawType_MAX                                     = 5
};

/// Enum /Script/SlateCore.ESlateBrushRoundingType
/// Size: 0x03
enum ESlateBrushRoundingType : uint8_t
{
	ESlateBrushRoundingType__FixedRadius                                             = 0,
	ESlateBrushRoundingType__HalfHeightRadius                                        = 1,
	ESlateBrushRoundingType__ESlateBrushRoundingType_MAX                             = 2
};

/// Enum /Script/SlateCore.ESlateColorStylingMode
/// Size: 0x05
enum ESlateColorStylingMode : uint8_t
{
	ESlateColorStylingMode__UseColor_Specified                                       = 0,
	ESlateColorStylingMode__UseColor_Specified_Link                                  = 1,
	ESlateColorStylingMode__UseColor_Foreground                                      = 2,
	ESlateColorStylingMode__UseColor_Foreground_Subdued                              = 3,
	ESlateColorStylingMode__UseColor_MAX                                             = 4
};

/// Enum /Script/SlateCore.EUINavigationRule
/// Size: 0x08
enum EUINavigationRule : uint8_t
{
	EUINavigationRule__Escape                                                        = 0,
	EUINavigationRule__Explicit                                                      = 1,
	EUINavigationRule__Wrap                                                          = 2,
	EUINavigationRule__Stop                                                          = 3,
	EUINavigationRule__Custom                                                        = 4,
	EUINavigationRule__CustomBoundary                                                = 5,
	EUINavigationRule__Invalid                                                       = 6,
	EUINavigationRule__EUINavigationRule_MAX                                         = 7
};

/// Enum /Script/SlateCore.ESlateDetailMode
/// Size: 0x04
enum ESlateDetailMode : uint8_t
{
	Stale_Low                                                                        = 0,
	Stale_Medium                                                                     = 1,
	Stale_High                                                                       = 2,
	Stale_MAX                                                                        = 3
};

/// Enum /Script/SlateCore.EFlowDirectionPreference
/// Size: 0x05
enum EFlowDirectionPreference : uint8_t
{
	EFlowDirectionPreference__Inherit                                                = 0,
	EFlowDirectionPreference__Culture                                                = 1,
	EFlowDirectionPreference__LeftToRight                                            = 2,
	EFlowDirectionPreference__RightToLeft                                            = 3,
	EFlowDirectionPreference__EFlowDirectionPreference_MAX                           = 4
};

/// Enum /Script/SlateCore.EColorVisionDeficiency
/// Size: 0x05
enum EColorVisionDeficiency : uint8_t
{
	EColorVisionDeficiency__NormalVision                                             = 0,
	EColorVisionDeficiency__Deuteranope                                              = 1,
	EColorVisionDeficiency__Protanope                                                = 2,
	EColorVisionDeficiency__Tritanope                                                = 3,
	EColorVisionDeficiency__EColorVisionDeficiency_MAX                               = 4
};

/// Enum /Script/SlateCore.ESelectInfo
/// Size: 0x05
enum ESelectInfo : uint8_t
{
	ESelectInfo__OnKeyPress                                                          = 0,
	ESelectInfo__OnNavigation                                                        = 1,
	ESelectInfo__OnMouseClick                                                        = 2,
	ESelectInfo__Direct                                                              = 3,
	ESelectInfo__ESelectInfo_MAX                                                     = 4
};

/// Enum /Script/SlateCore.ETextCommit
/// Size: 0x05
enum ETextCommit : uint8_t
{
	ETextCommit__Default                                                             = 0,
	ETextCommit__OnEnter                                                             = 1,
	ETextCommit__OnUserMovedFocus                                                    = 2,
	ETextCommit__OnCleared                                                           = 3,
	ETextCommit__ETextCommit_MAX                                                     = 4
};

/// Enum /Script/SlateCore.ETextShapingMethod
/// Size: 0x04
enum ETextShapingMethod : uint8_t
{
	ETextShapingMethod__Auto                                                         = 0,
	ETextShapingMethod__KerningOnly                                                  = 1,
	ETextShapingMethod__FullShaping                                                  = 2,
	ETextShapingMethod__ETextShapingMethod_MAX                                       = 3
};

/// Enum /Script/SlateCore.EHorizontalAlignment
/// Size: 0x05
enum EHorizontalAlignment : uint8_t
{
	HAlign_Fill                                                                      = 0,
	HAlign_Left                                                                      = 1,
	HAlign_Center                                                                    = 2,
	HAlign_Right                                                                     = 3,
	HAlign_MAX                                                                       = 4
};

/// Enum /Script/SlateCore.EVerticalAlignment
/// Size: 0x05
enum EVerticalAlignment : uint8_t
{
	VAlign_Fill                                                                      = 0,
	VAlign_Top                                                                       = 1,
	VAlign_Center                                                                    = 2,
	VAlign_Bottom                                                                    = 3,
	VAlign_MAX                                                                       = 4
};

/// Enum /Script/SlateCore.EFontLayoutMethod
/// Size: 0x03
enum EFontLayoutMethod : uint8_t
{
	EFontLayoutMethod__Metrics                                                       = 0,
	EFontLayoutMethod__BoundingBox                                                   = 1,
	EFontLayoutMethod__EFontLayoutMethod_MAX                                         = 2
};

/// Enum /Script/SlateCore.EFontLoadingPolicy
/// Size: 0x04
enum EFontLoadingPolicy : uint8_t
{
	EFontLoadingPolicy__LazyLoad                                                     = 0,
	EFontLoadingPolicy__Stream                                                       = 1,
	EFontLoadingPolicy__Inline                                                       = 2,
	EFontLoadingPolicy__EFontLoadingPolicy_MAX                                       = 3
};

/// Enum /Script/SlateCore.EFontHinting
/// Size: 0x06
enum EFontHinting : uint8_t
{
	EFontHinting__Default                                                            = 0,
	EFontHinting__Auto                                                               = 1,
	EFontHinting__AutoLight                                                          = 2,
	EFontHinting__Monochrome                                                         = 3,
	EFontHinting__None                                                               = 4,
	EFontHinting__EFontHinting_MAX                                                   = 5
};

/// Enum /Script/SlateCore.EFocusCause
/// Size: 0x07
enum EFocusCause : uint8_t
{
	EFocusCause__Mouse                                                               = 0,
	EFocusCause__Navigation                                                          = 1,
	EFocusCause__SetDirectly                                                         = 2,
	EFocusCause__Cleared                                                             = 3,
	EFocusCause__OtherWidgetLostFocus                                                = 4,
	EFocusCause__WindowActivate                                                      = 5,
	EFocusCause__EFocusCause_MAX                                                     = 6
};

/// Enum /Script/SlateCore.ESlateDebuggingFocusEvent
/// Size: 0x04
enum ESlateDebuggingFocusEvent : uint8_t
{
	ESlateDebuggingFocusEvent__FocusChanging                                         = 0,
	ESlateDebuggingFocusEvent__FocusLost                                             = 1,
	ESlateDebuggingFocusEvent__FocusReceived                                         = 2,
	ESlateDebuggingFocusEvent__MAX                                                   = 3
};

/// Enum /Script/SlateCore.ESlateDebuggingNavigationMethod
/// Size: 0x07
enum ESlateDebuggingNavigationMethod : uint8_t
{
	ESlateDebuggingNavigationMethod__Unknown                                         = 0,
	ESlateDebuggingNavigationMethod__Explicit                                        = 1,
	ESlateDebuggingNavigationMethod__CustomDelegateBound                             = 2,
	ESlateDebuggingNavigationMethod__CustomDelegateUnbound                           = 3,
	ESlateDebuggingNavigationMethod__NextOrPrevious                                  = 4,
	ESlateDebuggingNavigationMethod__HitTestGrid                                     = 5,
	ESlateDebuggingNavigationMethod__ESlateDebuggingNavigationMethod_MAX             = 6
};

/// Enum /Script/SlateCore.ESlateDebuggingStateChangeEvent
/// Size: 0x03
enum ESlateDebuggingStateChangeEvent : uint8_t
{
	ESlateDebuggingStateChangeEvent__MouseCaptureGained                              = 0,
	ESlateDebuggingStateChangeEvent__MouseCaptureLost                                = 1,
	ESlateDebuggingStateChangeEvent__ESlateDebuggingStateChangeEvent_MAX             = 2
};

/// Enum /Script/SlateCore.ESlateDebuggingInputEvent
/// Size: 0x27
enum ESlateDebuggingInputEvent : uint8_t
{
	ESlateDebuggingInputEvent__MouseMove                                             = 0,
	ESlateDebuggingInputEvent__MouseEnter                                            = 1,
	ESlateDebuggingInputEvent__MouseLeave                                            = 2,
	ESlateDebuggingInputEvent__PreviewMouseButtonDown                                = 3,
	ESlateDebuggingInputEvent__MouseButtonDown                                       = 4,
	ESlateDebuggingInputEvent__MouseButtonUp                                         = 5,
	ESlateDebuggingInputEvent__MouseButtonDoubleClick                                = 6,
	ESlateDebuggingInputEvent__MouseWheel                                            = 7,
	ESlateDebuggingInputEvent__TouchStart                                            = 8,
	ESlateDebuggingInputEvent__TouchEnd                                              = 9,
	ESlateDebuggingInputEvent__TouchForceChanged                                     = 10,
	ESlateDebuggingInputEvent__TouchFirstMove                                        = 11,
	ESlateDebuggingInputEvent__TouchMoved                                            = 12,
	ESlateDebuggingInputEvent__DragDetected                                          = 13,
	ESlateDebuggingInputEvent__DragEnter                                             = 14,
	ESlateDebuggingInputEvent__DragLeave                                             = 15,
	ESlateDebuggingInputEvent__DragOver                                              = 16,
	ESlateDebuggingInputEvent__DragDrop                                              = 17,
	ESlateDebuggingInputEvent__DropMessage                                           = 18,
	ESlateDebuggingInputEvent__PreviewKeyDown                                        = 19,
	ESlateDebuggingInputEvent__KeyDown                                               = 20,
	ESlateDebuggingInputEvent__KeyUp                                                 = 21,
	ESlateDebuggingInputEvent__KeyChar                                               = 22,
	ESlateDebuggingInputEvent__AnalogInput                                           = 23,
	ESlateDebuggingInputEvent__TouchGesture                                          = 24,
	ESlateDebuggingInputEvent__MotionDetected                                        = 25,
	ESlateDebuggingInputEvent__MAX                                                   = 26
};

/// Enum /Script/SlateCore.EScrollDirection
/// Size: 0x03
enum EScrollDirection : uint8_t
{
	Scroll_Down                                                                      = 0,
	Scroll_Up                                                                        = 1,
	Scroll_MAX                                                                       = 2
};

/// Enum /Script/SlateCore.EOrientation
/// Size: 0x03
enum EOrientation : uint8_t
{
	Orient_Horizontal                                                                = 0,
	Orient_Vertical                                                                  = 1,
	Orient_MAX                                                                       = 2
};

/// Enum /Script/SlateCore.EMenuPlacement
/// Size: 0x14
enum EMenuPlacement : uint8_t
{
	MenuPlacement_BelowAnchor                                                        = 0,
	MenuPlacement_CenteredBelowAnchor                                                = 1,
	MenuPlacement_BelowRightAnchor                                                   = 2,
	MenuPlacement_ComboBox                                                           = 3,
	MenuPlacement_ComboBoxRight                                                      = 4,
	MenuPlacement_MenuRight                                                          = 5,
	MenuPlacement_AboveAnchor                                                        = 6,
	MenuPlacement_CenteredAboveAnchor                                                = 7,
	MenuPlacement_AboveRightAnchor                                                   = 8,
	MenuPlacement_MenuLeft                                                           = 9,
	MenuPlacement_Center                                                             = 10,
	MenuPlacement_RightLeftCenter                                                    = 11,
	MenuPlacement_MatchBottomLeft                                                    = 12,
	MenuPlacement_MAX                                                                = 13
};

/// Enum /Script/SlateCore.ENavigationGenesis
/// Size: 0x04
enum ENavigationGenesis : uint8_t
{
	ENavigationGenesis__Keyboard                                                     = 0,
	ENavigationGenesis__Controller                                                   = 1,
	ENavigationGenesis__User                                                         = 2,
	ENavigationGenesis__ENavigationGenesis_MAX                                       = 3
};

/// Enum /Script/SlateCore.ENavigationSource
/// Size: 0x03
enum ENavigationSource : uint8_t
{
	ENavigationSource__FocusedWidget                                                 = 0,
	ENavigationSource__WidgetUnderCursor                                             = 1,
	ENavigationSource__ENavigationSource_MAX                                         = 2
};

/// Enum /Script/SlateCore.EUINavigationAction
/// Size: 0x05
enum EUINavigationAction : uint8_t
{
	EUINavigationAction__Accept                                                      = 0,
	EUINavigationAction__Back                                                        = 1,
	EUINavigationAction__Num                                                         = 2,
	EUINavigationAction__Invalid                                                     = 3,
	EUINavigationAction__EUINavigationAction_MAX                                     = 4
};

/// Enum /Script/SlateCore.EButtonPressMethod
/// Size: 0x04
enum EButtonPressMethod : uint8_t
{
	EButtonPressMethod__DownAndUp                                                    = 0,
	EButtonPressMethod__ButtonPress                                                  = 1,
	EButtonPressMethod__ButtonRelease                                                = 2,
	EButtonPressMethod__EButtonPressMethod_MAX                                       = 3
};

/// Enum /Script/SlateCore.EButtonTouchMethod
/// Size: 0x04
enum EButtonTouchMethod : uint8_t
{
	EButtonTouchMethod__DownAndUp                                                    = 0,
	EButtonTouchMethod__Down                                                         = 1,
	EButtonTouchMethod__PreciseTap                                                   = 2,
	EButtonTouchMethod__EButtonTouchMethod_MAX                                       = 3
};

/// Enum /Script/SlateCore.EButtonClickMethod
/// Size: 0x05
enum EButtonClickMethod : uint8_t
{
	EButtonClickMethod__DownAndUp                                                    = 0,
	EButtonClickMethod__MouseDown                                                    = 1,
	EButtonClickMethod__MouseUp                                                      = 2,
	EButtonClickMethod__PreciseClick                                                 = 3,
	EButtonClickMethod__EButtonClickMethod_MAX                                       = 4
};

/// Enum /Script/SlateCore.ESlateCheckBoxType
/// Size: 0x03
enum ESlateCheckBoxType : uint8_t
{
	ESlateCheckBoxType__CheckBox                                                     = 0,
	ESlateCheckBoxType__ToggleButton                                                 = 1,
	ESlateCheckBoxType__ESlateCheckBoxType_MAX                                       = 2
};

/// Enum /Script/SlateCore.ESlateParentWindowSearchMethod
/// Size: 0x03
enum ESlateParentWindowSearchMethod : uint8_t
{
	ESlateParentWindowSearchMethod__ActiveWindow                                     = 0,
	ESlateParentWindowSearchMethod__MainWindow                                       = 1,
	ESlateParentWindowSearchMethod__ESlateParentWindowSearchMethod_MAX               = 2
};

/// Enum /Script/SlateCore.EConsumeMouseWheel
/// Size: 0x04
enum EConsumeMouseWheel : uint8_t
{
	EConsumeMouseWheel__WhenScrollingPossible                                        = 0,
	EConsumeMouseWheel__Always                                                       = 1,
	EConsumeMouseWheel__Never                                                        = 2,
	EConsumeMouseWheel__EConsumeMouseWheel_MAX                                       = 3
};

