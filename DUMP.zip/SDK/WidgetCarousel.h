/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package WidgetCarousel.

/// Struct /Script/WidgetCarousel.WidgetCarouselNavigationBarStyle
/// Size: 0x0C88 (0x000008 - 0x000C90)
struct FWidgetCarouselNavigationBarStyle : FSlateWidgetStyle
{ 
	unsigned char                                      UnknownData00_2[0x8];                                       // 0x0008   (0x0008)  MISSED
	FSlateBrush                                        HighlightBrush;                                             // 0x0010   (0x00E0)  
	FButtonStyle                                       LeftButtonStyle;                                            // 0x00F0   (0x03E0)  
	FButtonStyle                                       CenterButtonStyle;                                          // 0x04D0   (0x03E0)  
	FButtonStyle                                       RightButtonStyle;                                           // 0x08B0   (0x03E0)  
};

/// Struct /Script/WidgetCarousel.WidgetCarouselNavigationButtonStyle
/// Size: 0x05A8 (0x000008 - 0x0005B0)
struct FWidgetCarouselNavigationButtonStyle : FSlateWidgetStyle
{ 
	unsigned char                                      UnknownData00_2[0x8];                                       // 0x0008   (0x0008)  MISSED
	FButtonStyle                                       InnerButtonStyle;                                           // 0x0010   (0x03E0)  
	FSlateBrush                                        NavigationButtonLeftImage;                                  // 0x03F0   (0x00E0)  
	FSlateBrush                                        NavigationButtonRightImage;                                 // 0x04D0   (0x00E0)  
};

