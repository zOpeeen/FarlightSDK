/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package LLHSDK.

/// Class /Script/LLHSDK.LLHSDKAppUtils
/// Size: 0x0010 (0x000028 - 0x000038)
class ULLHSDKAppUtils : public UObject
{ 
public:
	FMulticastInlineDelegate                           OnSteamUserStatesUpdate;                                    // 0x0028   (0x0010)  


	/// Functions
	// Function /Script/LLHSDK.LLHSDKAppUtils.ShowSteamVirtualKeyboard
	bool ShowSteamVirtualKeyboard();                                                                                         // [0x9f2ce0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.SDKConfigIsMultiDetect
	bool SDKConfigIsMultiDetect();                                                                                           // [0x9f2af0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.SDKConfigIsDebug
	bool SDKConfigIsDebug();                                                                                                 // [0x9f2ac0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.OnSteamUserStatesUpdate__DelegateSignature
	void OnSteamUserStatesUpdate__DelegateSignature(FString SteamId, bool IsFriend, bool Online, FString FriendName);        // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKAppUtils.IsSteamFriendOnline
	bool IsSteamFriendOnline(FString SteamId);                                                                               // [0x9f2a20] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.IsSimulator
	bool IsSimulator();                                                                                                      // [0x95ff20] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.IsPlatformSteamDeck
	bool IsPlatformSteamDeck();                                                                                              // [0x9f29f0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.IsPackageInstalled
	bool IsPackageInstalled(FString InPackageName);                                                                          // [0x9f2900] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.IsGrayRelease
	bool IsGrayRelease();                                                                                                    // [0x95ff20] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.InviteSteamUserToGame
	bool InviteSteamUserToGame(FString SteamId);                                                                             // [0x9f2860] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.GetVersionName
	FString GetVersionName();                                                                                                // [0x9f2110] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.GetVersionCode
	FString GetVersionCode();                                                                                                // [0x9f2110] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.GetSteamFriendsOnlineList
	TArray<bool> GetSteamFriendsOnlineList();                                                                                // [0x9f26a0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.GetSteamFriendsNameList
	TArray<FString> GetSteamFriendsNameList();                                                                               // [0x9f2620] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.GetSteamFriendName
	FString GetSteamFriendName(FString SteamId);                                                                             // [0x9f2540] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.GetSteamFriendIDList
	TArray<FString> GetSteamFriendIDList();                                                                                  // [0x9f24c0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.GetSteamFriendCount
	int32_t GetSteamFriendCount();                                                                                           // [0x9f2490] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.GetSDKVersionName
	FString GetSDKVersionName();                                                                                             // [0x9f2110] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.GetSDKVersionCode
	FString GetSDKVersionCode();                                                                                             // [0x9f2110] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.GetRunningProcessName
	FString GetRunningProcessName();                                                                                         // [0x9f2110] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.GetOperatingSystemId
	FString GetOperatingSystemId();                                                                                          // [0x9f2410] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.GetInstance
	ULLHSDKAppUtils* GetInstance();                                                                                          // [0x9f2380] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.GetGameTime
	int64_t GetGameTime();                                                                                                   // [0x9f2350] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.GetGameID
	FString GetGameID();                                                                                                     // [0x9f2110] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.GetEnvId
	FString GetEnvId();                                                                                                      // [0x9f22d0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.GetDeviceUUID
	FString GetDeviceUUID();                                                                                                 // [0x9f2110] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.GetChannelID
	FString GetChannelID();                                                                                                  // [0x9f2110] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.GetBiosUUID
	FString GetBiosUUID();                                                                                                   // [0x9f2090] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.GetAppName
	FString GetAppName();                                                                                                    // [0x9f2010] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.GetAppIDRaw
	FString GetAppIDRaw();                                                                                                   // [0x9f1f90] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.GetAppID
	FString GetAppID();                                                                                                      // [0x9f1f10] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.DoesDistributeForDomestic
	bool DoesDistributeForDomestic();                                                                                        // [0x9f1cb0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.DismissSteamVirtualKeyboard
	void DismissSteamVirtualKeyboard();                                                                                      // [0x9f1c90] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.DestoryInstance
	void DestoryInstance();                                                                                                  // [0x9f1c30] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKAppUtils.BindOnlineSubsystemSteamPresence
	void BindOnlineSubsystemSteamPresence();                                                                                 // [0x9f1ad0] Final|Native|Static|Public|BlueprintCallable 
};

/// Class /Script/LLHSDK.LLHSDKCommunity
/// Size: 0x0050 (0x000028 - 0x000078)
class ULLHSDKCommunity : public UObject
{ 
public:
	FMulticastInlineDelegate                           OnInitCommunity;                                            // 0x0028   (0x0010)  
	FMulticastInlineDelegate                           OnExitCommunity;                                            // 0x0038   (0x0010)  
	FMulticastInlineDelegate                           OnGetCommunityRedhint;                                      // 0x0048   (0x0010)  
	FMulticastInlineDelegate                           OnClearCommunityRedhint;                                    // 0x0058   (0x0010)  
	FMulticastInlineDelegate                           OnImageDownload;                                            // 0x0068   (0x0010)  


	/// Functions
	// Function /Script/LLHSDK.LLHSDKCommunity.OnInitCommunity__DelegateSignature
	void OnInitCommunity__DelegateSignature(FString ResultStr);                                                              // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKCommunity.OnImageDownload__DelegateSignature
	void OnImageDownload__DelegateSignature(bool bSuccess);                                                                  // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKCommunity.OnGetCommunityRedhint__DelegateSignature
	void OnGetCommunityRedhint__DelegateSignature(FString ResultStr);                                                        // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKCommunity.OnExitCommunity__DelegateSignature
	void OnExitCommunity__DelegateSignature(FString ResultStr);                                                              // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKCommunity.OnClearCommunityRedhint__DelegateSignature
	void OnClearCommunityRedhint__DelegateSignature(FString ResultStr);                                                      // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKCommunity.InitCommunityConfig
	void InitCommunityConfig(FString UrlInfo, FString ReqMethod, FString ExtraHttpParams);                                   // [0x9f2720] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKCommunity.GetInstance
	ULLHSDKCommunity* GetInstance();                                                                                         // [0x9f23b0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKCommunity.GetCommunityRedHint
	void GetCommunityRedHint(FString URL, FString ReqMethod, FString ExtraHttpParams);                                       // [0x9f2190] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKCommunity.ExitCommunity
	void ExitCommunity(FString URL, FString ReqMethod, FString ExtraHttpParams);                                             // [0x9f1dd0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKCommunity.DownloadImage
	void DownloadImage(FString URL, FString FilePath);                                                                       // [0x9f1ce0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKCommunity.DestoryInstance
	void DestoryInstance();                                                                                                  // [0x9f1c50] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKCommunity.ClearCommunityRedHint
	void ClearCommunityRedHint(FString URL, FString ReqMethod, FString ExtraHttpParams);                                     // [0x9f1af0] Final|Native|Static|Public|BlueprintCallable 
};

/// Class /Script/LLHSDK.LLHSDKCustomerService
/// Size: 0x0018 (0x000028 - 0x000040)
class ULLHSDKCustomerService : public UObject
{ 
public:
	FMulticastInlineDelegate                           OnReceiveNotification;                                      // 0x0028   (0x0010)  
	unsigned char                                      UnknownData00_6[0x8];                                       // 0x0038   (0x0008)  MISSED


	/// Functions
	// Function /Script/LLHSDK.LLHSDKCustomerService.ShowCustomerServicePage
	void ShowCustomerServicePage(FString ExtInfoStr);                                                                        // [0x9f2c50] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKCustomerService.SetCustomerServiceDebug
	void SetCustomerServiceDebug(bool& bIsPspDebug, FString PlayerId, int64_t ServerId);                                     // [0x9f2b20] Final|Native|Static|Public|HasOutParms|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKCustomerService.OnReceiveNotification__DelegateSignature
	void OnReceiveNotification__DelegateSignature(int32_t NotificationType);                                                 // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKCustomerService.GetInstance
	ULLHSDKCustomerService* GetInstance();                                                                                   // [0x9f23e0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKCustomerService.DestoryInstance
	void DestoryInstance();                                                                                                  // [0x9f1c70] Final|Native|Static|Public|BlueprintCallable 
};

/// Class /Script/LLHSDK.LLHSDKDeviceUtils
/// Size: 0x0020 (0x000028 - 0x000048)
class ULLHSDKDeviceUtils : public UObject
{ 
public:
	FMulticastInlineDelegate                           OnGoogleAdID;                                               // 0x0028   (0x0010)  
	FMulticastInlineDelegate                           OnDeviceScore;                                              // 0x0038   (0x0010)  


	/// Functions
	// Function /Script/LLHSDK.LLHSDKDeviceUtils.OnGoogleAdID__DelegateSignature
	void OnGoogleAdID__DelegateSignature(FString GoogleAdID);                                                                // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKDeviceUtils.OnDeviceScore__DelegateSignature
	void OnDeviceScore__DelegateSignature(int32_t DeviceScore);                                                              // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKDeviceUtils.IsEmulator
	bool IsEmulator();                                                                                                       // [0x9f5b60] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKDeviceUtils.GetTotalRAM
	FString GetTotalRAM();                                                                                                   // [0x9f6ad0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKDeviceUtils.GetTotalMemorySize
	FString GetTotalMemorySize();                                                                                            // [0x9f6a50] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKDeviceUtils.GetTimezoneName
	FString GetTimezoneName();                                                                                               // [0x9f69d0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKDeviceUtils.GetOSVersion
	FString GetOSVersion();                                                                                                  // [0x9f6830] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKDeviceUtils.GetNetworkTypeEnum
	ELLHSDKNetworkType GetNetworkTypeEnum();                                                                                 // [0x9f6800] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKDeviceUtils.GetNetworkType
	FString GetNetworkType();                                                                                                // [0x9f6780] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKDeviceUtils.GetMacAddress
	FString GetMacAddress();                                                                                                 // [0x9f2110] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKDeviceUtils.GetInstance
	ULLHSDKDeviceUtils* GetInstance();                                                                                       // [0x9f64b0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKDeviceUtils.GetIMSI
	FString GetIMSI();                                                                                                       // [0x9f2110] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKDeviceUtils.GetIDFA
	FString GetIDFA();                                                                                                       // [0x9f2110] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKDeviceUtils.GetGoogleAdID
	void GetGoogleAdID();                                                                                                    // [0x9f6490] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKDeviceUtils.GetDisplayMetrics
	TArray<float> GetDisplayMetrics();                                                                                       // [0x9f6410] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKDeviceUtils.GetDisplayCutout
	TArray<float> GetDisplayCutout();                                                                                        // [0x9f6390] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKDeviceUtils.GetDeviceType
	FString GetDeviceType();                                                                                                 // [0x9f2110] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKDeviceUtils.GetDeviceScore
	void GetDeviceScore();                                                                                                   // [0x9f6370] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKDeviceUtils.GetDeviceModel
	FString GetDeviceModel();                                                                                                // [0x9f62f0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKDeviceUtils.GetDeviceID
	FString GetDeviceID();                                                                                                   // [0x9f6270] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKDeviceUtils.GetDeviceCarrier
	FString GetDeviceCarrier();                                                                                              // [0x9f2110] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKDeviceUtils.GetDeviceBrand
	FString GetDeviceBrand();                                                                                                // [0x9f61f0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKDeviceUtils.GetDeviceAbi
	FString GetDeviceAbi();                                                                                                  // [0x9f2110] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKDeviceUtils.GetCPUModel
	FString GetCPUModel();                                                                                                   // [0x9f6170] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKDeviceUtils.GetCPUHardWareName
	FString GetCPUHardWareName();                                                                                            // [0x9f6170] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKDeviceUtils.GetAvailableRAM
	FString GetAvailableRAM();                                                                                               // [0x9f60f0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKDeviceUtils.GetAndroidID
	FString GetAndroidID();                                                                                                  // [0x9f2110] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKDeviceUtils.DestoryInstance
	void DestoryInstance();                                                                                                  // [0x9f5d10] Final|Native|Static|Public|BlueprintCallable 
};

/// Class /Script/LLHSDK.LLHSDKLocalization
/// Size: 0x0000 (0x000028 - 0x000028)
class ULLHSDKLocalization : public UObject
{ 
public:
};

/// Class /Script/LLHSDK.LLHSDKLogin
/// Size: 0x01D0 (0x000028 - 0x0001F8)
class ULLHSDKLogin : public UObject
{ 
public:
	FMulticastInlineDelegate                           OnInitFinish;                                               // 0x0028   (0x0010)  
	FMulticastInlineDelegate                           OnLoginFinish;                                              // 0x0038   (0x0010)  
	FMulticastInlineDelegate                           OnLoginFailed;                                              // 0x0048   (0x0010)  
	FMulticastInlineDelegate                           OnBindFinish;                                               // 0x0058   (0x0010)  
	FMulticastInlineDelegate                           OnSwitchAccountFinish;                                      // 0x0068   (0x0010)  
	FMulticastInlineDelegate                           OnSwitchAccountFailed;                                      // 0x0078   (0x0010)  
	FMulticastInlineDelegate                           OnProtocolClick;                                            // 0x0088   (0x0010)  
	FMulticastInlineDelegate                           OnLimSteamSDKInited;                                        // 0x0098   (0x0010)  
	FMulticastInlineDelegate                           OnSteamAutoLogin;                                           // 0x00A8   (0x0010)  
	FMulticastInlineDelegate                           OnSteamRegister;                                            // 0x00B8   (0x0010)  
	FMulticastInlineDelegate                           OnGetSteamRegisterUrl;                                      // 0x00C8   (0x0010)  
	FMulticastInlineDelegate                           OnGetThirdPartyLoginResult;                                 // 0x00D8   (0x0010)  
	FMulticastInlineDelegate                           OnSteamBindUrlGet;                                          // 0x00E8   (0x0010)  
	FMulticastInlineDelegate                           OnSteamLoginResultSet;                                      // 0x00F8   (0x0010)  
	FMulticastInlineDelegate                           OnSteamGetAccountInfo;                                      // 0x0108   (0x0010)  
	FMulticastInlineDelegate                           OnSteamBindFinish;                                          // 0x0118   (0x0010)  
	FMulticastInlineDelegate                           OnNSSDKInited;                                              // 0x0128   (0x0010)  
	FMulticastInlineDelegate                           OnNSLoginStart;                                             // 0x0138   (0x0010)  
	FMulticastInlineDelegate                           OnNSAccountInfoGet;                                         // 0x0148   (0x0010)  
	FMulticastInlineDelegate                           OnLimPCSDKInited;                                           // 0x0158   (0x0010)  
	FMulticastInlineDelegate                           OnLimPCSDKEventCallback;                                    // 0x0168   (0x0010)  
	FMulticastInlineDelegate                           OnLimPCSDKLogin;                                            // 0x0178   (0x0010)  
	FMulticastInlineDelegate                           OnLimPCSDKLogout;                                           // 0x0188   (0x0010)  
	FMulticastInlineDelegate                           OnLimPCSDKOpenAccountPage;                                  // 0x0198   (0x0010)  
	FMulticastInlineDelegate                           OnLimPCSDKOpenSwitchAccountPage;                            // 0x01A8   (0x0010)  
	FMulticastInlineDelegate                           OnLimPCSDKLanguageChange;                                   // 0x01B8   (0x0010)  
	FMulticastInlineDelegate                           OnLimPCSDKGetUserInfo;                                      // 0x01C8   (0x0010)  
	FMulticastInlineDelegate                           OnLimPCSDKCommonReportPoint;                                // 0x01D8   (0x0010)  
	FString                                            LimPCAlilogFields;                                          // 0x01E8   (0x0010)  


	/// Functions
	// Function /Script/LLHSDK.LLHSDKLogin.UpdateSteamCallBack
	void UpdateSteamCallBack();                                                                                              // [0x9f83d0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.SwitchOrLinkAccount
	void SwitchOrLinkAccount();                                                                                              // [0x9f81a0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.SteamRegister
	bool SteamRegister(FString Params);                                                                                      // [0x9f8100] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.SteamLoginResultSet
	bool SteamLoginResultSet(FString Params);                                                                                // [0x9f8060] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.SteamGetAccountInfo
	bool SteamGetAccountInfo(FString Params);                                                                                // [0x9f7fc0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.SteamFree
	void SteamFree();                                                                                                        // [0x9f7fa0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.SteamBindUrlGet
	bool SteamBindUrlGet(FString Params);                                                                                    // [0x9f7f00] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.SteamAutoLogin
	bool SteamAutoLogin(FString Params);                                                                                     // [0x9f7e60] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.ShowProtocolViewV2Ok
	void ShowProtocolViewV2Ok();                                                                                             // [0x9f60b0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.ShowProtocolViewV2Confirm
	void ShowProtocolViewV2Confirm();                                                                                        // [0x9f7a70] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.SetLimPCSDKLogHandler
	int32_t SetLimPCSDKLogHandler();                                                                                         // [0x9f7870] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.SetLimPCSDKEventHandler
	int32_t SetLimPCSDKEventHandler();                                                                                       // [0x9f7840] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.SetLimPCAlilogFieldsData
	void SetLimPCAlilogFieldsData(FString LimPCAlilogFieldsStr);                                                             // [0x9f77b0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.QueryCurrentUserInfo
	FLLHSDKLoginUserInfo QueryCurrentUserInfo();                                                                             // [0x9f7740] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.QueryCurrentUser
	FLLHSDKLoginUser QueryCurrentUser();                                                                                     // [0x9f75f0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.OpenSteamBindPage
	bool OpenSteamBindPage(FString URL);                                                                                     // [0x9f74a0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.OpenLIMPCSwitchAccPage
	int32_t OpenLIMPCSwitchAccPage();                                                                                        // [0x9f73e0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.OpenLIMPCAccountPage
	int32_t OpenLIMPCAccountPage(FString Params);                                                                            // [0x9f7340] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.OnProtocolClick__DelegateSignature
	void OnProtocolClick__DelegateSignature(bool bConfirmed);                                                                // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKLogin.OnLoginFinish__DelegateSignature
	void OnLoginFinish__DelegateSignature(FString AppUid, FString AppToken, ELLHSDKLoginType LoginType);                     // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKLogin.OnLoginFailed__DelegateSignature
	void OnLoginFailed__DelegateSignature(ELLHSDKLoginType LoginType, int32_t ErrorCode);                                    // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKLogin.OnInitFinish__DelegateSignature
	void OnInitFinish__DelegateSignature();                                                                                  // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKLogin.OnBindFinish__DelegateSignature
	void OnBindFinish__DelegateSignature(bool bSuccess, FString AppUid, FString AppToken, ELLHSDKLoginType LoginType);       // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKLogin.NSLogout
	void NSLogout();                                                                                                         // [0x9ba990] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.NSLoginStart
	bool NSLoginStart(FString Params);                                                                                       // [0x9f6c90] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.NSFinalize
	void NSFinalize();                                                                                                       // [0x9ba990] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.NSAccountInfoGet
	bool NSAccountInfoGet(FString Params);                                                                                   // [0x9f6c90] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.LogoutLimPCSDK
	int32_t LogoutLimPCSDK();                                                                                                // [0x9f7310] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.Logout
	void Logout();                                                                                                           // [0x9f60b0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.LoginUserInfo_ToString
	FString LoginUserInfo_ToString(FLLHSDKLoginUserInfo& InUserInfo);                                                        // [0x9f7090] Final|Native|Static|Public|HasOutParms|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.LoginUser_ToString
	FString LoginUser_ToString(FLLHSDKLoginUser& InUser);                                                                    // [0x9f71a0] Final|Native|Static|Public|HasOutParms|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.LoginLimPCSDK
	int32_t LoginLimPCSDK(FString Params);                                                                                   // [0x9f6ff0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.Login
	void Login();                                                                                                            // [0x9f6fd0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.LimSteamSDKCallBack__DelegateSignature
	void LimSteamSDKCallBack__DelegateSignature(FString Datas);                                                              // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKLogin.LimPCSDKCallBack__DelegateSignature
	void LimPCSDKCallBack__DelegateSignature(FString Datas);                                                                 // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKLogin.LimOnSteamLoginResultSet__DelegateSignature
	void LimOnSteamLoginResultSet__DelegateSignature(FString AppUid, FString AppToken, FString AppId);                       // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKLogin.IsInitFinish
	bool IsInitFinish();                                                                                                     // [0x9f2af0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.IsCurrentUserNewReg
	bool IsCurrentUserNewReg();                                                                                              // [0x9f5b90] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.InitNSSDK
	bool InitNSSDK(FString Params);                                                                                          // [0x9f6c90] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.InitLimSteamSDK
	bool InitLimSteamSDK(FString Params);                                                                                    // [0x9f6bf0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.InitLimPCSDK
	int32_t InitLimPCSDK(FString Params);                                                                                    // [0x9f6b50] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.GetSteamToken
	FString GetSteamToken();                                                                                                 // [0x9f6950] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.GetSteamRegisterUrl
	bool GetSteamRegisterUrl(FString Params);                                                                                // [0x9f68b0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.GetLimPCUserInfo
	int32_t GetLimPCUserInfo(FString Params);                                                                                // [0x9f6620] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.GetLimPCAlilogFieldsData
	FString GetLimPCAlilogFieldsData();                                                                                      // [0x9f65a0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.GetLimPCAlilogFields
	int32_t GetLimPCAlilogFields();                                                                                          // [0x9f6570] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.GetInstance
	ULLHSDKLogin* GetInstance();                                                                                             // [0x9f6510] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.FreeLimPCSDK
	void FreeLimPCSDK();                                                                                                     // [0x9f60d0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.DoSteamBind
	bool DoSteamBind(FString URL);                                                                                           // [0x9f5e80] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.DestoryInstance
	void DestoryInstance();                                                                                                  // [0x9f5d50] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.DAPLogAdd
	void DAPLogAdd(FString Params);                                                                                          // [0x9f5c80] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.CommonReportLimPCPoint
	int32_t CommonReportLimPCPoint(FString Params);                                                                          // [0x9f5be0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.ClearAutoLogin
	bool ClearAutoLogin();                                                                                                   // [0x9f5b90] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.ChangeLIMPCLanguage
	int32_t ChangeLIMPCLanguage(FString Params);                                                                             // [0x9f5ac0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.CanContinueLogin
	bool CanContinueLogin();                                                                                                 // [0x9f5a70] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKLogin.CancelSteamCallBack
	void CancelSteamCallBack();                                                                                              // [0x9f5aa0] Final|Native|Static|Public|BlueprintCallable 
};

/// Class /Script/LLHSDK.LLHSDKMisc
/// Size: 0x0120 (0x000028 - 0x000148)
class ULLHSDKMisc : public UObject
{ 
public:
	FMulticastInlineDelegate                           OnBrowserClosed;                                            // 0x0028   (0x0010)  
	FMulticastInlineDelegate                           OnScreenshotCaptured;                                       // 0x0038   (0x0010)  
	unsigned char                                      UnknownData00_5[0x8];                                       // 0x0048   (0x0008)  MISSED
	FMulticastInlineDelegate                           OnFacebookPhotoShared;                                      // 0x0050   (0x0010)  
	unsigned char                                      UnknownData01_5[0x8];                                       // 0x0060   (0x0008)  MISSED
	FMulticastInlineDelegate                           OnSystemShared;                                             // 0x0068   (0x0010)  
	unsigned char                                      UnknownData02_5[0x8];                                       // 0x0078   (0x0008)  MISSED
	FMulticastInlineDelegate                           OnGetFacebookToken;                                         // 0x0080   (0x0010)  
	unsigned char                                      UnknownData03_5[0x8];                                       // 0x0090   (0x0008)  MISSED
	FMulticastInlineDelegate                           OnQueryThirdPartyUserInfo;                                  // 0x0098   (0x0010)  
	unsigned char                                      UnknownData04_5[0x8];                                       // 0x00A8   (0x0008)  MISSED
	FMulticastInlineDelegate                           OnRefreshFirebaseToken;                                     // 0x00B0   (0x0010)  
	unsigned char                                      UnknownData05_5[0x8];                                       // 0x00C0   (0x0008)  MISSED
	FMulticastInlineDelegate                           OnHttpDiagnosisCallBack;                                    // 0x00C8   (0x0010)  
	FMulticastInlineDelegate                           OnPingDiagnosisCallBack;                                    // 0x00D8   (0x0010)  
	FMulticastInlineDelegate                           OnTcpPingDiagnosisCallBack;                                 // 0x00E8   (0x0010)  
	FMulticastInlineDelegate                           OnMtrDiagnosisCallBack;                                     // 0x00F8   (0x0010)  
	FMulticastInlineDelegate                           OnDnsDiagnosisCallBack;                                     // 0x0108   (0x0010)  
	FMulticastInlineDelegate                           OnLimPCOpenWebview;                                         // 0x0118   (0x0010)  
	FMulticastInlineDelegate                           OnLimPCCloseWebview;                                        // 0x0128   (0x0010)  
	FMulticastInlineDelegate                           OnPickFileFromAlbumCallBack;                                // 0x0138   (0x0010)  


	/// Functions
	// Function /Script/LLHSDK.LLHSDKMisc.UpdateNetworkExtensions
	void UpdateNetworkExtensions(FString InUserId, FString InDeviceID);                                                      // [0x9f5d90] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.TwitterShareText
	void TwitterShareText(FString InText);                                                                                   // [0x9f2c50] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.TwitterSharePhoto
	void TwitterSharePhoto(FString InText, FString InFilePath);                                                              // [0x9f5d90] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.TryToEnableAndroidNotification
	void TryToEnableAndroidNotification();                                                                                   // [0x9f60b0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.TcpPingDetect
	void TcpPingDetect(FString InDomain, int32_t Port);                                                                      // [0x9f8300] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.SystemShare
	void SystemShare(int32_t& ShareType, FString Description, FString FilePath);                                             // [0x9f81c0] Final|Native|Static|Public|HasOutParms|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.StartIOSFarlightBrowserWithOrientation
	void StartIOSFarlightBrowserWithOrientation(FString URL, FString Title, ELLHSDKScreenOrientation Orientation);           // [0x9f7d30] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.StartBrowserWithOrientation
	void StartBrowserWithOrientation(FString URL, FString Title, ELLHSDKScreenOrientation Orientation);                      // [0x9f7c00] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.StartBrowser
	void StartBrowser(FString URL, FString Title);                                                                           // [0x9f7a90] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.SetNetworkPolicyDomain
	void SetNetworkPolicyDomain(FString InDomain);                                                                           // [0x9f2c50] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.SetNetworkMultipleDetect
	void SetNetworkMultipleDetect(bool InEnable);                                                                            // [0x9f79f0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.SetNetworkDiagnosisDeviceID
	void SetNetworkDiagnosisDeviceID(FString InDeviceID);                                                                    // [0x9f2c50] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.RestartApplication
	void RestartApplication(FString IntentString);                                                                           // [0x9f2c50] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.RefreshFirebaseMessagingToken
	void RefreshFirebaseMessagingToken();                                                                                    // [0x9f60b0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.RefreshAndroidMediaScanner
	void RefreshAndroidMediaScanner(FString InFullFilePath);                                                                 // [0x9f2c50] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.QueryThirdPartUserInfo
	void QueryThirdPartUserInfo();                                                                                           // [0x9f60b0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.PingDetect
	void PingDetect(FString InDomain);                                                                                       // [0x9f2c50] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.PickFileFromAlbum
	void PickFileFromAlbum();                                                                                                // [0x9f75d0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.OpenSteamPayWebPage
	void OpenSteamPayWebPage(FString URL);                                                                                   // [0x9f7540] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.OpenLimPCWebPage
	void OpenLimPCWebPage(FString Params);                                                                                   // [0x9f7410] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.OnSystemShared__DelegateSignature
	void OnSystemShared__DelegateSignature(bool bSuccess);                                                                   // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKMisc.OnScreenshotCapturedEvent__DelegateSignature
	void OnScreenshotCapturedEvent__DelegateSignature(FString FullPath);                                                     // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKMisc.OnRefreshFirebaseToken__DelegateSignature
	void OnRefreshFirebaseToken__DelegateSignature(FString FirebaseToken);                                                   // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKMisc.OnQueryThirdPartUserInfo__DelegateSignature
	void OnQueryThirdPartUserInfo__DelegateSignature(bool Success, int32_t ErrorCode, TArray<FSDKSocialUserInfo> SocialUserInfoList); // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKMisc.OnPickFileFromAlbumFinishEvent__DelegateSignature
	void OnPickFileFromAlbumFinishEvent__DelegateSignature(FString PickFilePath, int32_t ErrorCode);                         // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKMisc.OnLimPCOpenWebview__DelegateSignature
	void OnLimPCOpenWebview__DelegateSignature(FString Params);                                                              // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKMisc.OnLimPCCloseWebview__DelegateSignature
	void OnLimPCCloseWebview__DelegateSignature(FString Params);                                                             // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKMisc.OnGetFacebookToken__DelegateSignature
	void OnGetFacebookToken__DelegateSignature(bool Result, FString Token, FString ApplicationId, FString UserId, FString GraphDomain); // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKMisc.OnFacebookPhotoShared__DelegateSignature
	void OnFacebookPhotoShared__DelegateSignature(FString FilePath, bool bSuccess);                                          // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKMisc.OnBrowserClosed__DelegateSignature
	void OnBrowserClosed__DelegateSignature();                                                                               // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKMisc.NetworkDiagnosisCallback__DelegateSignature
	void NetworkDiagnosisCallback__DelegateSignature(FString Type, FString Ret);                                             // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKMisc.MtrDetect
	void MtrDetect(FString InDomain);                                                                                        // [0x9f2c50] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.JumpToMarket
	void JumpToMarket(FString InAppPkg, FString InMarketPkg);                                                                // [0x9f5d90] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.JumpToAppStore
	void JumpToAppStore(FString AppStoreUrl);                                                                                // [0x9f2c50] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.IsFacebookShareable
	bool IsFacebookShareable();                                                                                              // [0x9f5b60] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.IsAppRooted
	bool IsAppRooted();                                                                                                      // [0x9f5b60] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.IsAndroidNotificationEnabled
	bool IsAndroidNotificationEnabled();                                                                                     // [0x9f5b90] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.InitNetworkDiagnosis
	void InitNetworkDiagnosis(FString InProject, FString InSecretKey, FString InEndPoint, FString InAccessKeyId, FString InAccessKeySecret, FString InUid, FString InChannel); // [0x9f6d30] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.HttpDetect
	void HttpDetect(FString InUrl);                                                                                          // [0x9f2c50] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.GetNetworkDiagnosisDeviceID
	FString GetNetworkDiagnosisDeviceID();                                                                                   // [0x9f2110] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.GetInstance
	ULLHSDKMisc* GetInstance();                                                                                              // [0x9f6540] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.GetFirebaseMessagingToken
	FString GetFirebaseMessagingToken();                                                                                     // [0x9f2110] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.GetFacebookToken
	void GetFacebookToken();                                                                                                 // [0x9f60b0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.FacebookSharePhotoWithFileAndDescription
	void FacebookSharePhotoWithFileAndDescription(FString Description, FString FilePath);                                    // [0x9f5d90] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.FacebookSharePhotoByPath
	void FacebookSharePhotoByPath(FString InFilePath);                                                                       // [0x9f2c50] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.FacebookSharePhoto
	void FacebookSharePhoto();                                                                                               // [0x9f60b0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.FacebookShareLink
	void FacebookShareLink(FString InLinkURL, FString InPreviewURL, FString InTitle, FString InDesc);                        // [0x9f5f20] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.DnsDetect
	void DnsDetect(FString InServer, FString InDomain);                                                                      // [0x9f5d90] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.DestoryInstance
	void DestoryInstance();                                                                                                  // [0x9f5d70] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.CloseLimPCWebPageAll
	void CloseLimPCWebPageAll();                                                                                             // [0x9f5bc0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKMisc.CheckGyroSensorSupport
	bool CheckGyroSensorSupport();                                                                                           // [0x9f5b60] Final|Native|Static|Public|BlueprintCallable 
};

/// Class /Script/LLHSDK.LLHSDKPay
/// Size: 0x0138 (0x000028 - 0x000160)
class ULLHSDKPay : public UObject
{ 
public:
	FMulticastInlineDelegate                           OnLSteamQuerySkus;                                          // 0x0028   (0x0010)  
	FMulticastInlineDelegate                           OnLSteamSDKPayApplied;                                      // 0x0038   (0x0010)  
	FMulticastInlineDelegate                           OnLimPCQueryPriceLadder;                                    // 0x0048   (0x0010)  
	FMulticastInlineDelegate                           OnLimPCQueryPriceLadderWithRegion;                          // 0x0058   (0x0010)  
	FMulticastInlineDelegate                           OnLimPCPayApplied;                                          // 0x0068   (0x0010)  
	FMulticastInlineDelegate                           OnSwitchSDKPayGetConsumables;                               // 0x0078   (0x0010)  
	FMulticastInlineDelegate                           OnSwitchSDKPayGetConsumableItems;                           // 0x0088   (0x0010)  
	FMulticastInlineDelegate                           OnSwitchSDKPayEShopOpen;                                    // 0x0098   (0x0010)  
	FMulticastInlineDelegate                           OnSwitchSDKPayOrdersCheck;                                  // 0x00A8   (0x0010)  
	FMulticastInlineDelegate                           OnSwitchSDKPayOrdersConsume;                                // 0x00B8   (0x0010)  
	FMulticastInlineDelegate                           OnGooglePayFinished;                                        // 0x00C8   (0x0010)  
	FMulticastInlineDelegate                           OnGoogleQuerySkuItemDetails;                                // 0x00D8   (0x0010)  
	FMulticastInlineDelegate                           OnGoogleQuerySkuItemDetailsSubscription;                    // 0x00E8   (0x0010)  
	FMulticastInlineDelegate                           OnGetGoogleConsumeGoods;                                    // 0x00F8   (0x0010)  
	FMulticastInlineDelegate                           OnGetGoogleConsumePointsGoods;                              // 0x0108   (0x0010)  
	FMulticastInlineDelegate                           OnIOSQuerySkus;                                             // 0x0118   (0x0010)  
	FMulticastInlineDelegate                           OnIOSLLHPayFinished;                                        // 0x0128   (0x0010)  
	FMulticastInlineDelegate                           OnGetIOSPurchaseExtNull;                                    // 0x0138   (0x0010)  
	unsigned char                                      UnknownData00_6[0x18];                                      // 0x0148   (0x0018)  MISSED


	/// Functions
	// Function /Script/LLHSDK.LLHSDKPay.Test_Google_SkuItemDetailsToString
	FString Test_Google_SkuItemDetailsToString(FLLHSDKGenericSkuItemsDetailList InDetails);                                  // [0x9fbfb0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKPay.SwitchSDKPayOrdersConsume__DelegateSignature
	void SwitchSDKPayOrdersConsume__DelegateSignature(FString Datas);                                                        // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKPay.SwitchSDKPayOrdersCheck__DelegateSignature
	void SwitchSDKPayOrdersCheck__DelegateSignature(FString Datas);                                                          // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKPay.SwitchSDKPayGetConsumables__DelegateSignature
	void SwitchSDKPayGetConsumables__DelegateSignature(FString Datas);                                                       // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKPay.SwitchSDKPayGetConsumableItems__DelegateSignature
	void SwitchSDKPayGetConsumableItems__DelegateSignature(FString Datas);                                                   // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKPay.SwitchSDKPayEShopOpen__DelegateSignature
	void SwitchSDKPayEShopOpen__DelegateSignature(FString Datas);                                                            // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKPay.Switch_OrdersConsume
	void Switch_OrdersConsume(FString Params);                                                                               // [0x9f2c50] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKPay.Switch_OrdersCheck
	void Switch_OrdersCheck(FString Params);                                                                                 // [0x9f2c50] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKPay.Switch_GetConsumables
	void Switch_GetConsumables(FString Params);                                                                              // [0x9f2c50] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKPay.Switch_GetConsumableItems
	void Switch_GetConsumableItems(FString Params);                                                                          // [0x9f2c50] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKPay.Switch_EShopOpen
	void Switch_EShopOpen(FString Params);                                                                                   // [0x9f2c50] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKPay.SteamQuerySkus
	void SteamQuerySkus(FString Params);                                                                                     // [0x9fbe90] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKPay.Steam_StartPay
	void Steam_StartPay(FString SteamPayInfo);                                                                               // [0x9fbf20] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKPay.SetPayNotifyUrl
	void SetPayNotifyUrl(FString InNotifyUrl);                                                                               // [0x9f2c50] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKPay.OnLLHQuerySkus__DelegateSignature
	void OnLLHQuerySkus__DelegateSignature(FLLHSDKGenericSkuItemsDetailList ItemsDetailList, TArray<FString>& InvalidProductIDs); // [0x2d64c70] MulticastDelegate|Public|Delegate|HasOutParms 
	// Function /Script/LLHSDK.LLHSDKPay.OnLLHPayFinished__DelegateSignature
	void OnLLHPayFinished__DelegateSignature(bool bSuccess, int32_t ErrorCode, FString ErrorMsg, int32_t PayValue, FString ProductID, ELLHSDKPayType PayType); // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKPay.OnGoogleQuerySkuSubItemDetails__DelegateSignature
	void OnGoogleQuerySkuSubItemDetails__DelegateSignature(bool bSuccess, int32_t ErrorCode, FString ItemsDetailListJsonString); // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKPay.OnGoogleQuerySkuItemDetails__DelegateSignature
	void OnGoogleQuerySkuItemDetails__DelegateSignature(bool bSuccess, int32_t ErrorCode, FString ItemsDetailListJsonString); // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKPay.OnGooglePayFinished__DelegateSignature
	void OnGooglePayFinished__DelegateSignature(bool bSuccess, int32_t ErrorCode, int32_t Price, FString ItemID, ELLHSDKPayType PayType); // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKPay.OnGetIOSPurchaseExtNull__DelegateSignature
	void OnGetIOSPurchaseExtNull__DelegateSignature(FString AppUid, FString ProductID);                                      // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKPay.OnGetGoogleConsumeGoods__DelegateSignature
	void OnGetGoogleConsumeGoods__DelegateSignature(TArray<FString>& Skus);                                                  // [0x2d64c70] MulticastDelegate|Public|Delegate|HasOutParms 
	// Function /Script/LLHSDK.LLHSDKPay.LSteamSDKQuerySkus__DelegateSignature
	void LSteamSDKQuerySkus__DelegateSignature(FString Datas);                                                               // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKPay.LSteamSDKPayApplied__DelegateSignature
	void LSteamSDKPayApplied__DelegateSignature(FString Datas);                                                              // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKPay.LimPCStartPay
	void LimPCStartPay(FString Params);                                                                                      // [0x9fa8b0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKPay.LimPCSDKQueryPriceLadder__DelegateSignature
	void LimPCSDKQueryPriceLadder__DelegateSignature(FString Datas);                                                         // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKPay.LimPCSDKPayApplied__DelegateSignature
	void LimPCSDKPayApplied__DelegateSignature(FString Datas);                                                               // [0x2d64c70] MulticastDelegate|Public|Delegate 
	// Function /Script/LLHSDK.LLHSDKPay.LimPCQueryPriceLadderWithRegion
	void LimPCQueryPriceLadderWithRegion(FString Params);                                                                    // [0x9fa820] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKPay.LimPCQueryPriceLadder
	void LimPCQueryPriceLadder();                                                                                            // [0x9fa800] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKPay.IOS_SetUserPayExtInCallback
	void IOS_SetUserPayExtInCallback(FString ProductID, FString PayExt);                                                     // [0x9f5d90] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKPay.IOS_SetUserPayExt
	void IOS_SetUserPayExt(FString PayExt);                                                                                  // [0x9f2c50] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKPay.IOS_SetAutoPayExt
	void IOS_SetAutoPayExt(bool bEnabled);                                                                                   // [0x9fa780] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKPay.IOS_QuerySkus
	void IOS_QuerySkus(TArray<FString>& ProductIDs);                                                                         // [0x9fa6c0] Final|Native|Static|Public|HasOutParms|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKPay.IOS_LLHPay
	void IOS_LLHPay(FString ProductID, FString PayExt);                                                                      // [0x9fa5d0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKPay.IOS_GetAutoPayExt
	bool IOS_GetAutoPayExt();                                                                                                // [0x9fa5a0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKPay.Google_StartPaySubscription
	void Google_StartPaySubscription(FString PayItemID, FString PayContext);                                                 // [0x9fa430] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKPay.Google_StartPay
	void Google_StartPay(FString PayItemID, FString PayContext);                                                             // [0x9fa430] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKPay.Google_QuerySkuItemDetailsSubscription
	void Google_QuerySkuItemDetailsSubscription(TArray<FString> Items);                                                      // [0x9fa2d0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKPay.Google_QuerySkuItemDetails
	void Google_QuerySkuItemDetails(TArray<FString> Items);                                                                  // [0x9fa170] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKPay.Google_HasConsumePointsGoods
	bool Google_HasConsumePointsGoods();                                                                                     // [0x9f5b60] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKPay.Google_HasConsumeGoods
	bool Google_HasConsumeGoods();                                                                                           // [0x9f5b60] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKPay.Google_GetConsumePointsGoods
	TArray<FString> Google_GetConsumePointsGoods();                                                                          // [0x9fa0f0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKPay.Google_GetConsumeGoods
	TArray<FString> Google_GetConsumeGoods();                                                                                // [0x9fa0f0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKPay.Google_ConsumeGoods
	void Google_ConsumeGoods(TArray<FString> Skus, TArray<FString> Contexts);                                                // [0x9f9ea0] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKPay.GetInstance
	ULLHSDKPay* GetInstance();                                                                                               // [0x9f9e40] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/LLHSDK.LLHSDKPay.DestoryInstance
	void DestoryInstance();                                                                                                  // [0x9f9e00] Final|Native|Static|Public|BlueprintCallable 
};

/// Class /Script/LLHSDK.LLHSDKReport
/// Size: 0x0000 (0x000028 - 0x000028)
class ULLHSDKReport : public UObject
{ 
public:
};

/// Class /Script/LLHSDK.LLHSDKSettings
/// Size: 0x0300 (0x000038 - 0x000338)
class ULLHSDKSettings : public UDeveloperSettings
{ 
public:
	EDistributionRegion                                DistributionRegion;                                         // 0x0038   (0x0001)  
	EReleaseType                                       ReleaseType;                                                // 0x0039   (0x0001)  
	bool                                               bIsSDKDebuggable;                                           // 0x003A   (0x0001)  
	bool                                               bIsGrayRelease;                                             // 0x003B   (0x0001)  
	unsigned char                                      UnknownData00_5[0x4];                                       // 0x003C   (0x0004)  MISSED
	FString                                            SDKGroupName;                                               // 0x0040   (0x0010)  
	FString                                            SDKFeatureName;                                             // 0x0050   (0x0010)  
	FString                                            SDKVersion;                                                 // 0x0060   (0x0010)  
	bool                                               bHasFacebook;                                               // 0x0070   (0x0001)  
	bool                                               bHasTiktok;                                                 // 0x0071   (0x0001)  
	bool                                               bHasFirebaseMessaging;                                      // 0x0072   (0x0001)  
	bool                                               bHasJiGuangPush;                                            // 0x0073   (0x0001)  
	unsigned char                                      UnknownData01_5[0x4];                                       // 0x0074   (0x0004)  MISSED
	FString                                            SDKAppIdForGrayRelease;                                     // 0x0078   (0x0010)  
	FString                                            SDKGameIdForGrayRelease;                                    // 0x0088   (0x0010)  
	FString                                            PspAppIdForGrayRelease;                                     // 0x0098   (0x0010)  
	FString                                            AndroidDebugParkwayEnvIdForGrayRelease;                     // 0x00A8   (0x0010)  
	FString                                            AndroidReleaseParkwayEnvIdForGrayRelease;                   // 0x00B8   (0x0010)  
	FString                                            FacebookAppIDForGrayRelease;                                // 0x00C8   (0x0010)  
	FString                                            FacebookContentProviderForGrayRelease;                      // 0x00D8   (0x0010)  
	FString                                            SDKAppId;                                                   // 0x00E8   (0x0010)  
	FString                                            SDKGameId;                                                  // 0x00F8   (0x0010)  
	FString                                            FacebookContentProvider;                                    // 0x0108   (0x0010)  
	FString                                            FacebookAppID;                                              // 0x0118   (0x0010)  
	FString                                            IOSFacebookContentProvider;                                 // 0x0128   (0x0010)  
	FString                                            IOSFacebookAppID;                                           // 0x0138   (0x0010)  
	FString                                            PspAppId;                                                   // 0x0148   (0x0010)  
	FString                                            AndroidDebugParkwayEnvId;                                   // 0x0158   (0x0010)  
	FString                                            AndroidReleaseParkwayEnvId;                                 // 0x0168   (0x0010)  
	FString                                            IOSDebugParkwayEnvId;                                       // 0x0178   (0x0010)  
	FString                                            IOSReleaseParkwayEnvId;                                     // 0x0188   (0x0010)  
	FString                                            SteamDebugParkwayEnvId;                                     // 0x0198   (0x0010)  
	FString                                            SteamReleaseParkwayEnvId;                                   // 0x01A8   (0x0010)  
	FString                                            OffcialWinDebugParkwayEnvId;                                // 0x01B8   (0x0010)  
	FString                                            OffcialWinReleaseParkwayEnvId;                              // 0x01C8   (0x0010)  
	FString                                            EpicDebugParkwayEnvId;                                      // 0x01D8   (0x0010)  
	FString                                            EpicReleaseParkwayEnvId;                                    // 0x01E8   (0x0010)  
	FString                                            SDKAppIdForDomesticRelease;                                 // 0x01F8   (0x0010)  
	FString                                            SDKGameIdForDomesticRelease;                                // 0x0208   (0x0010)  
	FString                                            AndroidDebugParkwayEnvIdForDomesticRelease;                 // 0x0218   (0x0010)  
	FString                                            AndroidReleaseParkwayEnvIdForDomesticRelease;               // 0x0228   (0x0010)  
	FString                                            IOSDebugParkwayEnvIdForDomesticRelease;                     // 0x0238   (0x0010)  
	FString                                            IOSReleaseParkwayEnvIdForDomesticRelease;                   // 0x0248   (0x0010)  
	FString                                            PspAppIdForDomesticRelease;                                 // 0x0258   (0x0010)  
	FString                                            OffcialWinDebugParkwayEnvIdForDomesticRelease;              // 0x0268   (0x0010)  
	FString                                            OffcialWinReleaseParkwayEnvIdForDomesticRelease;            // 0x0278   (0x0010)  
	bool                                               bAndroidXEnabled;                                           // 0x0288   (0x0001)  
	bool                                               bMultiDexEnabled;                                           // 0x0289   (0x0001)  
	bool                                               bShouldUseOverridedConfig;                                  // 0x028A   (0x0001)  
	unsigned char                                      UnknownData02_5[0x5];                                       // 0x028B   (0x0005)  MISSED
	FString                                            FirebaseCoreVersion;                                        // 0x0290   (0x0010)  
	FString                                            FirebaseMessagingVersion;                                   // 0x02A0   (0x0010)  
	FString                                            GoogleServicesVersion;                                      // 0x02B0   (0x0010)  
	FString                                            PlayServicesBasementVersion;                                // 0x02C0   (0x0010)  
	ELLHSDKGravity                                     PlayPhoneGravity;                                           // 0x02D0   (0x0001)  
	bool                                               bEnableAndroidScreenshotListener;                           // 0x02D1   (0x0001)  
	bool                                               bEnableAndroidMultipleDetect;                               // 0x02D2   (0x0001)  
	bool                                               bShowLogo;                                                  // 0x02D3   (0x0001)  
	ELLHSDKLoginUIStyle                                LoginUIStyle;                                               // 0x02D4   (0x0001)  
	bool                                               bIOSShouldUseOverridedConfig;                               // 0x02D5   (0x0001)  
	bool                                               bIOSShowTermsByServer;                                      // 0x02D6   (0x0001)  
	unsigned char                                      UnknownData03_5[0x1];                                       // 0x02D7   (0x0001)  MISSED
	FString                                            FacebookDisplayName;                                        // 0x02D8   (0x0010)  
	FString                                            QQAppID;                                                    // 0x02E8   (0x0010)  
	FString                                            WechatAppID;                                                // 0x02F8   (0x0010)  
	FString                                            GoogleReversedClientID;                                     // 0x0308   (0x0010)  
	FString                                            TwitterAPIKey;                                              // 0x0318   (0x0010)  
	FString                                            DefaultNSUserTrackingUsageDescription;                      // 0x0328   (0x0010)  
};

/// Struct /Script/LLHSDK.LLHSDKLoginUser
/// Size: 0x0048 (0x000000 - 0x000048)
struct FLLHSDKLoginUser
{ 
	bool                                               bValid;                                                     // 0x0000   (0x0001)  
	unsigned char                                      UnknownData00_5[0x7];                                       // 0x0001   (0x0007)  MISSED
	FString                                            AppUid;                                                     // 0x0008   (0x0010)  
	FString                                            AppToken;                                                   // 0x0018   (0x0010)  
	ELLHSDKLoginType                                   LoginType;                                                  // 0x0028   (0x0001)  
	unsigned char                                      UnknownData01_5[0x7];                                       // 0x0029   (0x0007)  MISSED
	FString                                            Name;                                                       // 0x0030   (0x0010)  
	bool                                               bIsGuest;                                                   // 0x0040   (0x0001)  
	bool                                               bIsSafe;                                                    // 0x0041   (0x0001)  
	unsigned char                                      UnknownData02_5[0x2];                                       // 0x0042   (0x0002)  MISSED
	int32_t                                            LimitDeviceCount;                                           // 0x0044   (0x0004)  
};

/// Struct /Script/LLHSDK.LLHSDKLoginUserInfo
/// Size: 0x0140 (0x000000 - 0x000140)
struct FLLHSDKLoginUserInfo
{ 
	bool                                               bValid;                                                     // 0x0000   (0x0001)  
	unsigned char                                      UnknownData00_5[0x7];                                       // 0x0001   (0x0007)  MISSED
	FString                                            Phone;                                                      // 0x0008   (0x0010)  
	FString                                            Email;                                                      // 0x0018   (0x0010)  
	FString                                            UserRegion;                                                 // 0x0028   (0x0010)  
	FString                                            IP;                                                         // 0x0038   (0x0010)  
	int32_t                                            RestPoint;                                                  // 0x0048   (0x0004)  
	bool                                               bDomesticHasBindAnyOne;                                     // 0x004C   (0x0001)  
	bool                                               bIsNewReg;                                                  // 0x004D   (0x0001)  
	bool                                               bIsIdentified;                                              // 0x004E   (0x0001)  
	bool                                               bIsAbusePrevented;                                          // 0x004F   (0x0001)  
	TSet<ELLHSDKLoginType>                             BoundLoginTypes;                                            // 0x0050   (0x0050)  
	TMap<ELLHSDKLoginType, FLLHSDKLoginUserInfoMap>    BoundInfoMap;                                               // 0x00A0   (0x0050)  
	FLLHSDKLoginUserInfoMap                            UserExtra;                                                  // 0x00F0   (0x0050)  
};

/// Struct /Script/LLHSDK.LLHSDKLoginUserInfoMap
/// Size: 0x0050 (0x000000 - 0x000050)
struct FLLHSDKLoginUserInfoMap
{ 
	TMap<FString, FString>                             Info;                                                       // 0x0000   (0x0050)  
};

/// Struct /Script/LLHSDK.SDKSocialUserInfo
/// Size: 0x0038 (0x000000 - 0x000038)
struct FSDKSocialUserInfo
{ 
	FString                                            Avatar;                                                     // 0x0000   (0x0010)  
	FString                                            Name;                                                       // 0x0010   (0x0010)  
	FString                                            Email;                                                      // 0x0020   (0x0010)  
	int32_t                                            BindType;                                                   // 0x0030   (0x0004)  
	unsigned char                                      UnknownData00_6[0x4];                                       // 0x0034   (0x0004)  MISSED
};

/// Struct /Script/LLHSDK.LLHSDKGenericSkuItemsDetailList
/// Size: 0x0010 (0x000000 - 0x000010)
struct FLLHSDKGenericSkuItemsDetailList
{ 
	TArray<FLLHSDKGoogleSkuItemDetail>                 Items;                                                      // 0x0000   (0x0010)  
};

/// Struct /Script/LLHSDK.LLHSDKGoogleSkuItemDetail
/// Size: 0x0070 (0x000000 - 0x000070)
struct FLLHSDKGoogleSkuItemDetail
{ 
	ELLHSDKPayGenericSkuItemType                       ItemType;                                                   // 0x0000   (0x0001)  
	unsigned char                                      UnknownData00_5[0x7];                                       // 0x0001   (0x0007)  MISSED
	FString                                            Title;                                                      // 0x0008   (0x0010)  
	FString                                            Desc;                                                       // 0x0018   (0x0010)  
	FString                                            Price;                                                      // 0x0028   (0x0010)  
	FString                                            Sku;                                                        // 0x0038   (0x0010)  
	FString                                            Currency;                                                   // 0x0048   (0x0010)  
	int32_t                                            PriceAmountMicros;                                          // 0x0058   (0x0004)  
	unsigned char                                      UnknownData01_5[0x4];                                       // 0x005C   (0x0004)  MISSED
	FString                                            SdkConvertSymbol;                                           // 0x0060   (0x0010)  
};

/// Struct /Script/LLHSDK.LLHSDKCustomerServiceExtra
/// Size: 0x0060 (0x000000 - 0x000060)
struct FLLHSDKCustomerServiceExtra
{ 
	TArray<FString>                                    Tags;                                                       // 0x0000   (0x0010)  
	TMap<FString, FString>                             CustomParams;                                               // 0x0010   (0x0050)  
};

/// Struct /Script/LLHSDK.LLHSDKLocaleInfo
/// Size: 0x0020 (0x000000 - 0x000020)
struct FLLHSDKLocaleInfo
{ 
	FString                                            Language;                                                   // 0x0000   (0x0010)  
	FString                                            Region;                                                     // 0x0010   (0x0010)  
};

/// Struct /Script/LLHSDK.LLHSDKGenericSkuSubItemsDetailList
/// Size: 0x0010 (0x000000 - 0x000010)
struct FLLHSDKGenericSkuSubItemsDetailList
{ 
	TArray<FLLHSDKGoogleSkuSubItemDetail>              Items;                                                      // 0x0000   (0x0010)  
};

/// Struct /Script/LLHSDK.LLHSDKGoogleSkuSubItemDetail
/// Size: 0x0050 (0x000000 - 0x000050)
struct FLLHSDKGoogleSkuSubItemDetail
{ 
	ELLHSDKPayGenericSkuItemType                       ItemType;                                                   // 0x0000   (0x0001)  
	unsigned char                                      UnknownData00_5[0x7];                                       // 0x0001   (0x0007)  MISSED
	FString                                            Title;                                                      // 0x0008   (0x0010)  
	FString                                            Desc;                                                       // 0x0018   (0x0010)  
	FString                                            Sku;                                                        // 0x0028   (0x0010)  
	int32_t                                            SubGoodsSize;                                               // 0x0038   (0x0004)  
	unsigned char                                      UnknownData01_5[0x4];                                       // 0x003C   (0x0004)  MISSED
	TArray<FLLHSDKGoogleSkuSubGood>                    SubGoods;                                                   // 0x0040   (0x0010)  
};

/// Struct /Script/LLHSDK.LLHSDKGoogleSkuSubGood
/// Size: 0x0038 (0x000000 - 0x000038)
struct FLLHSDKGoogleSkuSubGood
{ 
	FString                                            OfferToken;                                                 // 0x0000   (0x0010)  
	int32_t                                            CombineSize;                                                // 0x0010   (0x0004)  
	unsigned char                                      UnknownData00_5[0x4];                                       // 0x0014   (0x0004)  MISSED
	TArray<FLLHSDKGoogleSubCombineItem>                CombineItems;                                               // 0x0018   (0x0010)  
	TArray<FString>                                    OfferTags;                                                  // 0x0028   (0x0010)  
};

/// Struct /Script/LLHSDK.LLHSDKGoogleSubCombineItem
/// Size: 0x0070 (0x000000 - 0x000070)
struct FLLHSDKGoogleSubCombineItem
{ 
	int32_t                                            Index;                                                      // 0x0000   (0x0004)  
	unsigned char                                      UnknownData00_5[0x4];                                       // 0x0004   (0x0004)  MISSED
	FString                                            ProductID;                                                  // 0x0008   (0x0010)  
	FString                                            CombineItemName1;                                           // 0x0018   (0x0010)  
	FString                                            CombineItemName2;                                           // 0x0028   (0x0010)  
	FString                                            Price;                                                      // 0x0038   (0x0010)  
	FString                                            Currency;                                                   // 0x0048   (0x0010)  
	int32_t                                            PriceAmountMicros;                                          // 0x0058   (0x0004)  
	unsigned char                                      UnknownData01_5[0x4];                                       // 0x005C   (0x0004)  MISSED
	FString                                            SdkConvertSymbol;                                           // 0x0060   (0x0010)  
};

/// Enum /Script/LLHSDK.ELLHSDKNetworkType
/// Size: 0x09
enum ELLHSDKNetworkType : uint8_t
{
	ELLHSDKNetworkType__Unknown                                                      = 0,
	ELLHSDKNetworkType__NotConnected                                                 = 1,
	ELLHSDKNetworkType__Type_WiFi                                                    = 2,
	ELLHSDKNetworkType__Type_Unknown_Cell                                            = 3,
	ELLHSDKNetworkType__Type_2G                                                      = 4,
	ELLHSDKNetworkType__Type_3G                                                      = 5,
	ELLHSDKNetworkType__Type_4G                                                      = 6,
	ELLHSDKNetworkType__Type_5G                                                      = 7,
	ELLHSDKNetworkType__ELLHSDKNetworkType_MAX                                       = 8
};

/// Enum /Script/LLHSDK.ELLHSDKLoginType
/// Size: 0x21
enum ELLHSDKLoginType : uint8_t
{
	ELLHSDKLoginType__TYPE_NONE                                                      = 0,
	ELLHSDKLoginType__TYPE_QUICK_LOGIN                                               = 1,
	ELLHSDKLoginType__TYPE_LILITH_LOGIN                                              = 2,
	ELLHSDKLoginType__TYPE_MOBILE_LOGIN                                              = 2,
	ELLHSDKLoginType__TYPE_FACEBOOK_LOGIN                                            = 3,
	ELLHSDKLoginType__TYPE_GAME_CENTER_LOGIN                                         = 4,
	ELLHSDKLoginType__TYPE_GOOGLE_PLUS_OR_GAMES_LOGIN                                = 5,
	ELLHSDKLoginType__TYPE_WECHAT_LOGIN                                              = 6,
	ELLHSDKLoginType__TYPE_QQ_LOGIN                                                  = 7,
	ELLHSDKLoginType__TYPE_AUTO_LOGIN                                                = 8,
	ELLHSDKLoginType__TYPE_VK_LOGIN                                                  = 9,
	ELLHSDKLoginType__TYPE_GOOGLE_LOGIN                                              = 10,
	ELLHSDKLoginType__TYPE_LINE_LOGIN                                                = 11,
	ELLHSDKLoginType__TYPE_TWITTER_LOGIN                                             = 12,
	ELLHSDKLoginType__TYPE_APPLE_LOGIN                                               = 13,
	ELLHSDKLoginType__TYPE_WEIBO_LOGIN                                               = 14,
	ELLHSDKLoginType__TYPE_PGS_LOGIN                                                 = 15,
	ELLHSDKLoginType__TYPE_TIKTOK_LOGIN                                              = 16,
	ELLHSDKLoginType__TYPE_STEAM_LOGIN                                               = 17,
	ELLHSDKLoginType__TYPE_NINTENDO_LOGIN                                            = 18,
	ELLHSDKLoginType__TYPE_MAX                                                       = 19
};

/// Enum /Script/LLHSDK.ELLHSDKScreenOrientation
/// Size: 0x09
enum ELLHSDKScreenOrientation : uint8_t
{
	ELLHSDKScreenOrientation__Portrait                                               = 0,
	ELLHSDKScreenOrientation__ReversePortrait                                        = 1,
	ELLHSDKScreenOrientation__SensorPortrait                                         = 2,
	ELLHSDKScreenOrientation__Landscape                                              = 3,
	ELLHSDKScreenOrientation__ReverseLandscape                                       = 4,
	ELLHSDKScreenOrientation__SensorLandscape                                        = 5,
	ELLHSDKScreenOrientation__Sensor                                                 = 6,
	ELLHSDKScreenOrientation__FullSensor                                             = 7,
	ELLHSDKScreenOrientation__ELLHSDKScreenOrientation_MAX                           = 8
};

/// Enum /Script/LLHSDK.ELLHSDKPayType
/// Size: 0x15
enum ELLHSDKPayType : uint8_t
{
	ELLHSDKPayType__None                                                             = 0,
	ELLHSDKPayType__Apple                                                            = 1,
	ELLHSDKPayType__Google                                                           = 2,
	ELLHSDKPayType__Ali                                                              = 3,
	ELLHSDKPayType__Wechat                                                           = 4,
	ELLHSDKPayType__Union                                                            = 5,
	ELLHSDKPayType__PlayPhone                                                        = 6,
	ELLHSDKPayType__MyCard                                                           = 7,
	ELLHSDKPayType__Payssion                                                         = 8,
	ELLHSDKPayType__HuaweiAbroad                                                     = 9,
	ELLHSDKPayType__Paypal                                                           = 10,
	ELLHSDKPayType__Voucher                                                          = 11,
	ELLHSDKPayType__Samsung                                                          = 12,
	ELLHSDKPayType__Switch                                                           = 13,
	ELLHSDKPayType__ELLHSDKPayType_MAX                                               = 14
};

/// Enum /Script/LLHSDK.ELLHSDKPayGenericSkuItemType
/// Size: 0x03
enum ELLHSDKPayGenericSkuItemType : uint8_t
{
	ELLHSDKPayGenericSkuItemType__Normal                                             = 0,
	ELLHSDKPayGenericSkuItemType__Subscription                                       = 1,
	ELLHSDKPayGenericSkuItemType__ELLHSDKPayGenericSkuItemType_MAX                   = 2
};

/// Enum /Script/LLHSDK.ELLHSDKCustomerServiceRateAction
/// Size: 0x05
enum ELLHSDKCustomerServiceRateAction : uint8_t
{
	ELLHSDKCustomerServiceRateAction__Success                                        = 0,
	ELLHSDKCustomerServiceRateAction__FeedBack                                       = 1,
	ELLHSDKCustomerServiceRateAction__Close                                          = 2,
	ELLHSDKCustomerServiceRateAction__Fail                                           = 3,
	ELLHSDKCustomerServiceRateAction__ELLHSDKCustomerServiceRateAction_MAX           = 4
};

/// Enum /Script/LLHSDK.ELLHSDKSupportedLanguage
/// Size: 0x21
enum ELLHSDKSupportedLanguage : uint8_t
{
	ELLHSDKSupportedLanguage__DefaultLanguage                                        = 0,
	ELLHSDKSupportedLanguage__Arabic                                                 = 1,
	ELLHSDKSupportedLanguage__English                                                = 2,
	ELLHSDKSupportedLanguage__French                                                 = 3,
	ELLHSDKSupportedLanguage__German                                                 = 4,
	ELLHSDKSupportedLanguage__Indonesian                                             = 5,
	ELLHSDKSupportedLanguage__Italian                                                = 6,
	ELLHSDKSupportedLanguage__Japanese                                               = 7,
	ELLHSDKSupportedLanguage__Korean                                                 = 8,
	ELLHSDKSupportedLanguage__Malay                                                  = 9,
	ELLHSDKSupportedLanguage__Polish                                                 = 10,
	ELLHSDKSupportedLanguage__Portuguese                                             = 11,
	ELLHSDKSupportedLanguage__Russian                                                = 12,
	ELLHSDKSupportedLanguage__Spanish                                                = 13,
	ELLHSDKSupportedLanguage__Thai                                                   = 14,
	ELLHSDKSupportedLanguage__Turkish                                                = 15,
	ELLHSDKSupportedLanguage__Vietnamese                                             = 16,
	ELLHSDKSupportedLanguage__Hindi                                                  = 17,
	ELLHSDKSupportedLanguage__SimplifiedChinese                                      = 18,
	ELLHSDKSupportedLanguage__TraditionalChinese                                     = 19,
	ELLHSDKSupportedLanguage__ELLHSDKSupportedLanguage_MAX                           = 20
};

/// Enum /Script/LLHSDK.ELLHSDKReportCurrencyType
/// Size: 0x04
enum ELLHSDKReportCurrencyType : uint8_t
{
	ELLHSDKReportCurrencyType__USA_Dollar                                            = 0,
	ELLHSDKReportCurrencyType__China_Yuan                                            = 1,
	ELLHSDKReportCurrencyType__Taiwan_Dollar                                         = 2,
	ELLHSDKReportCurrencyType__ELLHSDKReportCurrencyType_MAX                         = 3
};

/// Enum /Script/LLHSDK.ELLHSDKOpenAlbumErrorCode
/// Size: 0x04
enum ELLHSDKOpenAlbumErrorCode : uint8_t
{
	ELLHSDKOpenAlbumErrorCode__None                                                  = 0,
	ELLHSDKOpenAlbumErrorCode__Cancel                                                = 1,
	ELLHSDKOpenAlbumErrorCode__NoPermission                                          = 2,
	ELLHSDKOpenAlbumErrorCode__ELLHSDKOpenAlbumErrorCode_MAX                         = 3
};

/// Enum /Script/LLHSDK.EReleaseType
/// Size: 0x03
enum EReleaseType : uint8_t
{
	EReleaseType__GrayRelease                                                        = 0,
	EReleaseType__Release                                                            = 1,
	EReleaseType__EReleaseType_MAX                                                   = 2
};

/// Enum /Script/LLHSDK.EDistributionRegion
/// Size: 0x03
enum EDistributionRegion : uint8_t
{
	EDistributionRegion__International                                               = 0,
	EDistributionRegion__Domestic                                                    = 1,
	EDistributionRegion__EDistributionRegion_MAX                                     = 2
};

/// Enum /Script/LLHSDK.ELLHSDKLoginUIStyle
/// Size: 0x06
enum ELLHSDKLoginUIStyle : uint8_t
{
	ELLHSDKLoginUIStyle__NormalStyle                                                 = 0,
	ELLHSDKLoginUIStyle__SoulHunterStyle                                             = 1,
	ELLHSDKLoginUIStyle__GameCenterStyle                                             = 2,
	ELLHSDKLoginUIStyle__DomesticStyle                                               = 3,
	ELLHSDKLoginUIStyle__GameCenterDomesticStyle                                     = 4,
	ELLHSDKLoginUIStyle__ELLHSDKLoginUIStyle_MAX                                     = 5
};

/// Enum /Script/LLHSDK.ELLHSDKGravity
/// Size: 0x10
enum ELLHSDKGravity : uint8_t
{
	ELLHSDKGravity__NO_GRAVITY                                                       = 0,
	ELLHSDKGravity__LeftTop                                                          = 1,
	ELLHSDKGravity__LeftCenter                                                       = 2,
	ELLHSDKGravity__LeftBottom                                                       = 3,
	ELLHSDKGravity__MidTop                                                           = 4,
	ELLHSDKGravity__MidBottom                                                        = 5,
	ELLHSDKGravity__RightTop                                                         = 6,
	ELLHSDKGravity__RightCenter                                                      = 7,
	ELLHSDKGravity__RightBottom                                                      = 8,
	ELLHSDKGravity__ELLHSDKGravity_MAX                                               = 9
};

