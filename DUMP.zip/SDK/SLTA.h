/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package SLTA.

/// Class /Script/SLTA.SLTA_BPL
/// Size: 0x0000 (0x000028 - 0x000028)
class USLTA_BPL : public UObject
{ 
public:
};

