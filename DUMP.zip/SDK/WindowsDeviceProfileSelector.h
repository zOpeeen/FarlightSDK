/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package WindowsDeviceProfileSelector.

/// Class /Script/WindowsDeviceProfileSelector.WindowsDeviceProfileMatchingRules
/// Size: 0x0020 (0x000028 - 0x000048)
class UWindowsDeviceProfileMatchingRules : public UObject
{ 
public:
	TArray<FWIndowProfileMatchGPU>                     MatchProfileGPU;                                            // 0x0028   (0x0010)  
	TArray<FWIndowProfileMatchCPU>                     MatchProfileCPU;                                            // 0x0038   (0x0010)  
};

/// Struct /Script/WindowsDeviceProfileSelector.WIndowProfileMatchCPU
/// Size: 0x0020 (0x000000 - 0x000020)
struct FWIndowProfileMatchCPU
{ 
	FString                                            Profile;                                                    // 0x0000   (0x0010)  
	FWindowsProfileMatchItemCPU                        Match;                                                      // 0x0010   (0x0010)  
};

/// Struct /Script/WindowsDeviceProfileSelector.WindowsProfileMatchItemCPU
/// Size: 0x0010 (0x000000 - 0x000010)
struct FWindowsProfileMatchItemCPU
{ 
	FString                                            PrimaryCPUBrand;                                            // 0x0000   (0x0010)  
};

/// Struct /Script/WindowsDeviceProfileSelector.WIndowProfileMatchGPU
/// Size: 0x0030 (0x000000 - 0x000030)
struct FWIndowProfileMatchGPU
{ 
	FString                                            Profile;                                                    // 0x0000   (0x0010)  
	FWindowsProfileMatchItemGPU                        Match;                                                      // 0x0010   (0x0020)  
};

/// Struct /Script/WindowsDeviceProfileSelector.WindowsProfileMatchItemGPU
/// Size: 0x0020 (0x000000 - 0x000020)
struct FWindowsProfileMatchItemGPU
{ 
	FString                                            PrimaryGPUBrand;                                            // 0x0000   (0x0010)  
	FString                                            GraphicsMemorySize;                                         // 0x0010   (0x0010)  
};

/// Enum /Script/WindowsDeviceProfileSelector.EWindowsDeviceLevel
/// Size: 0x07
enum EWindowsDeviceLevel : uint8_t
{
	EWindowsDeviceLevel__DeviceLevel1                                                = 1,
	EWindowsDeviceLevel__DeviceLevel2                                                = 2,
	EWindowsDeviceLevel__DeviceLevel3                                                = 3,
	EWindowsDeviceLevel__DeviceLevel4                                                = 4,
	EWindowsDeviceLevel__DeviceLevel5                                                = 5,
	EWindowsDeviceLevel__DeviceLevel6                                                = 6,
	EWindowsDeviceLevel__EWindowsDeviceLevel_MAX                                     = 7
};

