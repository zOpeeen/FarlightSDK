/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package RichtapTools.

/// Class /Script/RichtapTools.RichtapController
/// Size: 0x0098 (0x000028 - 0x0000C0)
class URichtapController : public UObject
{ 
public:
	unsigned char                                      UnknownData00_2[0x48];                                      // 0x0028   (0x0048)  MISSED
	TMap<FString, URichtapClip*>                       HeDataMap;                                                  // 0x0070   (0x0050)  


	/// Functions
	// Function /Script/RichtapTools.RichtapController.SetRichtapEnable
	void SetRichtapEnable(bool On);                                                                                          // [0xb76490] Final|Native|Public  
	// Function /Script/RichtapTools.RichtapController.SetEnableWinRichtap
	void SetEnableWinRichtap(bool bIsEnableWinRichtap);                                                                      // [0xb76410] Final|Native|Static|Public|BlueprintCallable 
	// Function /Script/RichtapTools.RichtapController.SetEnableRichtap
	void SetEnableRichtap(bool bIsEnableRichtap);                                                                            // [0xb76390] Final|Native|Static|Public|BlueprintCallable 
};

