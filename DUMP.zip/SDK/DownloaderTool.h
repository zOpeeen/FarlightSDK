/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package DownloaderTool.

/// Class /Script/DownloaderTool.DownloaderHttpTask
/// Size: 0x00A0 (0x000028 - 0x0000C8)
class UDownloaderHttpTask : public UObject
{ 
public:
	FMulticastInlineDelegate                           OnTaskProgress;                                             // 0x0028   (0x0010)  
	FMulticastInlineDelegate                           OnTaskSuccess;                                              // 0x0038   (0x0010)  
	FMulticastInlineDelegate                           OnTaskFailed;                                               // 0x0048   (0x0010)  
	unsigned char                                      UnknownData00_6[0x70];                                      // 0x0058   (0x0070)  MISSED
};

/// Class /Script/DownloaderTool.DownloaderUtils
/// Size: 0x0000 (0x000028 - 0x000028)
class UDownloaderUtils : public UObject
{ 
public:
};

/// Struct /Script/DownloaderTool.DownloaderResponse
/// Size: 0x0048 (0x000000 - 0x000048)
struct FDownloaderResponse
{ 
	FString                                            URL;                                                        // 0x0000   (0x0010)  
	int32_t                                            ErrorCode;                                                  // 0x0010   (0x0004)  
	unsigned char                                      UnknownData00_5[0x4];                                       // 0x0014   (0x0004)  MISSED
	TArray<char>                                       Data;                                                       // 0x0018   (0x0010)  
	bool                                               bWasSuccessful;                                             // 0x0028   (0x0001)  
	unsigned char                                      UnknownData01_5[0x3];                                       // 0x0029   (0x0003)  MISSED
	int32_t                                            ContentLength;                                              // 0x002C   (0x0004)  
	int32_t                                            DataLength;                                                 // 0x0030   (0x0004)  
	unsigned char                                      UnknownData02_5[0x4];                                       // 0x0034   (0x0004)  MISSED
	int64_t                                            Timestamp;                                                  // 0x0038   (0x0008)  
	ERawDataAction                                     RawDataAction;                                              // 0x0040   (0x0001)  
	unsigned char                                      UnknownData03_6[0x7];                                       // 0x0041   (0x0007)  MISSED
};

/// Struct /Script/DownloaderTool.DownloaderTaskInfo
/// Size: 0x0070 (0x000000 - 0x000070)
struct FDownloaderTaskInfo
{ 
	FString                                            URL;                                                        // 0x0000   (0x0010)  
	FString                                            JsonRequestStr;                                             // 0x0010   (0x0010)  
	bool                                               bCompleted;                                                 // 0x0020   (0x0001)  
	unsigned char                                      UnknownData00_5[0x7];                                       // 0x0021   (0x0007)  MISSED
	int64_t                                            CompleteTimeStamp;                                          // 0x0028   (0x0008)  
	bool                                               bUsingResumeTrans;                                          // 0x0030   (0x0001)  
	bool                                               bForceRedownload;                                           // 0x0031   (0x0001)  
	bool                                               bSaveToCache;                                               // 0x0032   (0x0001)  
	unsigned char                                      UnknownData01_5[0x5];                                       // 0x0033   (0x0005)  MISSED
	FString                                            FileDirectory;                                              // 0x0038   (0x0010)  
	FString                                            Filename;                                                   // 0x0048   (0x0010)  
	FString                                            FileExtension;                                              // 0x0058   (0x0010)  
	ERawDataAction                                     RawDataAction;                                              // 0x0068   (0x0001)  
	unsigned char                                      UnknownData02_6[0x7];                                       // 0x0069   (0x0007)  MISSED
};

/// Enum /Script/DownloaderTool.ERawDataAction
/// Size: 0x05
enum ERawDataAction : uint8_t
{
	ERawDataAction__Default                                                          = 0,
	ERawDataAction__UTF8String                                                       = 1,
	ERawDataAction__ReverseDecryptString                                             = 2,
	ERawDataAction__Texture2DDynamic                                                 = 3,
	ERawDataAction__ERawDataAction_MAX                                               = 4
};

/// Enum /Script/DownloaderTool.EDownloaderFailedType
/// Size: 0x18
enum EDownloaderFailedType : uint8_t
{
	EDownloaderFailedType__ConnectFailed                                             = 0,
	EDownloaderFailedType__RequestHeadFailed                                         = 1,
	EDownloaderFailedType__CreateFileFailed                                          = 2,
	EDownloaderFailedType__DownloadFailed                                            = 3,
	EDownloaderFailedType__WriteFailed                                               = 4,
	EDownloaderFailedType__DeleteOldFailed                                           = 5,
	EDownloaderFailedType__MoveFailed                                                = 6,
	EDownloaderFailedType__CreateDownloadTaskFail                                    = 7,
	EDownloaderFailedType__GetPlatformFileFail                                       = 8,
	EDownloaderFailedType__GetWrongJsonFormat                                        = 9,
	EDownloaderFailedType__RequestTimeOut                                            = 10,
	EDownloaderFailedType__RequestInvalid                                            = 11,
	EDownloaderFailedType__ResponseInvalid                                           = 12,
	EDownloaderFailedType__RequestCanceled                                           = 13,
	EDownloaderFailedType__ResponseNoContent                                         = 14,
	EDownloaderFailedType__TaskHasCompleted                                          = 15,
	EDownloaderFailedType__FileIODownloadFailed                                      = 16,
	EDownloaderFailedType__EDownloaderFailedType_MAX                                 = 17
};

/// Enum /Script/DownloaderTool.EServerInfoState
/// Size: 0x06
enum EServerInfoState : uint8_t
{
	EServerInfoState__ESIS_NotReady                                                  = 0,
	EServerInfoState__ESIS_Downloading                                               = 1,
	EServerInfoState__ESIS_Ready                                                     = 2,
	EServerInfoState__ESIS_Failed                                                    = 3,
	EServerInfoState__ESIS_OutOfDate                                                 = 4,
	EServerInfoState__ESIS_MAX                                                       = 5
};

/// Enum /Script/DownloaderTool.EDownloaderState
/// Size: 0x05
enum EDownloaderState : uint8_t
{
	EDownloaderState__NotStart                                                       = 0,
	EDownloaderState__Downloading                                                    = 1,
	EDownloaderState__Pausing                                                        = 2,
	EDownloaderState__Completed                                                      = 3,
	EDownloaderState__EDownloaderState_MAX                                           = 4
};

