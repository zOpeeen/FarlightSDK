/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package AndroidPermission.

/// Class /Script/AndroidPermission.AndroidPermissionCallbackProxy
/// Size: 0x0020 (0x000028 - 0x000048)
class UAndroidPermissionCallbackProxy : public UObject
{ 
public:
	FMulticastInlineDelegate                           OnPermissionsGrantedDynamicDelegate;                        // 0x0028   (0x0010)  
	unsigned char                                      UnknownData00_6[0x10];                                      // 0x0038   (0x0010)  MISSED
};

/// Class /Script/AndroidPermission.AndroidPermissionFunctionLibrary
/// Size: 0x0000 (0x000028 - 0x000028)
class UAndroidPermissionFunctionLibrary : public UBlueprintFunctionLibrary
{ 
public:
};

