/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package CascadeExtensionPlugin.

/// Class /Script/CascadeExtensionPlugin.AbstractParticleModule
/// Size: 0x0030 (0x000030 - 0x000060)
class UAbstractParticleModule : public UParticleModule
{ 
public:
	FParticleRandomSeedInfo                            RandomSeedInfo;                                             // 0x0030   (0x0020)  
	int32_t                                            StartDelay;                                                 // 0x0050   (0x0004)  
	int32_t                                            MaxDuration;                                                // 0x0054   (0x0004)  
	int32_t                                            LoopAfter;                                                  // 0x0058   (0x0004)  
	unsigned char                                      UnknownData00_6[0x4];                                       // 0x005C   (0x0004)  MISSED
};

/// Class /Script/CascadeExtensionPlugin.ForcePointDataProvider
/// Size: 0x0000 (0x000028 - 0x000028)
class UForcePointDataProvider : public UInterface
{ 
public:
};

/// Class /Script/CascadeExtensionPlugin.MeshDataProvider
/// Size: 0x0000 (0x000028 - 0x000028)
class UMeshDataProvider : public UInterface
{ 
public:
};

/// Class /Script/CascadeExtensionPlugin.ParticleDataProvider
/// Size: 0x0000 (0x000028 - 0x000028)
class UParticleDataProvider : public UInterface
{ 
public:
};

/// Class /Script/CascadeExtensionPlugin.ParticleDecalComponent
/// Size: 0x0010 (0x000360 - 0x000370)
class UParticleDecalComponent : public UDecalComponent
{ 
public:
	int32_t                                            ModuleID;                                                   // 0x0358   (0x0004)  
	float                                              TimeLeftUntilDestruction;                                   // 0x035C   (0x0004)  
	FVector                                            BaseScale;                                                  // 0x0360   (0x000C)  
	unsigned char                                      UnknownData00_6[0x4];                                       // 0x036C   (0x0004)  MISSED
};

/// Class /Script/CascadeExtensionPlugin.ParticleModuleColorTexture
/// Size: 0x0050 (0x000060 - 0x0000B0)
class UParticleModuleColorTexture : public UAbstractParticleModule
{ 
public:
	UTexture2D*                                        ColorIndexTexture;                                          // 0x0060   (0x0008)  
	bool                                               UpdateWithTick;                                             // 0x0068   (0x0001)  
	unsigned char                                      UnknownData00_5[0x3];                                       // 0x0069   (0x0003)  MISSED
	FBox                                               MapBounds;                                                  // 0x006C   (0x001C)  
	TEnumAsByte<ESpaceAxis>                            ParticleAxisToTextureX;                                     // 0x0088   (0x0001)  
	TEnumAsByte<ESpaceAxis>                            ParticleAxisToTextureY;                                     // 0x0089   (0x0001)  
	unsigned char                                      UnknownData01_5[0x2];                                       // 0x008A   (0x0002)  MISSED
	float                                              Intensity;                                                  // 0x008C   (0x0004)  
	bool                                               UseTextureAlpha;                                            // 0x0090   (0x0001)  
	unsigned char                                      UnknownData02_6[0x1F];                                      // 0x0091   (0x001F)  MISSED
};

/// Class /Script/CascadeExtensionPlugin.ParticleModuleCustomData
/// Size: 0x0010 (0x000060 - 0x000070)
class UParticleModuleCustomData : public UAbstractParticleModule
{ 
public:
	FName                                              DataProviderParameterName;                                  // 0x0060   (0x0008)  
	bool                                               UpdatedSpawnedParticles;                                    // 0x0068   (0x0001)  
	bool                                               UpdatedTickedParticles;                                     // 0x0069   (0x0001)  
	bool                                               UseLocationFromProvider;                                    // 0x006A   (0x0001)  
	bool                                               UseVelocityFromProvider;                                    // 0x006B   (0x0001)  
	bool                                               UseSizeFromProvider;                                        // 0x006C   (0x0001)  
	bool                                               UseColorFromProvider;                                       // 0x006D   (0x0001)  
	bool                                               UseRotationFromProvider;                                    // 0x006E   (0x0001)  
	bool                                               UseRotationRateFromProvider;                                // 0x006F   (0x0001)  
};

/// Class /Script/CascadeExtensionPlugin.ParticleModuleDecalComponent
/// Size: 0x00C0 (0x000060 - 0x000120)
class UParticleModuleDecalComponent : public UAbstractParticleModule
{ 
public:
	TArray<UMaterialInterface*>                        DecalMaterials;                                             // 0x0060   (0x0010)  
	FRawDistributionVector                             DecalScale;                                                 // 0x0070   (0x0048)  
	bool                                               ScaleWithParticleSize;                                      // 0x00B8   (0x0001)  
	unsigned char                                      UnknownData00_5[0x7];                                       // 0x00B9   (0x0007)  MISSED
	FRawDistributionVector                             DecalRotation;                                              // 0x00C0   (0x0048)  
	bool                                               RotateToParticleVelocity;                                   // 0x0108   (0x0001)  
	unsigned char                                      UnknownData01_5[0x3];                                       // 0x0109   (0x0003)  MISSED
	int32_t                                            SortOrder;                                                  // 0x010C   (0x0004)  
	bool                                               OptimizeDecalComponentUsage;                                // 0x0110   (0x0001)  
	unsigned char                                      UnknownData02_5[0x3];                                       // 0x0111   (0x0003)  MISSED
	FName                                              MaterialColorParameter;                                     // 0x0114   (0x0008)  
	unsigned char                                      UnknownData03_6[0x4];                                       // 0x011C   (0x0004)  MISSED
};

/// Class /Script/CascadeExtensionPlugin.ParticleModuleForcePoints
/// Size: 0x0028 (0x000060 - 0x000088)
class UParticleModuleForcePoints : public UAbstractParticleModule
{ 
public:
	float                                              Intensity;                                                  // 0x0060   (0x0004)  
	unsigned char                                      UnknownData00_5[0x4];                                       // 0x0064   (0x0004)  MISSED
	TArray<FVector>                                    Points;                                                     // 0x0068   (0x0010)  
	TEnumAsByte<EDistanceWeight>                       SeparationDistanceWeight;                                   // 0x0078   (0x0001)  
	unsigned char                                      UnknownData01_5[0x3];                                       // 0x0079   (0x0003)  MISSED
	float                                              DistanceScale;                                              // 0x007C   (0x0004)  
	FName                                              DynamicForcePointProviderName;                              // 0x0080   (0x0008)  
};

/// Class /Script/CascadeExtensionPlugin.ParticleModuleLocationDonut
/// Size: 0x0018 (0x000060 - 0x000078)
class UParticleModuleLocationDonut : public UAbstractParticleModule
{ 
public:
	FVector                                            Center;                                                     // 0x0060   (0x000C)  
	float                                              MinRadius;                                                  // 0x006C   (0x0004)  
	float                                              MaxRadius;                                                  // 0x0070   (0x0004)  
	bool                                               SurfaceOnly;                                                // 0x0074   (0x0001)  
	bool                                               IsFlat;                                                     // 0x0075   (0x0001)  
	unsigned char                                      UnknownData00_6[0x2];                                       // 0x0076   (0x0002)  MISSED
};

/// Class /Script/CascadeExtensionPlugin.ParticleModuleLocationHeightmap
/// Size: 0x0048 (0x000060 - 0x0000A8)
class UParticleModuleLocationHeightmap : public UAbstractParticleModule
{ 
public:
	UTexture2D*                                        HeightmapTexture;                                           // 0x0060   (0x0008)  
	bool                                               UpdateWithTick;                                             // 0x0068   (0x0001)  
	bool                                               SmoothUpdate;                                               // 0x0069   (0x0001)  
	unsigned char                                      UnknownData00_5[0x2];                                       // 0x006A   (0x0002)  MISSED
	FBox                                               MapBounds;                                                  // 0x006C   (0x001C)  
	float                                              Intensity;                                                  // 0x0088   (0x0004)  
	unsigned char                                      UnknownData01_6[0x1C];                                      // 0x008C   (0x001C)  MISSED
};

/// Class /Script/CascadeExtensionPlugin.ParticleModuleLocationJiggle
/// Size: 0x0048 (0x000060 - 0x0000A8)
class UParticleModuleLocationJiggle : public UAbstractParticleModule
{ 
public:
	FRawDistributionVector                             Intensity;                                                  // 0x0060   (0x0048)  
};

/// Class /Script/CascadeExtensionPlugin.ParticleModuleLocationMesh
/// Size: 0x00F0 (0x000060 - 0x000150)
class UParticleModuleLocationMesh : public UAbstractParticleModule
{ 
public:
	UStaticMesh*                                       SurfaceMesh;                                                // 0x0060   (0x0008)  
	FName                                              DynamicMeshParameterName;                                   // 0x0068   (0x0008)  
	FTransform                                         MeshTransform;                                              // 0x0070   (0x0030)  
	bool                                               EqualTriangeWeight;                                         // 0x00A0   (0x0001)  
	unsigned char                                      UnknownData00_5[0x7];                                       // 0x00A1   (0x0007)  MISSED
	FRawDistributionFloat                              VelocityScale;                                              // 0x00A8   (0x0030)  
	unsigned char                                      UnknownData01_6[0x78];                                      // 0x00D8   (0x0078)  MISSED


	/// Functions
	// Function /Script/CascadeExtensionPlugin.ParticleModuleLocationMesh.OnCachedActorDestroyed
	void OnCachedActorDestroyed(AActor* DestroyedActor);                                                                     // [0xccced0] Final|Native|Private 
};

/// Class /Script/CascadeExtensionPlugin.ParticleModuleLocationSpiral
/// Size: 0x00C0 (0x000060 - 0x000120)
class UParticleModuleLocationSpiral : public UAbstractParticleModule
{ 
public:
	FRawDistributionVector                             StartLocation;                                              // 0x0060   (0x0048)  
	FRawDistributionFloat                              Radius;                                                     // 0x00A8   (0x0030)  
	float                                              DeltaAngle;                                                 // 0x00D8   (0x0004)  
	float                                              EllipseA;                                                   // 0x00DC   (0x0004)  
	float                                              EllipseB;                                                   // 0x00E0   (0x0004)  
	unsigned char                                      UnknownData00_5[0x4];                                       // 0x00E4   (0x0004)  MISSED
	FRawDistributionFloat                              DiscHeight;                                                 // 0x00E8   (0x0030)  
	float                                              FalloffFactor;                                              // 0x0118   (0x0004)  
	unsigned char                                      UnknownData01_6[0x4];                                       // 0x011C   (0x0004)  MISSED
};

/// Class /Script/CascadeExtensionPlugin.ParticleModuleSizeBySpeedOverTime
/// Size: 0x0068 (0x000060 - 0x0000C8)
class UParticleModuleSizeBySpeedOverTime : public UAbstractParticleModule
{ 
public:
	FRawDistributionVector                             Size;                                                       // 0x0060   (0x0048)  
	bool                                               InvertSpeed;                                                // 0x00A8   (0x0001)  
	unsigned char                                      UnknownData00_5[0x3];                                       // 0x00A9   (0x0003)  MISSED
	FVector                                            MaxSize;                                                    // 0x00AC   (0x000C)  
	FVector                                            MinSize;                                                    // 0x00B8   (0x000C)  
	unsigned char                                      UnknownData01_6[0x4];                                       // 0x00C4   (0x0004)  MISSED
};

/// Class /Script/CascadeExtensionPlugin.ParticleModuleSortOrder
/// Size: 0x0008 (0x000060 - 0x000068)
class UParticleModuleSortOrder : public UAbstractParticleModule
{ 
public:
	int32_t                                            SortOrder;                                                  // 0x0060   (0x0004)  
	unsigned char                                      UnknownData00_6[0x4];                                       // 0x0064   (0x0004)  MISSED
};

/// Class /Script/CascadeExtensionPlugin.ParticleModuleSwarmMovement
/// Size: 0x0040 (0x000060 - 0x0000A0)
class UParticleModuleSwarmMovement : public UAbstractParticleModule
{ 
public:
	float                                              PerceptionRadius;                                           // 0x0060   (0x0004)  
	float                                              MaxAcceleration;                                            // 0x0064   (0x0004)  
	float                                              MaxVelocity;                                                // 0x0068   (0x0004)  
	float                                              SeparationWeight;                                           // 0x006C   (0x0004)  
	float                                              AlignmentWeight;                                            // 0x0070   (0x0004)  
	float                                              CohesionWeight;                                             // 0x0074   (0x0004)  
	float                                              BlindspotAngleDeg;                                          // 0x0078   (0x0004)  
	TEnumAsByte<EDistanceWeight>                       SeparationDistanceWeight;                                   // 0x007C   (0x0001)  
	unsigned char                                      UnknownData00_5[0x3];                                       // 0x007D   (0x0003)  MISSED
	TArray<FVector>                                    SteeringTargets;                                            // 0x0080   (0x0010)  
	float                                              SteeringWeight;                                             // 0x0090   (0x0004)  
	TEnumAsByte<EDistanceWeight>                       SteeringTargetDistanceWeight;                               // 0x0094   (0x0001)  
	unsigned char                                      UnknownData01_5[0x3];                                       // 0x0095   (0x0003)  MISSED
	FName                                              DynamicSteeringPointProviderName;                           // 0x0098   (0x0008)  
};

/// Class /Script/CascadeExtensionPlugin.ParticleModuleVelocityTurbulence
/// Size: 0x0020 (0x000060 - 0x000080)
class UParticleModuleVelocityTurbulence : public UAbstractParticleModule
{ 
public:
	FVector                                            Intensity;                                                  // 0x0060   (0x000C)  
	float                                              LengthScale;                                                // 0x006C   (0x0004)  
	float                                              Tightness;                                                  // 0x0070   (0x0004)  
	float                                              MaxAcceleration;                                            // 0x0074   (0x0004)  
	float                                              MaxVelocity;                                                // 0x0078   (0x0004)  
	unsigned char                                      UnknownData00_6[0x4];                                       // 0x007C   (0x0004)  MISSED
};

/// Struct /Script/CascadeExtensionPlugin.ForcePoints
/// Size: 0x0020 (0x000000 - 0x000020)
struct FForcePoints
{ 
	float                                              Intensity;                                                  // 0x0000   (0x0004)  
	unsigned char                                      UnknownData00_5[0x4];                                       // 0x0004   (0x0004)  MISSED
	TArray<FVector>                                    PointLocations;                                             // 0x0008   (0x0010)  
	TEnumAsByte<EDistanceWeight>                       SeparationDistanceWeight;                                   // 0x0018   (0x0001)  
	unsigned char                                      UnknownData01_5[0x3];                                       // 0x0019   (0x0003)  MISSED
	float                                              DistanceScale;                                              // 0x001C   (0x0004)  
};

/// Struct /Script/CascadeExtensionPlugin.MeshTriangleData
/// Size: 0x0020 (0x000000 - 0x000020)
struct FMeshTriangleData
{ 
	TArray<FVector>                                    Vertices;                                                   // 0x0000   (0x0010)  
	TArray<FTriangleIndices>                           Indices;                                                    // 0x0010   (0x0010)  
};

/// Struct /Script/CascadeExtensionPlugin.TriangleIndices
/// Size: 0x000C (0x000000 - 0x00000C)
struct FTriangleIndices
{ 
	int32_t                                            v0;                                                         // 0x0000   (0x0004)  
	int32_t                                            v1;                                                         // 0x0004   (0x0004)  
	int32_t                                            v2;                                                         // 0x0008   (0x0004)  
};

/// Struct /Script/CascadeExtensionPlugin.ParticleProperties
/// Size: 0x0044 (0x000000 - 0x000044)
struct FParticleProperties
{ 
	int32_t                                            ParticleId;                                                 // 0x0000   (0x0004)  
	float                                              RelativeTime;                                               // 0x0004   (0x0004)  
	FVector                                            Location;                                                   // 0x0008   (0x000C)  
	FVector                                            Velocity;                                                   // 0x0014   (0x000C)  
	FVector                                            Size;                                                       // 0x0020   (0x000C)  
	FLinearColor                                       Color;                                                      // 0x002C   (0x0010)  
	float                                              Rotation;                                                   // 0x003C   (0x0004)  
	float                                              RotationRate;                                               // 0x0040   (0x0004)  
};

/// Enum /Script/CascadeExtensionPlugin.EDistanceWeight
/// Size: 0x06
enum EDistanceWeight : uint8_t
{
	EDistanceWeight__LINEAR                                                          = 0,
	EDistanceWeight__INVERSE_LINEAR                                                  = 1,
	EDistanceWeight__QUADRATIC                                                       = 2,
	EDistanceWeight__INVERSE_QUAD                                                    = 3,
	EDistanceWeight__W_Max                                                           = 4,
	EDistanceWeight__EDistanceWeight_MAX                                             = 5
};

/// Enum /Script/CascadeExtensionPlugin.ESpaceAxis
/// Size: 0x05
enum ESpaceAxis : uint8_t
{
	ESpaceAxis__X                                                                    = 0,
	ESpaceAxis__Y                                                                    = 1,
	ESpaceAxis__Z                                                                    = 2,
	ESpaceAxis__Ax_Max                                                               = 3,
	ESpaceAxis__ESpaceAxis_MAX                                                       = 4
};

