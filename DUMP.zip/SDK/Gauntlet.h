/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package Gauntlet.

/// Class /Script/Gauntlet.GauntletTestController
/// Size: 0x0008 (0x000028 - 0x000030)
class UGauntletTestController : public UObject
{ 
public:
	unsigned char                                      UnknownData00_1[0x8];                                       // 0x0028   (0x0008)  MISSED
};

/// Class /Script/Gauntlet.GauntletTestControllerBootTest
/// Size: 0x0000 (0x000030 - 0x000030)
class UGauntletTestControllerBootTest : public UGauntletTestController
{ 
public:
};

/// Class /Script/Gauntlet.GauntletTestControllerErrorTest
/// Size: 0x0020 (0x000030 - 0x000050)
class UGauntletTestControllerErrorTest : public UGauntletTestController
{ 
public:
	unsigned char                                      UnknownData00_1[0x20];                                      // 0x0030   (0x0020)  MISSED
};

