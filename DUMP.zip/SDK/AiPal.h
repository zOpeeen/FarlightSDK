/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package AiPal.

/// Class /Script/AiPal.AiPalComponent
/// Size: 0x0000 (0x0000B0 - 0x0000B0)
class UAiPalComponent : public UActorComponent
{ 
public:
};

