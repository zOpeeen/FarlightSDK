/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package DTBPJson.

/// Class /Script/DTBPJson.DTBPJsonBPLib
/// Size: 0x0000 (0x000028 - 0x000028)
class UDTBPJsonBPLib : public UBlueprintFunctionLibrary
{ 
public:
};

/// Struct /Script/DTBPJson.DTStruct
/// Size: 0x0001 (0x000000 - 0x000001)
struct FDTStruct
{ 
	unsigned char                                      UnknownData00_1[0x1];                                       // 0x0000   (0x0001)  MISSED
};

