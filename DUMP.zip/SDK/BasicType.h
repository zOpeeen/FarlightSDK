/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package BasicType.

/// Struct /Custom/FName
/// Size: 0x0008 (0x000000 - 0x000008)
struct FName
{ 
	unsigned char                                      UnknownData00_1[0x8];                                       // 0x0000   (0x0008)  MISSED
};

/// Struct /Custom/TArray
/// Size: 0x0010 (0x000000 - 0x000010)
struct TArray
{ 
	T*                                                 Data;                                                       // 0x0000   (0x0008)  
	int                                                Count;                                                      // 0x0008   (0x0004)  
	int                                                Max;                                                        // 0x000C   (0x0004)  
};

