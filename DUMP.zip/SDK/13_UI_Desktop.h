/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package 13_UI_Desktop.

/// Class /Game/13_UI_Desktop/Blueprints/Common/UI_CursorWidget_Default.UI_CursorWidget_Default_C
/// Size: 0x0008 (0x000260 - 0x000268)
class UUI_CursorWidget_Default_C : public UUserWidget
{ 
public:
	UCanvasPanel*                                      CursorCanvas;                                               // 0x0260   (0x0008)  


	/// Functions
	// Function /Game/13_UI_Desktop/Blueprints/Common/UI_CursorWidget_Default.UI_CursorWidget_Default_C.GetModuleName
	FString GetModuleName();                                                                                                 // [0x2d64c70] Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const 
};

