/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package ProtectBase.

/// Class /Script/ProtectBase.ProtectBaseComponent
/// Size: 0x0008 (0x000028 - 0x000030)
class UProtectBaseComponent : public UObject
{ 
public:
	unsigned char                                      UnknownData00_1[0x8];                                       // 0x0028   (0x0008)  MISSED
};

/// Class /Script/ProtectBase.ProtectBaseManager
/// Size: 0x0000 (0x000028 - 0x000028)
class UProtectBaseManager : public UObject
{ 
public:
};

/// Class /Script/ProtectBase.SecDSComponent
/// Size: 0x0098 (0x000028 - 0x0000C0)
class USecDSComponent : public UObject
{ 
public:
	unsigned char                                      UnknownData00_1[0x98];                                      // 0x0028   (0x0098)  MISSED
};

