/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package ImpostorBaker.

/// Class /Script/ImpostorBaker.KismetImpostorBakerLibrary
/// Size: 0x0000 (0x000028 - 0x000028)
class UKismetImpostorBakerLibrary : public UBlueprintFunctionLibrary
{ 
public:
};

