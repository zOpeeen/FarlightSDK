/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package MobilePatchingUtils.

/// Class /Script/MobilePatchingUtils.MobileInstalledContent
/// Size: 0x0020 (0x000028 - 0x000048)
class UMobileInstalledContent : public UObject
{ 
public:
	unsigned char                                      UnknownData00_1[0x20];                                      // 0x0028   (0x0020)  MISSED
};

/// Class /Script/MobilePatchingUtils.MobilePendingContent
/// Size: 0x0040 (0x000048 - 0x000088)
class UMobilePendingContent : public UMobileInstalledContent
{ 
public:
	unsigned char                                      UnknownData00_1[0x40];                                      // 0x0048   (0x0040)  MISSED
};

/// Class /Script/MobilePatchingUtils.MobilePatchingLibrary
/// Size: 0x0000 (0x000028 - 0x000028)
class UMobilePatchingLibrary : public UBlueprintFunctionLibrary
{ 
public:
};

