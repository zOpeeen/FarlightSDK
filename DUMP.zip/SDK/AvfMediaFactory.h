/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package AvfMediaFactory.

/// Class /Script/AvfMediaFactory.AvfMediaSettings
/// Size: 0x0008 (0x000028 - 0x000030)
class UAvfMediaSettings : public UObject
{ 
public:
	bool                                               NativeAudioOut;                                             // 0x0028   (0x0001)  
	unsigned char                                      UnknownData00_6[0x7];                                       // 0x0029   (0x0007)  MISSED
};

