/********************************************************
*                                                       *
*   Package generated using UEDumper by Spuckwaffel.    *
*                                                       *
********************************************************/

/// Package FacialAnimation.

/// Class /Script/FacialAnimation.AudioCurveSourceComponent
/// Size: 0x0040 (0x000900 - 0x000940)
class UAudioCurveSourceComponent : public UAudioComponent
{ 
public:
	FName                                              CurveSourceBindingName;                                     // 0x0900   (0x0008)  
	float                                              CurveSyncOffset;                                            // 0x0908   (0x0004)  
	unsigned char                                      UnknownData00_6[0x34];                                      // 0x090C   (0x0034)  MISSED
};

