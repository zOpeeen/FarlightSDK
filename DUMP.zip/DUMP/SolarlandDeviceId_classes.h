// Class SolarlandDeviceId.SolarlandDeviceInfoSettings
// Size: 0x48 (Inherited: 0x38)
struct USolarlandDeviceInfoSettings : UDeveloperSettings {
	struct FString UserName; // 0x38(0x10)

	struct USolarlandDeviceInfoSettings* GetInstance(); // Function SolarlandDeviceId.SolarlandDeviceInfoSettings.GetInstance // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2a53050
};

