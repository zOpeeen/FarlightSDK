// Class UdiniIntermediateModule.UdiniIntermediateModuleBPLibrary
// Size: 0x28 (Inherited: 0x28)
struct UUdiniIntermediateModuleBPLibrary : UBlueprintFunctionLibrary {

	float UdiniIntermediateModuleSampleFunction(float Param); // Function UdiniIntermediateModule.UdiniIntermediateModuleBPLibrary.UdiniIntermediateModuleSampleFunction // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x1ce5160
};

