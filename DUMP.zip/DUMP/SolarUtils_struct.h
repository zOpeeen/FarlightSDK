// ScriptStruct SolarUtils.SolarAggregationTickFunction
// Size: 0x30 (Inherited: 0x28)
struct FSolarAggregationTickFunction : FTickFunction {
	char pad_28[0x8]; // 0x28(0x08)
};

