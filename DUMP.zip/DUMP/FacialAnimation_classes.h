// Class FacialAnimation.AudioCurveSourceComponent
// Size: 0x940 (Inherited: 0x900)
struct UAudioCurveSourceComponent : UAudioComponent {
	struct FName CurveSourceBindingName; // 0x900(0x08)
	float CurveSyncOffset; // 0x908(0x04)
	char pad_90C[0x34]; // 0x90c(0x34)
};

