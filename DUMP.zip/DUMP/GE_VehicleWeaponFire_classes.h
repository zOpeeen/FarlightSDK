// BlueprintGeneratedClass GE_VehicleWeaponFire.GE_VehicleWeaponFire_C
// Size: 0x848 (Inherited: 0x848)
struct UGE_VehicleWeaponFire_C : UGameplayEffect {
};

