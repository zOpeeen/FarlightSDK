// BlueprintGeneratedClass GA_VehicleWeaponFire.GA_VehicleWeaponFire_C
// Size: 0x508 (Inherited: 0x508)
struct UGA_VehicleWeaponFire_C : USolarVehicleGA_WeaponFire {
};

