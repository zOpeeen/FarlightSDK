// Class WindowsDeviceProfileSelector.WindowsDeviceProfileMatchingRules
// Size: 0x48 (Inherited: 0x28)
struct UWindowsDeviceProfileMatchingRules : UObject {
	struct TArray<struct FWIndowProfileMatchGPU> MatchProfileGPU; // 0x28(0x10)
	struct TArray<struct FWIndowProfileMatchCPU> MatchProfileCPU; // 0x38(0x10)
};

