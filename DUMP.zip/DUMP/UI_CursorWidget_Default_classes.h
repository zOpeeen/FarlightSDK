// WidgetBlueprintGeneratedClass UI_CursorWidget_Default.UI_CursorWidget_Default_C
// Size: 0x268 (Inherited: 0x260)
struct UUI_CursorWidget_Default_C : UUserWidget {
	struct UCanvasPanel* CursorCanvas; // 0x260(0x08)

	struct FString GetModuleName(); // Function UI_CursorWidget_Default.UI_CursorWidget_Default_C.GetModuleName // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x2d64a40
};

