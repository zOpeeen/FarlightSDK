// Class SignificanceManager.SignificanceManager
// Size: 0x138 (Inherited: 0x28)
struct USignificanceManager : UObject {
	char pad_28[0xf8]; // 0x28(0xf8)
	struct FSoftClassPath SignificanceManagerClassName; // 0x120(0x18)
};

