// Class ProtectBase.ProtectBaseComponent
// Size: 0x30 (Inherited: 0x28)
struct UProtectBaseComponent : UObject {
	char pad_28[0x8]; // 0x28(0x08)

	struct UProtectBaseComponent* GetInstance(); // Function ProtectBase.ProtectBaseComponent.GetInstance // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xcc06a0
};

// Class ProtectBase.ProtectBaseManager
// Size: 0x28 (Inherited: 0x28)
struct UProtectBaseManager : UObject {
};

// Class ProtectBase.SecDSComponent
// Size: 0xc0 (Inherited: 0x28)
struct USecDSComponent : UObject {
	char pad_28[0x98]; // 0x28(0x98)

	struct USecDSComponent* GetInstance(); // Function ProtectBase.SecDSComponent.GetInstance // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xcc06d0
};

