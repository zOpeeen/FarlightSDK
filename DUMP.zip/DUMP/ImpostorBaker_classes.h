// Class ImpostorBaker.KismetImpostorBakerLibrary
// Size: 0x28 (Inherited: 0x28)
struct UKismetImpostorBakerLibrary : UBlueprintFunctionLibrary {

	struct UStaticMesh* ConvertProceduralToStatic(struct UProceduralMeshComponent* ProceduralMeshComponent, struct FName MeshName, struct FString MeshPath); // Function ImpostorBaker.KismetImpostorBakerLibrary.ConvertProceduralToStatic // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x1cf90f0
};

