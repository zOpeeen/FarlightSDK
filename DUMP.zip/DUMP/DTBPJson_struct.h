// ScriptStruct DTBPJson.DTStruct
// Size: 0x01 (Inherited: 0x00)
struct FDTStruct {
	char pad_0[0x1]; // 0x00(0x01)
};

