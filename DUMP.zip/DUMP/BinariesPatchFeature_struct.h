// Enum BinariesPatchFeature.EBinariesPatchFeature
enum class EBinariesPatchFeature : uint8 {
	None = 0,
	Count = 1,
	EBinariesPatchFeature_MAX = 2
};

